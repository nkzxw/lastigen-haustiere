//////////////////////////////////////////////////////////////////////
// example.cpp
#include "str_stream.hpp"
#include <iomanip>

std::basic_ostream< wchar_t> & width_4( std::basic_ostream< wchar_t> & out)
{
    out.width( 4);
    return out;
}

void print_c_like_str( const char * str) {
    std::cout << str << std::endl;
}

void test() {
    using namespace boost;
    // for wide strings.
    std::wstring str = wstr_stream() << std::oct << 8;
    str = wstr_stream() << std::setfill( L'0') << width_4 << 35 << std::endl;
    std::wcout << str;

    // for strings
    int users = 45;
    std::string s = str_stream() << "There have been " << users << " users logged on so far";
    std::cout << s << std::endl;

    int words = 78;
    s = str_stream( "We found ") << words << " words.";
    std::cout << s << std::endl;
    
    // convert it to C-like string
    print_c_like_str( (str_stream() << "testing " << 1 << 2 << 3).c_str() );
    std::cin.get();
}

int main() {
    test();
}