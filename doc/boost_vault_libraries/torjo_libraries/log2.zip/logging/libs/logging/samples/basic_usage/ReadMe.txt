Example of using Boost Logging Lib v2
