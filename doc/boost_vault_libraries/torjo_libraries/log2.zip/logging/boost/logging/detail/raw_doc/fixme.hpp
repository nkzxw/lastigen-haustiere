/*


about non_const_context

about formatting


convert- also explain that you can convert from str x to y; for instance write_time can actually append the time (instead of prepending it - default)!

formatters - most of them don't need thread-safety, destinations usually need . Explain why/how/when




*/