namespace boost { namespace logging {

/** 
@page template title


*/

}}
