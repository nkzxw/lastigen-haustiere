
#include <boost/rtl.hpp>

#include <vector>
#include <list>
#include <map>
#include <iostream>
#include <assert.h>
#include <numeric>
#include <algorithm>

// note: only the ranges are tested, not the range algorithms !!!


void do_double( int & i) { i *= 2; }

using namespace boost::rtl;
void test_range_of_pointer() {
    int a[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    irange< int*> r( a, a + 10);
    int sum = std::accumulate( r.begin(), r.end(), 0);
    assert( sum == 55);

    std::for_each( r.begin(), r.end(), do_double);
    sum = std::accumulate( r.begin(), r.end(), 0);
    assert( sum == 55 * 2);

    // constant range (like, const_iterator)
    irange< const int*> cr( a, a + 10);
    // compile-time error
    // std::for_each( cr.begin(), cr.end(), do_double);
    sum = 0;
    sum = std::accumulate( cr.begin(), cr.end(), 0);
    assert( sum == 55 * 2);
}


void test_range_of_vector() {
    typedef std::vector< int> array;
    array a;
    for ( int idx = 0; idx < 20; ++idx)
        a.push_back( idx);

    crange< array> r( a);
    int sum = std::accumulate( r.begin(), r.end(), 0);
    assert( sum == 190);

    std::for_each( r.begin(), r.end(), do_double);
    sum = std::accumulate( r.begin(), r.end(), 0);
    assert( sum == 190 * 2);

    // constant range (like, const_iterator)
    crange< const array> cr( a);
    // compile-time error
    //std::for_each( cr.begin(), cr.end(), do_double);
    sum = 0;
    sum = std::accumulate( cr.begin(), cr.end(), 0);
    assert( sum == 190 * 2);
}

void test_range_of_list() {
    typedef std::list< int> array;
    array a;
    for ( int idx = 0; idx < 20; ++idx)
        a.push_back( idx);

    crange< array> r( a);
    int sum = std::accumulate( r.begin(), r.end(), 0);
    assert( sum == 190);

    std::for_each( r.begin(), r.end(), do_double);
    sum = std::accumulate( r.begin(), r.end(), 0);
    assert( sum == 190 * 2);

    // constant range (like, const_iterator)
    crange< const array> cr( a);
    // compile-time error
    //std::for_each( cr.begin(), cr.end(), do_double);
    sum = 0;
    sum = std::accumulate( cr.begin(), cr.end(), 0);
    assert( sum == 190 * 2);
}


template< class iterator>
void show_range_of_iterators( iterator first, iterator last) {
    // note: we can also use range<iterator> !!!
    // (not just range<container>)
    irange< iterator> r( first, last);
    while ( r)
        std::cout << *r++ << ' ';
}

template< class iterator>
void double_range_of_iterators( iterator first, iterator last) {
    // note: we can also use range<iterator> !!!
    // (not just range<container>)
    irange< iterator> r( first, last);
    std::for_each( r.begin(), r.end(), do_double);
}

void test_range_of_list_use_iterators() {
    typedef std::list< int> array;
    array a;
    for ( int idx = 0; idx < 20; ++idx)
        a.push_back( idx);

    show_range_of_iterators( a.begin(), a.end() );
    double_range_of_iterators( a.begin(), a.end() );

    crange< const array> r( a);
    int sum = std::accumulate( r.begin(), r.end(), 0);
    assert( sum == 190 * 2);
}


void test_ranges() {
    test_range_of_pointer();
    test_range_of_vector();
    test_range_of_list();
    test_range_of_list_use_iterators();
}


#if defined(TEST_RANGES)

int main(int argc, char* argv[])
{
	test_ranges();
}

#endif