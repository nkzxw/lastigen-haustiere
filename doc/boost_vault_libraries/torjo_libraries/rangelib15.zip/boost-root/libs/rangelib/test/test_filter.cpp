
#if 0

#include <boost/rtl/rtl.hpp>
#include <boost/rtl/algo.hpp>

#include <deque>
#include <vector>
#include <list>

#include <iostream>
using namespace boost::rtl;

namespace {
    template< class iterator, class pred, class range>
    void test_range_impl( iterator first, iterator last, pred p, range r) {
        while ( first != last) {
            if ( p( *first)) {
                // see if it's in the filtered range as well
                if ( &*first == &*r)
                    ;
                else
                    // range is not working correctly!
                    // it did not advance correctly
                    assert( false);
                // advance to the next filtered element
                ++r;
            }
            ++first;
        }
    }


    // tests that the filtered range is the same as manually
    // filtering the range (by using the given predicate
    //
    // note: we need forward iterators
    template< class iterator, class pred>
    void test_range( iterator first, iterator last, pred p) {
        test_range_impl( first, last, p, 
            r_adapt<filter_adaptor>( i_range(first,last), p) );
    }

    bool divides_by_two( int i) {
        return (i % 2) == 0;
    }
    bool divides_by_three( int i) {
        return (i % 3) == 0;
    }

    template< class container>
    void test_filter( container * ignore_vc_bug = 0) {
        container c;
        for ( int idx = 0; idx < 10000; ++idx)
            c.push_back( idx);

        test_range( c.begin(), c.end(), divides_by_two);
        test_range( c.begin(), c.end(), divides_by_three);
    }

} // namespace
 




struct test {
    bool operator()(int) { return true; }
};

#endif
