
#include <boost/rangelib/slice_byeach.hpp>
#include <boost/rangelib/algo.hpp>
using namespace boost::rangelib;
#include <time.h>
#include <boost/format.hpp>
#include <map>
#include <string>
#include <iostream>

namespace {
// represents details about items that's been sold
struct sold_items_info {
    sold_items_info( const char * item, time_t t, int items, const char * customer)
        : item_name(item), sold_at_time(t), items_count(items), customer_name(customer) {}

    std::string item_name;
    time_t sold_at_time;
    // how many items did we sell
    int items_count;
    // to whom we sold?
    std::string customer_name;
};



bool slice_into_days( const sold_items_info & first, const sold_items_info & second) {
    tm details1= *localtime(&first.sold_at_time);
    tm details2 = *localtime(&second.sold_at_time);
    return details1.tm_year == details2.tm_year && 
        details1.tm_yday == details2.tm_yday;
}


/////////////////////////////////////////////////////////
// showing how many items of each kind were bought each day

struct item_summary {
    time_t day;
    std::map< std::string, int> items;
};
void add_item_summary( item_summary & summary, sold_items_info & info) {
    summary.day = info.sold_at_time;
    summary.items[ info.item_name] += info.items_count;
}

void show_item_summary( const item_summary & summary) {
    tm details = *localtime(&summary.day);
    std::cout << (boost::format("On %d-%d-%d, we've sold:") % (details.tm_year+1900) % (details.tm_mon+1) % details.tm_mday) << std::endl;
    crange< const std::map<std::string,int> > r( summary.items);
    while (r) {
        std::cout << r->second << ' ' << r->first << "(s)" << std::endl;
        ++r;
    }
}

/////////////////////////////////////////////////////////
// showing customers that bought each day

struct customer_summary {
    time_t day;
    std::map< std::string, std::string> items_per_cust;
};

// in case you have a functor, either derive from binary_function, 
// or just typedef the first parameter
struct add_customer_summary {
    typedef customer_summary first_argument_type;
    void operator() ( customer_summary & summary, sold_items_info & info) const {
        summary.day = info.sold_at_time;
        std::string & s= summary.items_per_cust[ info.customer_name];

        using namespace boost;
        if ( !s.empty() ) s += " and ";
        s += io::str( format("%1% %2%(s)") % info.items_count % info.item_name);
    }
};

void show_customer_summary( const customer_summary & summary) {
    tm details = *localtime(&summary.day);
    std::cout << (boost::format("On %d-%d-%d we had the following customers:") % (details.tm_year+1900) % (details.tm_mon+1) % details.tm_mday) << std::endl;
    crange< const std::map<std::string,std::string> > r( summary.items_per_cust);
    while (r) {
        std::cout << r->first << ", who bought " << r->second << std::endl;
        ++r;
    }
}

} // namespace



void use_slice_byeach() {
    std::vector< sold_items_info> v;
    time_t now = time(0);
    // ... 8 days ago
    v.push_back( sold_items_info( "Soap", now - 8*24*60*60 - 5684, 5, "John" ) );
    v.push_back( sold_items_info( "TV", now - 8*24*60*60 - 2684, 2, "Matt" ) );
    v.push_back( sold_items_info( "Soap", now - 8*24*60*60 - 1384, 10, "Frank" ) );
    v.push_back( sold_items_info( "sofa", now - 8*24*60*60 - 684, 1, "Frank" ) );
    v.push_back( sold_items_info( "computer", now - 8*24*60*60 - 73, 3, "Cathy" ) );
    v.push_back( sold_items_info( "TV", now - 8*24*60*60, 1, "Irene" ) );
    // ... 7 days ago
    v.push_back( sold_items_info( "speaker", now - 7*24*60*60 - 6543, 4, "Cathy" ) );
    v.push_back( sold_items_info( "phone", now - 7*24*60*60 - 3885, 3, "Mary" ) );
    v.push_back( sold_items_info( "Soap", now - 7*24*60*60 - 2543, 6, "Mary" ) );
    v.push_back( sold_items_info( "speaker", now - 7*24*60*60 - 235, 20, "James" ) );
    v.push_back( sold_items_info( "TV", now - 7*24*60*60 - 25, 5, "Cathy" ) );
    // ... 4 days ago
    v.push_back( sold_items_info( "hard-disk", now - 4*24*60*60 - 7522, 10, "Irene" ) );
    v.push_back( sold_items_info( "computer", now - 4*24*60*60 - 6552, 3, "Bill" ) );
    v.push_back( sold_items_info( "laptop", now - 4*24*60*60 - 4522, 5, "Irene" ) );
    v.push_back( sold_items_info( "TV", now - 4*24*60*60 - 2322, 1, "Francis" ) );
    v.push_back( sold_items_info( "phone", now - 4*24*60*60 - 522, 1, "Ford" ) );
    // ... one day ago
    v.push_back( sold_items_info( "phone", now - 1*24*60*60 - 3478, 3, "Shrek" ) );
    v.push_back( sold_items_info( "sofa", now - 1*24*60*60 - 2668, 1, "Matt" ) );
    v.push_back( sold_items_info( "speaker", now - 1*24*60*60 - 1478, 3, "John" ) );
    v.push_back( sold_items_info( "phone", now - 1*24*60*60, 1, "Mary" ) );
    // ... around now
    v.push_back( sold_items_info( "laptop", now - 3443, 1, "Sue" ) );
    v.push_back( sold_items_info( "cd", now - 2445, 30, "Monica" ) );
    v.push_back( sold_items_info( "laptop", now - 1343, 2, "John" ) );
    v.push_back( sold_items_info( "laptop", now - 38, 20, "Monica" ) );

    /* Output:

        On 2003-11-26, we've sold:
        15 Soap(s)
        3 TV(s)
        3 computer(s)
        1 sofa(s)
        On 2003-11-27, we've sold:
        6 Soap(s)
        5 TV(s)
        3 phone(s)
        24 speaker(s)
        On 2003-11-30, we've sold:
        1 TV(s)
        3 computer(s)
        10 hard-disk(s)
        5 laptop(s)
        1 phone(s)
        On 2003-12-3, we've sold:
        4 phone(s)
        1 sofa(s)
        3 speaker(s)
        On 2003-12-4, we've sold:
        30 cd(s)
        23 laptop(s)        
    */
    // showing how many items of each kind were bought each day
    rng::for_each( sliced_byeach(v, 
        rng::fun<item_summary>(&add_item_summary), &slice_into_days),
        //       ^^^^^^^^^^^^ - this obfuscation is needed for dummy VC6 
        //                      (in case you have a function, and not an object)
        show_item_summary);

    std::cout << "-----------------------" << std::endl;
    /* Output:

        On 2003-11-26 we had the following customers:
        Cathy, who bought 3 computer(s)
        Frank, who bought 10 Soap(s) and 1 sofa(s)
        Irene, who bought 1 TV(s)
        John, who bought 5 Soap(s)
        Matt, who bought 2 TV(s)
        On 2003-11-27 we had the following customers:
        Cathy, who bought 4 speaker(s) and 5 TV(s)
        James, who bought 20 speaker(s)
        Mary, who bought 3 phone(s) and 6 Soap(s)
        On 2003-11-30 we had the following customers:
        Bill, who bought 3 computer(s)
        Ford, who bought 1 phone(s)
        Francis, who bought 1 TV(s)
        Irene, who bought 10 hard-disk(s) and 5 laptop(s)
        On 2003-12-3 we had the following customers:
        John, who bought 3 speaker(s)
        Mary, who bought 1 phone(s)
        Matt, who bought 1 sofa(s)
        Shrek, who bought 3 phone(s)
        On 2003-12-4 we had the following customers:
        John, who bought 2 laptop(s)
        Monica, who bought 30 cd(s) and 20 laptop(s)
        Sue, who bought 1 laptop(s)    
    */
    rng::for_each( sliced_byeach(v, add_customer_summary(), &slice_into_days),
        show_customer_summary);
}

#if defined(USING_SLICE_BYEACH)

int main() {
    use_slice_byeach();
    return 0;
}

#endif
