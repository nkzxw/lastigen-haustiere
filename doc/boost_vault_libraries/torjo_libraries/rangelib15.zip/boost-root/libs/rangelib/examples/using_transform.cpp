
#include <boost/rangelib/transform.hpp>
#include <boost/rangelib/algo.hpp>

#include <vector>
#include <iostream>
#include <algorithm>
#include <list>
#include <iterator>
#include <string>

using namespace boost::rangelib;

namespace {
    struct name {
        name( const std::string & first, const std::string & second)
            : m_first_name( first), m_last_name( second) {}
        std::string m_first_name;
        std::string m_last_name;
    };

    std::string first_name( const name& n) {
        return n.m_first_name;
    }
    std::string last_name( const name& n) {
        return n.m_last_name;
    }
}


void use_transform() {
    typedef std::list<name> array;
    array l;
    l.push_back( name( "John", "Doe") );
    l.push_back( name( "Frank", "Enstein") );
    l.push_back( name( "Sherry", "Loe") );
    l.push_back( name( "Marry", "Luis") );
    l.push_back( name( "Marry", "Christmas") );
    std::cout << "First names:" << std::endl;
    rng::copy( transformed_f(l,&first_name), std::ostream_iterator<std::string>(std::cout," ") );
    std::cout << "Last names:" << std::endl;
    rng::copy( transformed_f(l,&last_name), std::ostream_iterator<std::string>(std::cout," ") );
}



#if defined(USING_TRANSFORM)

int main() {
    use_transform();

	return 0;
}

#endif
