
#include <boost/rangelib/range.hpp>
#include <boost/rangelib/multi.hpp>
#include <boost/rangelib/algo.hpp>
#include <boost/rangelib/resort.hpp>
#include <vector>
#include <iterator>
#include <iostream>
#include <string>
using namespace boost::rangelib;


namespace {
	
	struct employee {
		employee( int i, const std::string & nm, int sal) : id(i), name(nm), salary(sal) {
		}
		int id;
		std::string name;
		int salary;
	};
	std::ostream & operator<< ( std::ostream & out, const employee & empl) {
		return out << "ID " << empl.id << ", Name: " << empl.name << ", Salary: " << empl.salary;
	}
	bool employee_byname( const employee & first, const employee & second) {
		return first.name < second.name;
	}
	bool employee_bysalary( const employee & first, const employee & second) {
		return first.salary < second.salary;
	}
	
	struct department {
		department(int i, const std::string & nm) : id(i), name(nm) {
		}
		int id;
		std::string name;
		std::vector<employee> empls;
	};

	crange< const std::vector<employee> > get_empls(const department & d) {
		return d.empls;
	}

}

BOOST_TT_BROKEN_COMPILER_SPEC(employee)

#ifdef USING_MULTI_BYRANGE

int main() {
	std::vector<department> deps;
	// empty department
	deps.push_back( department( 0, "No Relations (empty)") );

	deps.push_back( department( 1, "Public Relations") );
	deps.back().empls.push_back( employee( 1, "John Doe", 30000) );
	deps.back().empls.push_back( employee( 2, "Cora Leoni", 24000) );
	deps.back().empls.push_back( employee( 3, "Titi Mnemonic", 25000) );
	deps.back().empls.push_back( employee( 4, "Someone Else", 33000) );
	deps.back().empls.push_back( employee( 5, "Mumu International", 50000) );

	deps.push_back( department( 2, "Customer Care") );
	deps.back().empls.push_back( employee( 6, "Demi Moo", 10000) );
	deps.back().empls.push_back( employee( 7, "Semi Bau", 14000) );
	deps.back().empls.push_back( employee( 8, "Joe Osmosis", 40000) );
	deps.back().empls.push_back( employee( 9, "Gigi Duru", 45000) );
	deps.back().empls.push_back( employee( 10, "Inter Planetarium", 100000) );

	deps.push_back( department( 3, "Logistics") );
	deps.back().empls.push_back( employee( 11, "Camelia Titirezu", 3000) );
	deps.back().empls.push_back( employee( 12, "Petronela Baubau", 6000) );
	deps.back().empls.push_back( employee( 13, "James Forrs", 7000) );
	deps.back().empls.push_back( employee( 14, "Forever Darling", 800000) );
	deps.back().empls.push_back( employee( 15, "Mio Fratello", 70000) );

	// empty department
	deps.push_back( department( 4, "Another Empty department") );

	deps.push_back( department( 5, "IT") );
	deps.back().empls.push_back( employee( 16, "Tradi Tional", 20000) );
	deps.back().empls.push_back( employee( 17, "Joe Black", 10000) );
	deps.back().empls.push_back( employee( 18, "Fou Thai", 3000) );
	deps.back().empls.push_back( employee( 19, "Johhny Mee", 120000) );
	deps.back().empls.push_back( employee( 20, "You Hoooou", 17000) );

	// empty department
	deps.push_back( department( 7, "Last department (empty)") );

	// shows all employees (
	std::cout << "\nAll employees: " << std::endl;
	rng::copy( multied_byrange_f( deps, &get_empls),
		std::ostream_iterator<employee>( std::cout, "\n"));

	std::cout << "\nAll employees, sorted by name: " << std::endl;
	rng::copy( resorted(multied_byrange_f( deps, &get_empls), &employee_byname),
		std::ostream_iterator<employee>( std::cout, "\n"));
	std::cout << "\nAll employees, sorted by salary: " << std::endl;
	rng::copy( resorted(multied_byrange_f( deps, &get_empls), &employee_bysalary),
		std::ostream_iterator<employee>( std::cout, "\n"));
}

#endif
