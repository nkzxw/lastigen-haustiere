
#include <boost/rangelib/slice_byrange.hpp>
#include <boost/rangelib/slice_byeach.hpp>
#include <boost/rangelib/range.hpp>
#include <boost/rangelib/algo.hpp>
using namespace boost::rangelib;
#include <string>

#include <iostream>
#include <fstream>
#include <sstream>
#include <iterator>
#include <boost/bind.hpp>
#include <numeric>


/*
    Example 1:

    A simple tokenizer, that separates a text into words.
    Anything between quotes is considered a word.
*/

bool is_separator( char ch) { return isspace(ch) || ispunct(ch); }

// does a new word begin, after 'first'?
struct word_finder {
    word_finder() : m_in_quote(false) {}

    bool operator()( char first, char second) {
        if ( m_in_quote) {
            // within quoted string
            if ( first == '"') {
                m_in_quote = false;
                return false;
            }
            else
                return true;
        }
        else // not within quoted string 
            if ( first == '"') {            
                m_in_quote = true;
                return true;
            }

        if ( !is_separator(second))
            // not a separator, is from same word
            return true;

        if ( is_separator(first))
            // first char is separator, second char is separator
            return true;
        else 
            // first char is not separator, second char is separator
            return false;
    }
private:
    bool m_in_quote;
};

template<class iterator>
void ignore_seps(iterator & begin, iterator &end) {
    while ( begin != end)
        if (is_separator(*begin)) ++begin;
        else break;
    while ( begin != end)
        if (is_separator(end[-1])) --end; 
        else break;

    if ( begin < end)
        if ( (*begin == '"') && (*end == '"'))
            ++begin, --end;
        // if only begin or only end is quote, you can throw an exception
}


struct parse_word {
    typedef std::string first_argument_type;
    template< class iterator>
    void operator()( std::string & out, iterator begin, iterator end) {
       ignore_seps(begin,end);
       out.assign( begin, end);
    }
};

struct parse_word_len {
    typedef int first_argument_type;
    template< class iterator>
    void operator()( int & res, iterator begin, iterator end) {
        ignore_seps(begin,end);
        res = end - begin;
    }
};


/*
    Example 2:

    A simple tokenzier recognizing XML escaped sequences:
    (case-sensitive)
    &lt; <
    &gt; >
    &amp; &

    &quot; "
    &#DDD; character coresponding to the given decimal number
    &#xHH; character coresponding to the given hexa-decimal number
*/

// finds escape sequences
struct xml_escape_finder {
    xml_escape_finder() : is_escaped( false) {}

    bool operator()( char first, char second) {
        if ( is_escaped) {
            if ( first == ';') {
                is_escaped = false;
                return false;
            }
            else 
                // we're still within the escaped sequence
                return true;
        }
        else // not escaped
            if ( first == '&') {
                // new escaped sequence begins
                is_escaped = true;
                return true;
            }
            else
                // not an escaped sequece
                return false;

    }
private:
    bool is_escaped;
};

void add_hex_char( int & val, char ch) {
    int digit = 0;
    if ( isdigit(ch))
        digit = ch - '0';
    else {
        ch = toupper(ch);
        digit = ch - 'A';
    }        
    if ( digit < 0 || digit > 9)
        throw std::runtime_error( "invalid digit char");
    val *= 16;
    val += digit;
}
void add_dec_char( int & val, char ch) {
    int digit = 0;
    if ( isdigit(ch))
        digit = ch - '0';
    else
        throw std::runtime_error( "invalid digit char");
    val *= 10;
    val += digit;
}


// this has got one bug, which I'm not willing to reveal ;)
struct parse_xml_char {
    typedef char first_argument_type;
    template<class iterator>
    void operator()( char & ch, iterator begin, iterator end) {
        if ( end - begin == 1) {
            // not escaped
            ch = *begin;
            return;
        }
        else if ( *begin == '&' && end[-1] == ';') {
            ++begin, --end;
            irange<iterator> char_seq(begin,end);
            if ( rng::equal( char_seq, i_("lt") )) {
                ch = '<';
                return;
            }
            else if ( rng::equal( char_seq, i_("gt") )) {
                ch = '>';
                return;
            }
            else if ( rng::equal( char_seq, i_("quot") )) {
                ch = '"';
                return;
            }
            else if ( rng::equal( char_seq, i_("amp") )) {
                ch = '>';
                return;
            }

            // look for &# sequences
            if ( char_seq)
                if ( *char_seq == '#') {
                    ++char_seq;
                    if ( char_seq) {
                        using boost::bind; using boost::ref;
                        if ( *char_seq == 'x') {
                            // hexadecimal number
                            ++char_seq;
                            if ( char_seq) {
                                // we have at least one more char
                                int val = 0;
                                rng::for_each( char_seq, bind( add_hex_char, ref(val), _1) );
                                ch = (char)val;
                                return;
                            }
                        }
                        else {
                            // decimal number
                            int val = 0;
                            rng::for_each( char_seq, bind( add_dec_char, ref(val), _1) );
                            ch = (char)val;
                            return;
                        }
                    }
                }
        }

        throw std::runtime_error( "invalid escape");
    }
};


int get_max( int i, int j) { return std::max(i, j); }
void string_append( std::string & s, char ch) { s += ch; }



void use_slice_byrng_tokenize() {
    using boost::bind; using boost::ref;

    std::string words = " \"there are\" quite a few ,   .\nwords \"in here\", \"three in one\" end. \nTake my word for it,mate.";
    // show the words
    rng::copy( sliced_byrange(words, parse_word(), word_finder() ),
        std::ostream_iterator<std::string>(std::cout,"\n") );
    // show max length
    int max_len = rng::accumulate( sliced_byrange(words, parse_word_len(), word_finder() ),
        0, get_max);
    std::cout << "max word is of length " << max_len << std::endl;

    // same as the words above ;)
    std::string words_xml = " &quot;there are&quot; quite a few&#32;"
        ",   .&#10;words &#x22;in here&quot;, &quot;three in one&quot; end. "
        "&#10;T&#x61;ke my wo&#114;d for it,mate.";

    std::string escaped;
    escaped.reserve( words_xml.size());
    // decode the xml string
    rng::for_each( sliced_byrange( words_xml, parse_xml_char(), xml_escape_finder()),
        bind(string_append, ref(escaped), _1) );
    assert ( escaped == words);

    /*
    rng::for_each( 
        sliced_byeach( 
            sliced_byrange( words_xml, rng::fun<char>(parse_xml_char), xml_escape_finder()),
            parse_word(), word_finder() ),
         std::ostream_iterator<std::string>(std::cout,"\n") );
*/
    /*
        FIXME For some strange reason, in VC6 I can't use the result of
        sliced_byrange in a composition (for instance, to further filter it).

		Note: I have fixed this, should retry the above again.
    */
}

#ifdef USING_SLICE_BYRNG_TOKENIZE

int main() {
    use_slice_byrng_tokenize();
    return 0;
}

#endif
