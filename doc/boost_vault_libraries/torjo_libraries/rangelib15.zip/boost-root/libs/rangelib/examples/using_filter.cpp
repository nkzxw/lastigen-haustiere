
#include <boost/rangelib/filter.hpp>
#include <boost/rangelib/algo.hpp>

#include <vector>
#include <iostream>
#include <algorithm>
#include <list>
#include <iterator>

using namespace boost::rangelib;


namespace {
    struct next {
        next() : m_i(0) {}
        int operator() () { return m_i++; }
    private:
        int m_i;
    };

    bool is_even(int i) { return (i%2) == 0; }
    bool divides_by3(int i) { return (i%3) == 0; }

}

void use_filter() {
    typedef std::list<int> array;
    array l;
    l.resize( 50);
    rng::generate( l, next() );
    rng::reverse( l);

    // print out only the even elements
    std::cout << "even numbers " << std::endl;
    rng::copy( filtered(l,&is_even), std::ostream_iterator<int>(std::cout," ") );

    // same thing as above, only now, one number per line
    filtered_range<array,bool(*)(int)> r( l, &is_even);
    while (r) {
        std::cout << *r++ << std::endl;
    }

    // constant list (usually MSVC6 has problems with this)
    const array l2(l);
    std::cout << "numbers dividable by 3" << std::endl;
    rng::copy( filtered(l2,&divides_by3), std::ostream_iterator<int>(std::cout," ") );
}



#if defined(USING_FILTER)

int main() {
    use_filter();

	return 0;
}

#endif
