
#include <boost/rangelib/transform.hpp>
#include <boost/rangelib/reverse.hpp>
#include <boost/rangelib/algo.hpp>

#include <vector>
#include <iostream>
#include <algorithm>
#include <list>
#include <iterator>
#include <string>

using namespace boost::rangelib;

namespace {
    struct name {
        name( const std::string & first, const std::string & second)
            : m_first_name( first), m_last_name( second) {}
        std::string m_first_name;
        std::string m_last_name;
    };
    std::ostream& operator<<( std::ostream & out, const name & n) {
        return out << n.m_first_name << ' ' << n.m_last_name << ' ';
    }

    std::string first_name( const name& n) {
        return n.m_first_name;
    }
    std::string last_name( const name& n) {
        return n.m_last_name;
    }
}


void use_reverse() {
    typedef std::list<name> array;
    array l;
    l.push_back( name( "John", "Doe") );
    l.push_back( name( "Frank", "Enstein") );
    l.push_back( name( "Sherry", "Loe") );
    l.push_back( name( "Marry", "Luis") );
    l.push_back( name( "Marry", "Christmas") );
    std::cout << "\nNames in normal order:" << std::endl;
    rng::copy( l, std::ostream_iterator<name>(std::cout,",") );
    std::cout << "\nNames in reversed order:" << std::endl;
    rng::copy( reversed(l), std::ostream_iterator<name>(std::cout,",") );


    std::cout << "\nFirst Names in reversed order:" << std::endl;
    // we can first apply transform, and then reverse...
    rng::copy( reversed(transformed_f(l,&first_name) ), 
        std::ostream_iterator<std::string>(std::cout,",") );

    // ... or, vice-versa
    std::cout << "\nLast Names in reversed order:" << std::endl;
    rng::copy( transformed_f(reversed(l),&last_name) , 
        std::ostream_iterator<std::string>(std::cout,",") );

}



#if defined(USING_REVERSE)

int main() {
    use_reverse();

	return 0;
}

#endif
