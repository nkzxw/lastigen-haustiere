
#include <boost/rangelib/slice_byrange.hpp>
#include <boost/rangelib/algo.hpp>
#include <boost/rangelib/transform.hpp>
using namespace boost::rangelib;
#include <boost/bind.hpp>
#include <boost/format.hpp>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iterator>
#include <vector>
#include <map>
#include <numeric>
#include <time.h>


/*
    note: example not ready yet ;)
*/


// have a double array (just like lambda example)


namespace {

// represents details about items that's been sold
struct sold_items_info {
    sold_items_info( const char * item, time_t t, int items, const char * customer)
        : item_name(item), sold_at_time(t), items_count(items), customer_name(customer) {}

    std::string item_name;
    time_t sold_at_time;
    // how many items did we sell
    int items_count;
    // to whom we sold?
    std::string customer_name;
};



bool slice_into_days( const sold_items_info & first, const sold_items_info & second) {
    tm details1= *localtime(&first.sold_at_time);
    tm details2 = *localtime(&second.sold_at_time);
    return details1.tm_year == details2.tm_year && 
        details1.tm_yday == details2.tm_yday;
}

template<class T>
struct select1st {
    template< class pair>
    T operator()( pair & val) { return val.first; }
    template< class pair>
    T operator()( const pair & val) const { return val.first; }
};
template<class T>
struct select2nd {
    template< class pair>
    T operator()( pair & val) { return val.second; }
    template< class pair>
    T operator()( const pair & val) const { return val.second; }
};


// information about the best customer
// we consider best customer the one who bought most no. of items ;)
struct best_customer_info {
    // period for which best customer is computed
    time_t start;
    std::string customer_name;
    // user-friendly string.
    std::string items;
};

int get_min(int a, int b) { return a < b ? a : b; }

struct get_best_customer {
	typedef best_customer_info first_argument_type;

    template< class iterator> 
	void operator()( best_customer_info & info, iterator begin, iterator end) {
        using namespace boost;

        // find out the best customer
        typedef std::map< std::string, int> coll;
        coll items;
        irange<iterator> r( begin, end);
        while ( r) {
			items[ r->customer_name] += r->items_count;
            ++r;
        }

		crange<const coll> r_item( items);
		int max = -1;
		std::string best;
		while ( r_item) {
			if ( max < r_item->second) 
				best = r_item->first, max = r_item->second;
			++r_item;
		}
		info.customer_name = best;
		info.items.erase();
		info.start = begin->sold_at_time;
        // find out what he bought
        r = i_range(begin,end);
        while ( r) {
            if ( r->customer_name == best) {
                if ( !info.items.empty()) info.items += " and ";
                info.items += io::str(format("%1% %2%(s)") % r->items_count % r->item_name);
            }
            ++r;
        }
    }
};

} // namespace


BOOST_TT_BROKEN_COMPILER_SPEC(sold_items_info)

namespace {
	void show_best_customer_info( const best_customer_info & info) {
		tm details = *localtime(&info.start);
		std::cout << (boost::format("Best customer for %d-%d-%d") % (details.tm_year+1900) % (details.tm_mon+1) % details.tm_mday)
			<< " is " << info.customer_name << ", who bought " << info.items << std::endl;
	}
}

void use_slice_byrng() {
    std::vector< sold_items_info> v;
    time_t now = time(0);
    // ... 8 days ago
    v.push_back( sold_items_info( "Soap", now - 8*24*60*60 - 5684, 5, "John" ) );
    v.push_back( sold_items_info( "TV", now - 8*24*60*60 - 2684, 2, "Matt" ) );
    v.push_back( sold_items_info( "Soap", now - 8*24*60*60 - 1384, 10, "Frank" ) );
    v.push_back( sold_items_info( "sofa", now - 8*24*60*60 - 684, 1, "Frank" ) );
    v.push_back( sold_items_info( "computer", now - 8*24*60*60 - 73, 3, "Cathy" ) );
    v.push_back( sold_items_info( "TV", now - 8*24*60*60, 1, "Irene" ) );
    // ... 7 days ago
    v.push_back( sold_items_info( "speaker", now - 7*24*60*60 - 6543, 4, "Cathy" ) );
    v.push_back( sold_items_info( "phone", now - 7*24*60*60 - 3885, 3, "Mary" ) );
    v.push_back( sold_items_info( "Soap", now - 7*24*60*60 - 2543, 6, "Mary" ) );
    v.push_back( sold_items_info( "speaker", now - 7*24*60*60 - 235, 20, "James" ) );
    v.push_back( sold_items_info( "TV", now - 7*24*60*60 - 25, 5, "Cathy" ) );
    // ... 4 days ago
    v.push_back( sold_items_info( "hard-disk", now - 4*24*60*60 - 7522, 10, "Irene" ) );
    v.push_back( sold_items_info( "computer", now - 4*24*60*60 - 6552, 3, "Bill" ) );
    v.push_back( sold_items_info( "laptop", now - 4*24*60*60 - 4522, 5, "Irene" ) );
    v.push_back( sold_items_info( "TV", now - 4*24*60*60 - 2322, 1, "Francis" ) );
    v.push_back( sold_items_info( "phone", now - 4*24*60*60 - 522, 1, "Ford" ) );
    // ... one day ago
    v.push_back( sold_items_info( "phone", now - 1*24*60*60 - 3478, 3, "Shrek" ) );
    v.push_back( sold_items_info( "sofa", now - 1*24*60*60 - 2668, 1, "Matt" ) );
    v.push_back( sold_items_info( "speaker", now - 1*24*60*60 - 1478, 3, "John" ) );
    v.push_back( sold_items_info( "phone", now - 1*24*60*60, 1, "Mary" ) );
    // ... around now
    v.push_back( sold_items_info( "laptop", now - 3443, 1, "Sue" ) );
    v.push_back( sold_items_info( "cd", now - 2445, 30, "Monica" ) );
    v.push_back( sold_items_info( "laptop", now - 1343, 2, "John" ) );
    v.push_back( sold_items_info( "laptop", now - 38, 20, "Monica" ) );


    // showing best customer information for each day
    rng::for_each( sliced_byrange(v, get_best_customer(), &slice_into_days),
        show_best_customer_info);

    std::cout << "-----------------------" << std::endl;
    /* Output:

		Best customer for 2004-1-6 is Frank, who bought 10 Soap(s) and 1 sofa(s)
		Best customer for 2004-1-7 is James, who bought 20 speaker(s)
		Best customer for 2004-1-10 is Irene, who bought 10 hard-disk(s) and 5 laptop(s)

		Best customer for 2004-1-13 is John, who bought 3 speaker(s)
		Best customer for 2004-1-14 is Monica, who bought 30 cd(s) and 20 laptop(s)    
	*/
}

#if defined(USING_SLICE_BYRNG)

int main() {
    use_slice_byrng();
    return 0;
}

#endif
