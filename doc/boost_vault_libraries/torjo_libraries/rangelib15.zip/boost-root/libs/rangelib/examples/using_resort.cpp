
#include <boost/rangelib/resort.hpp>
#include <boost/rangelib/filter.hpp>
#include <boost/rangelib/indirect.hpp>
#include <boost/rangelib/transform.hpp>
#include <boost/rangelib/algo.hpp>

#include <vector>
#include <iostream>
#include <algorithm>
#include <list>
#include <iterator>
#include <fstream>
#include <string>
#if defined(__MWERKS__)
# include <ctype>
using std::toupper;
#endif /* BOOST_MWERKS */
#include <stdlib.h>

using namespace boost::rangelib;

bool less_insensitive_char( char first, char second) {
    return toupper(first) < toupper(second);
}
bool less_insensitive( const std::string & first, const std::string & second) {
    return rng::lexicographical_compare( first, second, less_insensitive_char);
}
bool begins_with_b( const std::string & str) {
    if ( str.empty() ) return false;
    return str[0] == 'b' || str[0] == 'B';
}
std::string in_uppercase( const std::string & str) {
    std::string up = str;
    rng::transform( up, up.begin(), toupper);
    return up;
}

BOOST_TT_BROKEN_COMPILER_SPEC(std::string) // I ****hate**** VC6
void use_resort() {
    std::ifstream in( "./using_resort.cpp");
    std::vector< std::string> words;
    // read all words from the file, and insert them into the array
    rng::copy( istream_range<std::string>(in), std::back_inserter(words));

    std::cout << "\nAll words, (re)sorted, case-sensitive" << std::endl;
    rng::copy( resorted(words), std::ostream_iterator<std::string>(std::cout," ") );
    std::cout << "\nAll words, (re)sorted case-INsensitive" << std::endl;
    rng::copy( resorted(words, less_insensitive), 
        std::ostream_iterator<std::string>(std::cout," ") );

    // and best is yet to come...

    // resords the words, case insensitive,
    // then filters only those that begin with letter 'b',
    // and shows them in uppercase
    std::cout << "\nWords that begin with 'b', (re)sorted case-INsensitive, shown in uppercase" << std::endl;
    rng::copy( transformed_f( filtered( resorted(words, less_insensitive), begins_with_b), in_uppercase),
        std::ostream_iterator<std::string>(std::cout," ") );

    // the original range (so that you see its original order was preserved)
    std::cout << "\nThe words, as they were read" << std::endl;
    rng::copy( words, std::ostream_iterator<std::string>(std::cout," ") );
}



#if defined(USING_RESORT)

int main() {
    use_resort();

	return 0;
}

#endif
