
#include <boost/rangelib/generate.hpp>
#include <boost/rangelib/algo.hpp>
using namespace boost::rangelib;
#include <iostream>
#include <functional>

namespace {
    struct step {
        typedef int result_type;
        step( int s = 1) : m_i(0), m_step( s) {}
        int operator() () { 
            int i = m_i;
            m_i += m_step;
            return i; 
        }
    private:
        int m_i;
        int m_step;
    };

    struct fibonacci {
        typedef int result_type;
        fibonacci() : m_first( 0), m_second( 1) {}
        int operator()() {
            int tmp = m_first + m_second;
            m_first = m_second;
            m_second = tmp;
            return m_first;
        }
    private:
        int m_first, m_second;
    };
    
}


#ifdef USING_GENERATE

int main() {
    std::cout << "\nNumbers from 0 to 9" << std::endl;
    rng::copy( generated(step(), gen_n(10)), std::ostream_iterator<int>(std::cout," "));

    std::cout << "\nFirst 10 numbers, in increments of 3" << std::endl;
    rng::copy( generated(step(3), gen_n(10)), std::ostream_iterator<int>(std::cout," "));

    std::cout << "\nFirst 20 fibonnacci numbers" << std::endl;
    rng::copy( generated(fibonacci(), gen_n(20)), std::ostream_iterator<int>(std::cout," "));

    std::cout << "\nFibonnacci numbers, up to 200" << std::endl;
    rng::copy( generated(fibonacci(), gen_upto(200)), std::ostream_iterator<int>(std::cout," "));

    // multiplies each fibonacci number with its index:
    // 1 * 0
    // 2 * 1
    // 3 * 2
    // 5 * 3, etc.
    std::cout << "\nFibonnacci numbers, multiplied by their index" << std::endl;
    rng::transform( 
        generated( step(), gen_n(20)),
        generated( fibonacci(), gen_n(20)), 
        std::ostream_iterator<int>(std::cout," "),
        std::multiplies<int>() );
}

#endif
