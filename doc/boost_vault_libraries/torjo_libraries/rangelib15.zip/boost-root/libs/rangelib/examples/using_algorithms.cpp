
#include <boost/rangelib/range.hpp>
#include <boost/rangelib/algo.hpp>

#include <deque>
#include <vector>
#include <list>
#include <iterator>
#include <iostream>
using namespace boost::rangelib;


namespace {
    bool test( int i) { return true; }

    struct next {
        next() : m_i(0) {}
        int operator() () {
            return m_i++;
        }
    private:
        int m_i;
    };

    void print_out(int i) {
        std::cout << i << std::endl;    
    }

    int do_double( int i) { return i * 2; }
    int do_multiply( int i, int j) { return i * j; }
    bool is_consecutive( int i, int j) { return i + 1 == j; }
}

#if defined(USING_ALGORITHMS)

int main() {

    std::vector<int> v;
    v.resize( 10);
    rng::generate( v, next() );
    rng::reverse( v);
    rng::for_each( v, print_out );

    std::cout << "---------------------------" << std::endl;
    std::deque<int> d;
    rng::transform( v, std::back_inserter(d), do_double);
    rng::for_each( d, print_out );

    std::cout << "---------------------------" << std::endl;
    rng::replace_copy( v, std::back_inserter(d), 0, 100);
    rng::for_each( d, print_out );

    std::list<int> l;
    std::cout << "---------------------------" << std::endl;
    rng::sort( v);
    rng::sort( d);
    rng::merge( v, d, std::back_inserter(l) );
    rng::for_each( l, print_out );

    std::cout << "---------------------------" << std::endl;
    // computing product of v & d
    std::list<int> product;
    rng::transform( v, d, std::back_inserter(product), do_multiply);
    rng::for_each( product, print_out );

    const std::list<int> same = product;
    std::cout << "---------------------------" << std::endl;
    // used to choke on VC6 (same is const)
    rng::copy( same, std::ostream_iterator<int>(std::cout, " ") );

    std::cout << "---------------------------" << std::endl;
    // finds first two equal elements, and then prints everything starting from there
    rng::reverse(l);
    rng::for_each( rng::adjacent_find(l), print_out);
    rng::reverse(l);

    // finds first two consecutive elements, and then prints everything starting from there
    std::cout << "---------------------------" << std::endl;
    rng::for_each( rng::adjacent_find(l, is_consecutive), print_out);

    std::cout << "---------------------------" << std::endl;
    // print all elements that are equal to 6.
    rng::for_each( rng::equal_range( l, 6), print_out);

    
    return 0;
}

#endif
