
#include <boost/rangelib/range.hpp>
#include <boost/rangelib/multi.hpp>
#include <boost/rangelib/slice_byeach.hpp>
#include <boost/rangelib/algo.hpp>
using namespace boost::rangelib;
#include <time.h>
#include <boost/format.hpp>
#include <map>
#include <string>
#include <iostream>

namespace {
// represents details about items that's been sold
struct sold_items_info {
    sold_items_info( const char * item, time_t t, int items, const char * customer)
        : item_name(item), sold_at_time(t), items_count(items), customer_name(customer) {}

    std::string item_name;
    time_t sold_at_time;
    // how many items did we sell
    int items_count;
    // to whom we sold?
    std::string customer_name;
};



bool slice_into_days( const sold_items_info & first, const sold_items_info & second) {
    tm details1= *localtime(&first.sold_at_time);
    tm details2 = *localtime(&second.sold_at_time);
    return details1.tm_year == details2.tm_year && 
        details1.tm_yday == details2.tm_yday;
}


/////////////////////////////////////////////////////////
// showing how many items of each kind were bought each day

struct item_summary {
    time_t day;
    std::map< std::string, int> items;
};
void add_item_summary( item_summary & summary, sold_items_info & info) {
    summary.day = info.sold_at_time;
    summary.items[ info.item_name] += info.items_count;
}

void show_item_summary( const item_summary & summary) {
    tm details = *localtime(&summary.day);
    crange< const std::map<std::string,int> > r( summary.items);
    if ( r) {
        std::cout << (boost::format("On %d-%d-%d, we've sold:") % (details.tm_year+1900) % (details.tm_mon+1) % details.tm_mday) << std::endl;
        while (r) {
            std::cout << "    " << r->second << ' ' << r->first << "(s)" << std::endl;
            ++r;
        }
    }
    else
        std::cout << (boost::format("On %d-%d-%d, there was no shopping.") % (details.tm_year+1900) % (details.tm_mon+1) % details.tm_mday) << std::endl;
}



struct normalize_days {
    normalize_days() : m_prev(-1) {}

    typedef item_summary first_argument_type;
    bool operator()( item_summary & dest, const item_summary & val, int idx) {
        bool different_days = false;
        if ( m_prev != -1) {
            m_prev += 24*60*60;
            tm prev_day = *localtime( &m_prev);
            tm now = *localtime( &val.day);
            different_days = prev_day.tm_yday != now.tm_yday || prev_day.tm_year != now.tm_year;
        }

        if ( different_days) {
            // return intermediate day
            dest = item_summary();
            dest.day = m_prev;
        }
        else {
            // return it, and go to next day
            dest = val;
            m_prev = val.day;
        }
        return different_days ? true : false;
    }

    time_t m_prev;
};

} // namespace



void use_multi_byeach() {
    std::vector< sold_items_info> v;
    time_t now = time(0);
    // ... 8 days ago
    v.push_back( sold_items_info( "Soap", now - 8*24*60*60 - 5684, 5, "John" ) );
    v.push_back( sold_items_info( "TV", now - 8*24*60*60 - 2684, 2, "Matt" ) );
    v.push_back( sold_items_info( "Soap", now - 8*24*60*60 - 1384, 10, "Frank" ) );
    v.push_back( sold_items_info( "sofa", now - 8*24*60*60 - 684, 1, "Frank" ) );
    v.push_back( sold_items_info( "computer", now - 8*24*60*60 - 73, 3, "Cathy" ) );
    v.push_back( sold_items_info( "TV", now - 8*24*60*60, 1, "Irene" ) );
    // ... 7 days ago
    v.push_back( sold_items_info( "speaker", now - 7*24*60*60 - 6543, 4, "Cathy" ) );
    v.push_back( sold_items_info( "phone", now - 7*24*60*60 - 3885, 3, "Mary" ) );
    v.push_back( sold_items_info( "Soap", now - 7*24*60*60 - 2543, 6, "Mary" ) );
    v.push_back( sold_items_info( "speaker", now - 7*24*60*60 - 235, 20, "James" ) );
    v.push_back( sold_items_info( "TV", now - 7*24*60*60 - 25, 5, "Cathy" ) );
    // ... 4 days ago
    v.push_back( sold_items_info( "hard-disk", now - 4*24*60*60 - 7522, 10, "Irene" ) );
    v.push_back( sold_items_info( "computer", now - 4*24*60*60 - 6552, 3, "Bill" ) );
    v.push_back( sold_items_info( "laptop", now - 4*24*60*60 - 4522, 5, "Irene" ) );
    v.push_back( sold_items_info( "TV", now - 4*24*60*60 - 2322, 1, "Francis" ) );
    v.push_back( sold_items_info( "phone", now - 4*24*60*60 - 522, 1, "Ford" ) );
    // ... one day ago
    v.push_back( sold_items_info( "phone", now - 1*24*60*60 - 3478, 3, "Shrek" ) );
    v.push_back( sold_items_info( "sofa", now - 1*24*60*60 - 2668, 1, "Matt" ) );
    v.push_back( sold_items_info( "speaker", now - 1*24*60*60 - 1478, 3, "John" ) );
    v.push_back( sold_items_info( "phone", now - 1*24*60*60, 1, "Mary" ) );
    // ... around now
    v.push_back( sold_items_info( "laptop", now - 3443, 1, "Sue" ) );
    v.push_back( sold_items_info( "cd", now - 2445, 30, "Monica" ) );
    v.push_back( sold_items_info( "laptop", now - 1343, 2, "John" ) );
    v.push_back( sold_items_info( "laptop", now - 38, 20, "Monica" ) );

    /* Output:

        On 2003-12-3, we've sold:
            15 Soap(s)
            3 TV(s)
            3 computer(s)
            1 sofa(s)
        On 2003-12-4, we've sold:
            6 Soap(s)
            5 TV(s)
            3 phone(s)
            24 speaker(s)
        On 2003-12-5, there was no shopping.
        On 2003-12-6, there was no shopping.
        On 2003-12-7, we've sold:
            1 TV(s)
            3 computer(s)
            10 hard-disk(s)
            5 laptop(s)
            1 phone(s)
        On 2003-12-8, there was no shopping.
        On 2003-12-9, there was no shopping.
        On 2003-12-10, we've sold:
            4 phone(s)
            1 sofa(s)
            3 speaker(s)
        On 2003-12-11, we've sold:
            30 cd(s)
            23 laptop(s)
    */
    // showing how many items of each kind were bought each day
    rng::for_each( multied_byeach(
            sliced_byeach(v, rng::fun<item_summary>(&add_item_summary), &slice_into_days), 
            normalize_days() ),
        show_item_summary);
}


#if defined(USING_MULTI_BYEACH)

int main() {
    use_multi_byeach();
    return 0;
}

#endif
