
#include <boost/rangelib/indirect.hpp>
#include <boost/rangelib/filter.hpp>
#include <boost/rangelib/algo.hpp>

#include <vector>
#include <iostream>
#include <algorithm>
#include <list>
#include <iterator>

using namespace boost::rangelib;

namespace {
    struct next {
        next() : m_i(0) {}
        int operator() () { return m_i++; }
    private:
        int m_i;
    };
    bool is_even(int i) { return (i%2) == 0; }
    void new_obj( int* & p) { p = new int; }
}


void use_indirect() {
    typedef std::list<int*> array;
    array l;
    l.resize( 50);
    // allocate
    rng::for_each( l, new_obj);
    rng::generate( indirected(l), next() );
    rng::reverse( indirected(l));

    std::cout << "print all numbers " << std::endl;
    rng::copy( indirected(l), std::ostream_iterator<int>(std::cout," ") );
    std::cout << "print all EVEN numbers " << std::endl;
    rng::copy( filtered(indirected(l),&is_even), std::ostream_iterator<int>(std::cout," ") );

    // same thing as above, only now, one number per line
    std::cout << "print all numbers " << std::endl;
    indirected_range<array> r(l);
    while (r) {
        std::cout << *r++ << std::endl;
    }
}



#if defined(USING_INDIRECT)

int main() {
    use_indirect();
}

#endif
