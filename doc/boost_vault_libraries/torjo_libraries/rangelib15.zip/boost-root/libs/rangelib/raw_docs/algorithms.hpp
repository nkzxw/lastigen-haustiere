
/** 

@page algorithms Range Algorithms


- @ref algorithms_rng 
- @ref algorithms_i_  
- @ref algorithms_ret_range 
- @ref algorithms_extra 
    - @ref algorithms_extra_erase 
    - @ref algorithms_extra_erase_current 
    - @ref algorithms_extra_coll_find 
    - @ref algorithms_extra_advanced 




@section algorithms_rng rng:: algorithms


@code
#include <boost/rangelib/algorithm.hpp>
@endcode

After easing working with @ref basics "manual loops", it's time to ease working with STL algorithms.

@b Every STL algorithm has a @c rng:: conterpart, which, instead of requiring two iterators,
requires a range:

@code
typedef std::vector<std::string> word_array;
word_array v;

// STL version
std::copy( v.begin(), v.end(), print);

// rng:: version
rng::copy( v, print);

@endcode

For the purpose of @c rng:: algorithms, containers are considered to be ranges <em>by default</em>.

@code
typedef std::vector<std::string> word_array;
word_array v;

rng::copy( v, print);
@endcode

Whenever an STL algorithm would require two ranges, the STL algorithms either:
@li require at least 4 iterator parameters (begin1, end1, begin2, end2).
An example of such algorithm is std::find_end. <br>
For the rng:: algorithm, pass 2 range parameters instead.
@li require at least 3 iterator parameters (begin1, end1, begin2). 
In this case, the 2nd range is assumed to be equal in length to the first. <br>
For the rng:: algorithm, again, pass 2 range parameters instead.

Example:

@code
// 4 arguments
std::string str = "I'm a cool programmer, really cool that is", search = "cool";

// STL version
std::find_end( str.begin(), str.end(), search.begin(), search.end() );

// rng:: version
rng::find_end( str, search);


// 3 arguments

// STL version
typedef std::vector<int> array;
array v1, v2, v3;
// ... fill v1 and v2; v1 and v2 have the same size

// STL version
std::transform( v1.begin(), v1.end(), v2.begin(), std::back_inserter(v3), std::max<int>);

// rng:: version
rng::transform( v1, v2, std::back_inserter(v3), std::max<int>);
@endcode


@section algorithms_i_  The i_ or i_param shortcut

As said above, some STL algorithms, when needing two ranges, require 3 parameters: begin1, end1, begin2; 
in which case, they assume the two ranges are of equal size.

Sometimes, for the second range, you will indeed have only one iterator variable (as opposed to a range variable).
In this case, use @c i_ or the @c i_param shortcut:


@code

using boost::filesystem;
std::vector<path> cached;
// ... fill cached

directory_iterator dest("c:/my_path");

if ( rng::equal( cached, i_(dest)) )
    std::cout << "I have all cached files" << std::endl; 

@endcode


@section algorithms_ret_range Algorithms that return a range

STL algorithms that return an iterator (such as std::find, std::find_if, etc.) can be much improved. 
Based on how these algorithms are used, we can conclude that usually, you'll use such an iterator to do either of:
- walk from it to the end of the range (or container)
- test if this is a valid iterator or not. 

In order to ease that, the rng:: algorithm counterpars, by default, return a range: from the found iterator,
up to the @c end().

@code

// [1] (walk from found, up to the end)

// filling a vector with all the indexes at which a certain string is found
std::string str = "I'm a cool programmer, really cool that is", find = "cool";

std::vector<int> result;
crange<std::string> r(str);
while ( r = rng::search(r, find)) 
    result.push_back ( r.begin() - str.begin() );

// [2] test if it's a valid iterator or not

// find if string exists within another string
std::string str = "I'm a cool programmer", find = "cool";
bool I_am_cool = rng::search(str, find);

@endcode

Just in case returning a range is not wheat you need, you can configure what you want to be returned:
- @c iter: return only the iterator (as the STL counterpart)
- @c from_beg: return the <tt>[container.begin(), found)</tt> range
- @c to_end: return the <tt>[found, container.end())</tt> range (this is the default)

@code
typedef std::vector<int> array;
array v;
// assume using boost.assign library
v += 1, 5, 7, 9, 11, 21, 23, 25, 31, 37, 71;

// (default behavior)
// returns the [11, 21, 23, 25, 31, 37, 71, end()) range
crange<array> r1 =rng::find(v, 11);

// returns the iterator where '11' was found
array::iterator i2 = rng::find<iter>(v, 11);

// returns the [1, 5, 7, 9, 11) range (11 is not included in this range)
crange<array> r3 = rng::find<from_beg>(v, 11);

// returns the [11, 21, 23, 25, 31, 37, 71, end()) range
crange<array> r4 =rng::find<to_end>(v, 11);


// (default behavior)
// returns the [v.end(), v.end()) range (since 12 is not found)
crange<array> r5 =rng::find(v, 12);

// returns v.end()
array::iterator i6 = rng::find<iter>(v, 12);

// returns the whole 'v' (since 12 is not found)
crange<array> r7 = rng::find<from_beg>(v, 12);

// returns the [v.end(), v.end()) range (since 12 is not found)
crange<array> r8 =rng::find<to_end>(v, 12);

@endcode



@section algorithms_extra Extra algorithms

In addition all of the STL algorithms, we've provided a few extra helpers. 

@section algorithms_extra_erase rng::erase algorithm 

Syntax:
@code
template<class container, class r> void erase( container & c, const crange<r> & rng);

// equivalent to:
// c.erase( rng.begin(), rng.end() );
@endcode

It erases the whole range from the container. It is very useful when dealing with 
removal algorithms:

@code
typedef std::vector<int> array;
array v;
// assume using boost.assign library
v += 1, 5, 5, 7, 9, 9, 9, 11, 11, 21, 23, 23, 25;

// after executing this, v will contain: { 1, 5, 7, 9, 11, 21, 23, 25 } elements
rng::erase( v, rng::unique(v) );

@endcode


@section algorithms_extra_erase_current rng::erase_current algorithm

Syntax:
@code
template<class container, class r> crange<r> erase_current(container & c, const crange<r> & rng);
@endcode

From the container c, it erases the current element and returns the remaining range. What this means is:
@li for a non-associative ccntainer, it performs an erase(), and after that, it returns an iterator pointing
to the element that used to be after the erased element.
@li for an associative container, it performs an equivalent to: <br>
iterator it = rng.begin(); <br>
++rng; <br>
c.erase(it); <br>

Example:

@code

// [1] (non-associative)

typedef std::vector<int> array;
array v;
// assume using boost.assign library
v += 1, 5, 7, 9, 11, 21, 23, 25, 31, 37, 71;

crange<array> r = find(v, 11);
r = erase_current(v, r);
// now:
// v is { 1, 5, 7, 9, 21, 23, 25, 31, 37, 71 }
// r is             [ 21, 23, 25, 31, 37, 71 , end())


// [2] (associative)

typedef std::map<int,std::string> coll;
coll c;
c[1] = "one"; c[2] = "two", c[4] = "four"; c[5] = "five";

// r points to {4, "four"} element
crange<coll> r = rng::coll_find(c, 4);

r = erase_current(c, r);
// now:
// v is { {1, "one"}, {2, "two"}, {5, "five"}}
// r is                          [{5, "five"}, end())

@endcode

Note: many thanks to Thorsten Ottosen for suggesting this really cool algorithm.


@section algorithms_extra_coll_find rng::coll_find algorithm

Syntax:
@code
template< class container, class value_type> crange<container>
coll_find( [const] container & c, const value_type & val)
@endcode


The coll_find is a shortcut for finding an element in a collection (non-associative array).
It returns a range from the found element to the end() of the collection, or an empty range, if
the element was not found.


Example:

@code

typedef std::map<int,std::string> coll;
coll c;
c[1] = "one"; c[2] = "two", c[4] = "four"; c[5] = "five";

// r is [ {4, "four"}, {5, "five"}, end() ) 
crange<coll> r = rng::coll_find(c, 4);

@endcode


@section algorithms_extra_advanced rng::advanced algorithm

Syntax:

@code
template< class iterator, class Distance> iterator advanced( iterator i, Distance n);
@endcode

It advances an iterator, and retuns the newly advanced position. 

It is useful for creating fixed ranges (note: @c std::advance returns @c void).

@code
typedef ... array;
array v;
// ... fill v

// contains the first 10 elements from v.
crange<array> r10( v.begin(), rng::advanced(v.begin(),10));

// note: the following will only work for random iterators
// crange<array> r10( v.begin(), v.begin() + 10);

@endcode


*/


