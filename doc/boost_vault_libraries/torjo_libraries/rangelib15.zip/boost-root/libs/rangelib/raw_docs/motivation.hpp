/**
@page motivation Motivation

STL came up with a novel idea: separate algorithms from the containers.
So, iterators were born. They have proven to be of tremendous use,
but, in not trivial cases, they become hard to use, and mostly redundant:

@code
// writing some_array twice...
std::for_each( some_array.begin(), some_array.end(), print);
@endcode

Not only are they hard to use in algorithms, the resulting code is not as compact as it should be,
and more often than not, it is hard to read and write. 

A lot of times, when you manipulate a container, extra
data you need to manipulate is local to the function and/or scope you're in. 
Thus, you will most likely end up coding a manual loop, which again
is hard to write, read and error-prone:

@code
// ... and what about a loop inside another loop?
for ( some_array_type::iterator begin = some_array.begin(), end = some_array.end(); begin != end; ++begin)
   do_something( *begin, some_other_data);
@endcode

And every now and then, you end up with buggy code:

@code
std::vector<int> a, b;
// ... fill them

// ... notice the bug?
std::copy(a.begin(), b.end(), print);
@endcode

To solve the above, Iterable Ranges were born (@ref motivation_note1).

Simply put, an Iterable Range is a smarter @c std::pair<iterator,iterator>.

Everything becomes much more simple, here's a taste:

@code
rng::for_each( some_array, print);

for ( crange<some_array_type> r(some_array); r; ++r)
    do_something( *r, some_data);
@endcode




<hr>
Notes:

@section motivation_note1 [1]

They are part of a larger concept, which includes: Notional Range, Iterable Range,
and Indirect Range. You can find out all about it here:
@htmlonly <a href="http://rangelib.org">http://rangelib.org</a> @endhtmlonly


*/
