
/** 
@page adaptors Range Adaptors and Composition(s)

This is the most powerful part of this library: the ability to adapt iterators, and to perform compostion(s).

A <tt>range adaptor</tt> adapts an iterator, in order to be used in range algorithms and/or composed.

In other words, the code will be much simpler, more compact and easier to read and write:

@code
typedef ... array;
array some_array;
// ... fill v

// [1] print all even elements (not using range adaptors)
typedef boost::filter_iterator<array> filter_iterator;
rng::for_each( irange<filter_iterator>( 
    filter_iterator(some_array.begin(), is_even), 
    filter_iterator( some_array.end(), is_even), print );


// [2] print all even elements (using range adaptors)
rng::for_each( filtered(some_array, is_even), print);
@endcode

Besides the fact that it's clearly much easier to use a range adaptor instead of its raw iterator counterpart,
now range composition is possible (before ranges, it was very hard to compose iterators):

@code
struct employee {
    std::string name;
    std::string country;
    // ...
};


bool from_ro(const employee & e) { return e.country == "Romania"; }
std::string get_empl_name(const employee &e) { return e.name; } 

typedef std::vector<employee> array;
array empls;

// take all employees from Romania, and print their names
rng::copy( transformed( filtered(empls,from_ro), get_empl_name),
    std::ostream_iterator<std::string>(std::cout," "));

// can you guess how the above would look like without range adaptors?

@endcode

Here's what we've already provided:

- <tt>filtered( range, predicate)</tt>. Returns a range that contains only the elements int 
  the original range that match the given predicate.
- <tt>transformed( range, func)</tt>. For each element in the original range, 
  applies @c func and returs the result.
- <tt>breaked( range, predicate)</tt>. Returns the original range up-to the 
  first time when <tt>predicate(*iterator)</tt> returns false. 
  Similar to a manual-loop with an internal <tt>if (!predicate(*iter)) break;</tt>.
- <tt>indirected( range)</tt>. Dereferences each element in the range. 
  Useful when you have a container of pointers, and want to manipulate the pointed values.
- <tt>resorted( range [,pred])</tt>. Returns the original range re-sorted, 
  leaving the original range unchanged.
- <tt>reversed( range)</tt>. Returns the original range reversed (from rbegin() to rend() ).
- <tt>generated( generator, stopper_pred)</tt>. Creates a range by using 
  a generator() function (similar to std::generate/ std::generate_n algorithms). 
  After generating one element, the stopper_pred is asked if it should 
  generate more elements. The range ends when stopper_pred returns false.

In order to use any of the above, just @c #include the header corresponding 
to the function name (without the ed suffix). 
For instance, for filtered algorithm,
@code
#include <boost/rangelib/filter.hpp>
@endcode

FIXME slice_byeach/ slice_byrange, multi_byeach, multi_byrange


Examples:

@code
// *************** Using breaked

std::vector<int> v;
// assume using boost.assign library
v += 1, 5, 7, 22, 11, 21, 23, 25, 31, 37, 71;

// will print: "1 5 7 22"
rng::copy( breaked(v, bk_after(4) ), std::ostream_iterator<int>(std::cout, " ") );



// *************** Using generate

struct fibonacci {
    typedef int result_type;
    int operator()() { ... }
};

std::vector<int> v;
// v will contain the first 20 fibonnacci numbers
std::copy( generated( fibonacci(), gen_n(20)), std::back_inserter(v) );


// *************** Using resorted

std::ifstream in( "./in.txt");
std::vector<std::string> words;
// read all words from the file, and insert them into the array
rng::copy( istream_range<std::string>(in), std::back_inserter(words));

// print the sorted words, while the 'words' array remains *unchanged*
rng::copy( resorted(words), std::ostream_iterator<std::string>(std::cout," ") );


@endcode



FIXME istream_range

FIXME more examples + explain about _range classes.

*/


