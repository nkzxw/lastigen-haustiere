
/** 

@mainpage Boost. Iterable Range Library (rangelib) - Index

Note: these are beta docs, and we're trying to improve it as much as I can. <br>
We welcome all feedback. 

- @ref motivation
- @ref basics
- @ref crange_vs_irange
- @ref algorithms
    - @ref algorithms_rng 
    - @ref algorithms_i_  
    - @ref algorithms_ret_range 
    - @ref algorithms_extra 
        - @ref algorithms_extra_erase 
        - @ref algorithms_extra_erase_current 
        - @ref algorithms_extra_coll_find 
        - @ref algorithms_extra_advanced 
- @ref adaptors
- @ref examples
- @ref acknowledgements

*/
