/** 

@page acknowledgements Acknowledgements

Many thanks to Thorsten Ottosen for collaborating with us, giving us food for thought, and quite a few suggestions.

Also, many thanks to Vladimir Prus and Neal D. Becker for feedback and suggestions.





*/