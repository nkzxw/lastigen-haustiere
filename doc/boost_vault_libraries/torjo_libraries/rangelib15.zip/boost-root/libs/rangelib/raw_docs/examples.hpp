/** 
@page examples Examples

There are quite a few examples coming with this library.

They're found in the usual place: <br> @c boost-root/libs/rangelib/examples 

Check them out, and know the of course, we welcome all feedback.

*/
