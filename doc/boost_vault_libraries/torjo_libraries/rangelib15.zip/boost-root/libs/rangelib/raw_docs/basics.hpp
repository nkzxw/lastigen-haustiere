namespace boost { namespace rangelib { 

/** 
@page basics Range Basics (Manual Loops)

@code
#include <boost/rangelib/range.hpp>
@endcode

Again, an Iterable Range is a smarter std::pair<iterator,iterator>, made of 
the <tt>begin()</tt>inig of the range, and the <tt>end()</tt>ing of the range.

To keep it simple, I'll use 'range' from now on, to denote 'Iterable Range',
unlesss stated otherwise.

First step in making work easier with containers is coding manual loops.

@code
typedef std::vector<std::string> word_array;
word_array strs;
// ... fill it

int words_len = 0;
for ( crange<word_array> r(strs): r; ++r)
    words_len += r->length();
@endcode


@attention
You can think of a range as a smarter iterator, one that knows when to stop (when it reaches its @c end() ).
When operating on a range, it's as if you're operating on its @c begin() iterator.

On any range, you can do the following operations:
- ask if a range has reached its end, by calling its <tt>operator bool()</tt>
- derefence the range, just like dereferencing an iterator, by calling its <tt>operator*()</tt>

@code
typedef std::vector<std::string> word_array;
crange<word_array> r = ...;

std::string str;
// ask if the range has reached its end
if ( r)
    str = *r; // dereference the range
@endcode


The range preserves the underlying iterator category 
(@c input_iterator_tag, @c forward_iterator_tag, etc.). In other words:
- if the underlying iterator provides operator--, so will the range
- if the underlying iterator provides operator+=, so will the range
- and so on

Every range is composed of two iterators (@c begin() and @c end()).
You can access/modify each of them. If @c r is a range, then:
- @c r.begin() - returns the range's begin
- @c r.end() - returns the range's end
- @c r.begin(new_begin) - resets the range's begin
- @c r.end(new_end) - resets the range's end


*/

}}
