namespace boost { namespace rangelib { 

/** 
@page crange_vs_irange Two range classes: crange and irange (Manual Loops)

Usually, when coding ranges manually (as opposed to using them in algorithms), you'll be happy with crange
(shortcut for <b>C</b>ontainer <b>range</b>).

Syntax:

@code
// uses the container_type::iterator
crange<container_type> r = ...;

// uses the container_type::const_iterator
crange<const container_type> r = ...;
@endcode

You can construct a @c crange from:
- a container
- two iterators
- a std::pair<iterator,iterator>
- another range

Example:

@code
typedef std::vector<std::string> word_array;

void nonconst_func(word_array & v) {
    // uses word_array::iterator
    for ( crange<word_array> r(v); r; ++r)
        *r = "same";
}

void const_func(const word_array & v) {
    int len_sum = 0;
    // uses word_array::const_iterator
    for ( crange<const word_array> r(v.begin(), v.begin() + v.size()/2); r; ++r)
        len_sum += r->size();
}

@endcode

However, at times, you won't get to know the container type, but rather, only the iterator type 
(this can sometimes happen in generic code).
In such a case, use @c irange class instead (shortcut for <b>I</b>terator <b>range</b>). It works like @c crange, but its syntax is:

@code
irange<iterator_type> r = ...;
@endcode

You construct an @c irange from:
- two iterators
- a std::pair<iterator,iterator>

Example:

@code
template<class iterator> int distance(iterator first, iterator last) {
    int dist = 0;
    for ( irange<iterator> r( first, last); r; ++r, ++dist);
    return dist;
}
@endcode

The only differences between @c irange and @c crange are:
- at definition (crange uses the container type to determine the iterator, while irange uses the iterator type directly)
- at construction

Other than that, manipulating @c irange and @c crange follow the same syntax.

As you proably guessed, you can always use irange instead of crange (while the reverse is not true):

@code
typedef std::vector<std::string> word_array;
word_array v;

// the following are equivalent
crange<word_array> r( v);
irange<word_array::iterator> r( v.begin(), v.end() );
@endcode

You should prefer @c crange whenever possible, since as you can see, its syntax is more compact.

*/

}}
