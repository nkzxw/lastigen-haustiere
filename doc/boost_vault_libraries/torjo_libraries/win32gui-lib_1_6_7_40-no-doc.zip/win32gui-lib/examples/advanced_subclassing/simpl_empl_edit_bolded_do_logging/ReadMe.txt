This takes the example from controls/simpl_empl_edit_bolded_dlg,
and subclasses everything.

It shows you how easy it is to do advanced subclassing.

In this sample, I do these subclassings:
- I subclass *all* windows
- I subclass all edit controls
- I subclass all buttons

Since it's a very simple example, all it does is write (very innefficiently)
to a file.

The file to look for it all is subclass_some_windows.cpp
