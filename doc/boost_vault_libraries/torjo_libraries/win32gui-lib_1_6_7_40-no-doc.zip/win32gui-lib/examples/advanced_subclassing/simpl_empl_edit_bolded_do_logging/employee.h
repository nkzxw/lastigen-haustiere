#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>

typedef enum status_type {
    not_married = 0,
    married = 1,
    divorced = 2,
    widowed = 3,
    undisclosed = 4,
    
};


struct employee {
    employee() : id(0), salary(0), has_homepage(false), status(undisclosed), birth_date(0) {
    }

    std::string first_name;
    std::string last_name;
    int id;
    unsigned long salary;

    time_t birth_date;

    std::string country;
    std::string address;
    std::string email;

    bool has_homepage;
    std::string homepage;

    status_type status;
};

#endif
