// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#ifndef SAMPLE_STDAFX_H
#define SAMPLE_STDAFX_H

#pragma warning (disable : 4244) // VC has a really stupid time_t...


#include <win32gui/window.hpp>

// Win32GUI Window base class 
using win32::gui::window_base;
using win32::gui::create_wnd;
// ... null window
using win32::gui::null_wnd;

// for extending windows/dialogs
using win32::gui::wnd_extend;

// Dialog class
using win32::gui::dialog;
using win32::gui::create_dlg;
using win32::gui::create_modal_dlg;

// Resizing Ability
using win32::gui::resizable_wnd;

// STL
#include <map>
#include <vector>
#include <string>
#include <algorithm>

#endif
