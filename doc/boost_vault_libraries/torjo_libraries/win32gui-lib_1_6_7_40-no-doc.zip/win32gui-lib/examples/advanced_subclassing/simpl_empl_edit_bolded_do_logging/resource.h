//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sample_start.rc
//
#define IDC_MYICON                      2
#define IDD_SAMPLE_START_DIALOG         102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_SAMPLE_START                107
#define IDI_SMALL                       108
#define IDC_SAMPLE_START                109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_SAMPLE                      129
#define IDD_empl                        129
#define ID_first_name                   1000
#define IDC_EDIT2                       1001
#define ID_last_name                    1001
#define IDC_has_hp                      1002
#define IDC_hp                          1003
#define ID_salary                       1004
#define ID_id                           1005
#define ID_country                      1006
#define ID_address                      1007
#define ID_email                        1008
#define IDC_status                      1009
#define IDC_LIST1                       1010
#define IDC_status2                     1011
#define IDC_DATETIMEPICKER1             1012
#define IDC_birth                       1012
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
