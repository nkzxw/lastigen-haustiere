#pragma once

#include <win32gui/wnd_extend/save_dlg.hpp>
#include "employee.h"

struct ui_empl : win32::gui::save_dlg::corresp {
    ui_empl(employee & empl);

    void init(win32::gui::save_dlg&);
    void save();
    void init_ctrl(win32::gui::wnd<> & w);

private:
    employee & m_empl;
    // note: when making the corresponence, we CANNOT add an enumerator type (status_type).
    int m_status;
};
