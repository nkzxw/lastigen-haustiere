#include "StdAfx.h"
#include <win32gui/event_handler.hpp>
#include <win32gui/controls.hpp>
#include <fstream>
#include <sstream>

using namespace win32::gui;

// all events, from all windows
struct global_handler_all : subclass::auto_event_handler<global_handler_all, window_base> {

    handle_event any_event(msg_param msg, hwnd_param h) {
        std::ofstream out ("all.txt", std::ios::out | std::ios::app);
        std::stringstream msg_out; msg_out << "[all] got event " << msg << " for " << h << std::endl;
        ::OutputDebugString( msg_out.str().c_str() );
        out << msg_out.str();
        return event<0>().HANDLED_BY(&me::any_event);
    }
};


// all events, from all edit controls
struct global_handler_edit : subclass::auto_event_handler<global_handler_edit, edit> {

    handle_event any_event(msg_param msg, hwnd_param h) {
        std::ofstream out ("edit.txt", std::ios::out | std::ios::app);
        std::stringstream msg_out; msg_out << "[edit] got event " << msg << " for " << h << std::endl;
        ::OutputDebugString( msg_out.str().c_str() );
        out << msg_out.str();
        return event<0>().HANDLED_BY(&me::any_event);
    }
};


// all events, from all buttons
struct global_handler_button : subclass::auto_event_handler<global_handler_button, button> {

    handle_event any_event(msg_param msg, hwnd_param h) {
        std::ofstream out ("button.txt", std::ios::out | std::ios::app);
        std::stringstream msg_out; msg_out << "[button] got event " << msg << " for " << h << std::endl;
        ::OutputDebugString( msg_out.str().c_str() );
        out << msg_out.str();
        return event<0>().HANDLED_BY(&me::any_event);
    }
};




