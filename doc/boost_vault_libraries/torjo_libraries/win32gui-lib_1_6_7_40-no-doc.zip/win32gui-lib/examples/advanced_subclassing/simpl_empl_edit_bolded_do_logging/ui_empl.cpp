#include "StdAfx.h"
#include ".\ui_empl.h"
#include "resource.h"
#include <win32gui/controls.hpp>

using namespace win32::gui;
void at_least_6_chars( const std::string & old_name, std::string & new_name, save_dlg::info<employee> & info) {
    if ( new_name.length() < 6)
        info.error = "Name too small (should have at least 6 chars)";
}

void what( const std::string & old_name, std::string & new_name, save_dlg::info_base & info) {
    info.on_cancel_answer = save_dlg::oncancel_ask_yesnocancel;
    info.on_cancel_question = "Saving?";
}

void salary_too_big( const unsigned long & , unsigned long & new_salary, save_dlg::info_base & info) {
    if ( new_salary > 40000)
        info.error = "You wish you had this salary (max salary - 40000)!";
}

void salary_too_small( const unsigned long & , unsigned long & new_salary, save_dlg::info_base & info) {
    if ( new_salary < 10000)
        info.error = "Are you working for free?";
}

struct in_range {
    in_range(const std::string & name, int min_val, int max_val) : name(name), min_val(min_val), max_val(max_val) {}
    typedef int member_type;
    typedef save_dlg::info_base member_class;

    void operator() (const int &, int & val, save_dlg::info_base& info) const {
        if (val >= min_val && val <= max_val) return;
        std::ostringstream out;
        out << name << " is not in the [" << min_val << ", " << max_val << "] range!";
        info.error = out.str();
    }
private:
    int min_val, max_val;
    std::string name;
};


ui_empl::ui_empl(employee & empl) : m_empl(empl) {
    add_var(empl);
    add_corresp( &employee::first_name, ID_first_name);
    add_corresp( &employee::last_name, ID_last_name);
    add_corresp( &employee::birth_date, IDC_birth);

    add_corresp( &employee::id, ID_id);
    add_corresp( &employee::salary, ID_salary);
    add_corresp( &employee::country, ID_country);
    add_corresp( &employee::address, ID_address);
    add_corresp( &employee::email, ID_email);

    add_corresp( &employee::has_homepage, IDC_has_hp);
    add_corresp( &employee::homepage, IDC_hp);

    add_validator(ID_first_name, at_least_6_chars);
    add_validator(ID_last_name, at_least_6_chars);

    add_validator(ID_salary, salary_too_big);
    add_validator(ID_salary, salary_too_small);
    add_validator(ID_id, in_range("Employee ID", 10000, 11000) );

    // on cancel, ask the user if he wants to save...
    add_validator(ID_first_name, what, validate::on_cancel);
}

void ui_empl::init_ctrl(wnd<> & w) {
    switch ( w->dlg_ctrl_id() ) {
    case IDC_status:
        if ( wnd<combo_box> c = try_cast<combo_box>(w) ) {
            c->add_item("Not married");
            c->add_item("Married");
            c->add_item("Divorced");
            c->add_item("Widowed");
            c->add_item("Undisclosed (VIP)");
        }
     break;
    }
}

void ui_empl::init(save_dlg&) {
    m_status = m_empl.status;
    add_corresp( &m_status, IDC_status);
}
void ui_empl::save() {
    m_empl.status = (status_type)m_status; // hold it internally as an enumerator
}

