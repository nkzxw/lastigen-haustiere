Just like simpl_empl_edit_bolded_win32gui_spy,
just that this time spy.cpp is included per se.
