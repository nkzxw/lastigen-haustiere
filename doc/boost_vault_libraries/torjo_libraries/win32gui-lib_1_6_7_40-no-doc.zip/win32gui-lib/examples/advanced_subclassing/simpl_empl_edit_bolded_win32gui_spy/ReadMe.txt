Takes the controls/simpl_employee_bold example,
and spies it ;)

You should note that only *2 lines of code* were
done, in order to allow spying.

Take it for a spin, run win32gui_spy on it, and enjoy ;)

