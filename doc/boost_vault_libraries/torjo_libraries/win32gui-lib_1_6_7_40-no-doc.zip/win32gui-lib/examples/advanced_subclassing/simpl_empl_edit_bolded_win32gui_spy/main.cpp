// sample_start.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "ui_empl.h"
#include "resource.h"
#include <sstream>
#include <win32gui/wnd_extend/bolded_save_dlg.hpp>

// line 1
//
// Note: depending on your application, you can also choose to include
// win32gui/spy/spy.cpp as a source file in your project, and where you enable_spy(),
// simply #include <win32gui/spy/spy.hpp> 
//
// (notice the difference from including a header or a source file)
#include <win32gui/spy/spy.cpp>

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
    using namespace win32::gui;

    // line 2
    enable_spy();

    employee john;
    john.first_name = "John";
    john.last_name = "Doe";
    john.birth_date = mktime_t(1978, one_month(2), 15); // 15th of Feb, 1978
    john.id = 5;
    john.salary = 100000;
    john.has_homepage = true;
    john.homepage = "www.myhome.com";

    ui_empl ui(john);
    create_modal_save_dlg<bolded_save_dlg>(IDD_empl, ui, null_wnd);

    std::ostringstream out;
    out << "You have chosen: \n"
        << "\nName: " << john.first_name << ' ' << john.last_name 
        << "\nID: " << john.id
        << "\nSalary " << john.salary
        << "\nCountry: " << john.country
        << "\nAddress: " << john.address
        << "\nEmail: " << john.email
        << "\nHas homepage: " << (john.has_homepage ? "yes" : "no")
        << "\nHomepage: " << john.homepage
        << "\nStatus: " << john.status;
    msg_box(null_wnd, out.str() );
}
