
#include <win32gui/frame.hpp>
#include <win32gui/event_handler.hpp>
#include <win32gui/controls.hpp>
#include "resource.h"
#include "sample_dlg.h"


using namespace win32::gui;
struct automap_frame : wnd_extend<mdi_frame, automap_frame> {
    automap_frame() : extend_base("Sample Frame - demonstrates auto-mapping") {}
};

struct automap_frame_handler : event_handler<automap_frame_handler, mdi_frame, automap_frame> {
    automap_frame_handler() {
        post_command(ID_TEST_NEWVIEW);
    }

    handle_event on_new_view() {
        create_dlg<sample_dlg>( top_wnd<automap_frame>()->create_mdi_child() );
        return command<ID_TEST_NEWVIEW>().HANDLED_BY(&me::on_new_view);
    }

    handle_event disable_all_buttons() {
        for ( wnd_iterator<button> begin = find_wnd_range<button>(), end; begin != end; ++begin)
            if ( begin->is_real_button() ) begin->enable(false);
        return command<ID_TEST_DISABLEALLBUTTONS>().HANDLED_BY(&me::disable_all_buttons);
    }

    handle_event enable_all_buttons() {
        for ( wnd_iterator<button> begin = find_wnd_range<button>(), end; begin != end; ++begin)
            if ( begin->is_real_button() ) begin->enable(true);
        return command<ID_TEST_ENABLEALLBUTTONS>().HANDLED_BY(&me::enable_all_buttons);
    }
};



using namespace win32::gui;
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR lpCmdLine, int nCmdShow) {
    create_wnd<automap_frame>( null_wnd, create_info().menu(IDC_AUTO_MAPPING))->wait();
}

