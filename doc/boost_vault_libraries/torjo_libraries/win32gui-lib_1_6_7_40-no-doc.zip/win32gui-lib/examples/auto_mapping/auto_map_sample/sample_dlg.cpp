#include ".\sample_dlg.h"
#include "resource.h"
#include <win32gui/controls.hpp>
using namespace win32::gui;

sample_dlg::sample_dlg() : extend_base("Sample") {
    // select a radio button
    child<radio_button>(IDC_opt_one)->check();

    // select check boxes
    child<check_box>(IDC_chk_one)->check();
    child<check_box>(IDC_chk_two)->check(false);
}

sample_dlg::~sample_dlg() {
}

int sample_dlg::dialog_id() { return IDD_SAMPLE; }



