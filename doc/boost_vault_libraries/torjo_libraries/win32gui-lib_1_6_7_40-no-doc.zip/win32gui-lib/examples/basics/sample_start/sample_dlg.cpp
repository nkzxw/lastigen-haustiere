#include "stdafx.h"
// sample_dlg.cpp


// note: for v1.6.3+, you should try to use the Resource Splitter
// comment this line, and uncomment the following one
#include "resource.h"
// #include "win32gui_res/sample.hpp"
#include "sample_dlg.h"

using namespace win32::gui;


struct sample_dlg_handler : event_handler<sample_dlg_handler, sample_dlg> {
};


sample_dlg::sample_dlg() {
}

sample_dlg::~sample_dlg() {
}

// note: for v1.6.3+, you should try to use the Resource Splitter
// comment this line, and uncomment the following one
int sample_dlg::dialog_id() { return IDD_SAMPLE; }
// int sample_dlg::dialog_id() { return dialog_id_; }
