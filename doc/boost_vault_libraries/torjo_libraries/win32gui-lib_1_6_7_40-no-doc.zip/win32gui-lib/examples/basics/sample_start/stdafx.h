// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//
#ifndef SAMPLE_STDAFX_H
#define SAMPLE_STDAFX_H

#include <win32gui/window.hpp>
#include <win32gui/controls.hpp>
#include <win32gui/event_handler.hpp>
#include <win32gui/frame.hpp>

// Win32GUI Window base class 
using win32::gui::window_base;
using win32::gui::create_wnd;
// ... null window
using win32::gui::null_wnd;

// for extending windows/dialogs
using win32::gui::wnd_extend;

// Dialog class
using win32::gui::dialog;
using win32::gui::create_dlg;
using win32::gui::create_modal_dlg;

// for defining event handlers
using win32::gui::event_handler;

// Resizing Ability
using win32::gui::resizable_wnd;

// Frames
using win32::gui::view_frame;
using win32::gui::sdi_frame;
using win32::gui::mdi_frame;

// STL
#include <map>
#include <vector>
#include <string>
#include <algorithm>

#endif

