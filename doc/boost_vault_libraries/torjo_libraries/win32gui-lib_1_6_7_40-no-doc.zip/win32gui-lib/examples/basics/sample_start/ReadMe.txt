Note:

I use this as shortcut, when creating new SAMPLE projects, etc.

Think of it as just a trivial Wizard for when implementing a new win32gui project.

Note: I've used the stdafx precompiled header file and included quite a few win32gui header files.
I also brought some names into the global namespace. 

If you use it as a start-up in your code, please take a look at it, and remove what you don't need.
