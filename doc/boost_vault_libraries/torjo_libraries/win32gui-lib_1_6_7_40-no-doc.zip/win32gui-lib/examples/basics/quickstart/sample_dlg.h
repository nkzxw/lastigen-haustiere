// sample_dlg.h
#include <win32gui/window.hpp>
struct sample_dlg : win32::gui::wnd_extend<win32::gui::dialog,sample_dlg> {
    sample_dlg();
    static int dialog_id();
};
