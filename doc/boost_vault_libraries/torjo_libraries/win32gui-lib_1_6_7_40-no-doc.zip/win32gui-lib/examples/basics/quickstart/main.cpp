// main.cpp
#include <win32gui/frame.hpp>
#include <win32gui/window.hpp>
#include "sample_dlg.h"
#include "resource.h"

using namespace win32::gui;
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int) {
    wnd<> top = create_wnd<sdi_frame>( "MyFrame", null_wnd, create_info().menu(IDR_my_app));
    create_dlg<sample_dlg>(top);
    top->wait();
}
