//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by quickstart.rc
//
#define IDC_MYICON                      2
#define IDD_QUICKSTART_DIALOG           102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDI_QUICKSTART                  107
#define IDI_SMALL                       108
#define IDC_QUICKSTART                  109
#define IDR_my_app                      109
#define IDR_MAINFRAME                   128
#define IDD_SAMPLE                      129
#define IDC_CHECK1                      1000
#define IDC_EDIT1                       1001
#define ID_new_view                     32772
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
