// sample_dlg.cpp
#include "resource.h"
#include "sample_dlg.h"
#include <win32gui/event_handler.hpp>
#include <win32gui/frame.hpp>
using namespace win32::gui;

struct sample_dlg_handler 
    : event_handler<sample_dlg_handler,sample_dlg> {

    handle_event on_new_view() {
        wnd<> view = create_dlg<sample_dlg>( top_parent());
        top_parent<sdi_frame>()->activate( view);
        return command<ID_new_view>().HANDLED_BY(&me::on_new_view);
    }
};

sample_dlg::sample_dlg() : extend_base("View") {}

int sample_dlg::dialog_id() { return IDD_SAMPLE; }
