Simple example of how reflectable classes work, if you're using Resource Splitter.

Check out the only dialog resource, 
and look at the ID names of the hyper_link and lite_html:
- IDC_link_typeis_hyper_link
- IDC_description_typeis_lite_html
