Shows how easy it is to create hyperlinks
at *dialog design time*