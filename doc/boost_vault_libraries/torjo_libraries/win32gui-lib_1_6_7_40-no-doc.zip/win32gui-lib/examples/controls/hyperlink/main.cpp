#include <win32gui/window.hpp>
#include "resource.h"

int APIENTRY WinMain(HINSTANCE , HINSTANCE , LPTSTR, int) {
    using namespace win32::gui;
    create_modal_dlg<dialog>(null_wnd, create_info().id(IDD_SAMPLE) )  .wait();
}
