
#include <win32gui/wnd_extend/save_dlg.hpp>
#include <fstream>
#include <iostream>
#include <sstream>
#include "resource.h"
using namespace win32::gui;

struct html_info {
    std::string txt;
    std::string html;
};

void on_change(const std::string &, std::string & new_val, save_dlg::info<html_info> & info) {
    info.new_val.html = info.new_val.txt;
}
void on_cancel(const std::string &, std::string & new_val, save_dlg::info<html_info> & info) {
    info.on_cancel_answer = save_dlg::oncancel_do_save_and_close;
}

int APIENTRY WinMain(HINSTANCE , HINSTANCE , LPTSTR, int) {
    html_info sample;

    { std::ifstream in("lite_text.txt");
    std::ostringstream out;
    out << in.rdbuf();
    sample.html = out.str();
    if ( sample.html.empty() )
        sample.html = "<font color=blue><font size=+5><b>Welcome</b></font><br>into the wold of win32gui</font>";
    }
    sample.txt = sample.html;

    create_modal_save_dlg(IDD_SAMPLE, save_dlg::corresp()
        .add_var( sample)
        .add_corresp( &html_info::txt, ID_text)
        .add_corresp( &html_info::html, ID_litehtml1)
        .add_validator( ID_text, &on_change, validate::on_change)
        .add_validator( ID_text, &on_cancel, validate::on_cancel), null_wnd);

    std::ofstream out("lite_text.txt");
    out << sample.html;
}
