An easy way to create and text your lite HTML strings, 
before putting them on labels.

You can create the text here, and when it's ready, just copy/paste
it into a lite_html (label) control.
