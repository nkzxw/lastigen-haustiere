//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sample_start.rc
//
#define IDC_MYICON                      2
#define IDD_SAMPLE_START_DIALOG         102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_SAMPLE_START                107
#define IDI_SMALL                       108
#define IDC_SAMPLE_START                109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_SAMPLE                      129
#define IDR_rclick                      130
#define ID_user_name                    1000
#define ID_passw                        1001
#define ID_remember                     1002
#define ID_logon_grroup                 1003
#define IDC_CHECK1                      1004
#define ID_turn_off                     1004
#define ID_mon                          1005
#define ID_tue                          1006
#define ID_wed                          1007
#define ID_thu                          1008
#define ID_fri                          1009
#define ID_sat                          1010
#define ID_sun                          1011
#define ID_SUBMENU0_OTHERS              32774
#define ID_rclick_me                    32777
#define ID_rclick_you                   32778
#define ID_rclick_him                   32779
#define ID_rclick_them                  32780
#define ID_rclick_another               32781
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
