#include "stdafx.h"
// sample_dlg.cpp
#include "resource.h"
#include "sample_dlg.h"
#include <win32gui/event_handler.hpp>
#include <win32gui/res.hpp>
#include <win32gui/controls.hpp>

using namespace win32::gui;


struct sample_dlg_handler : event_handler<sample_dlg_handler, dialog, sample_dlg> {

    handle_event on_rclick() {
        menu<owned> m(IDR_rclick);
        m.sub_menu(0).run_popup(cursor_pos(), window());
        return event<WM_RBUTTONUP>().HANDLED_BY(&me::on_rclick);
    }

    // in case you want to turn off tooltip(s)
    handle_event on_showing_tip(l_param<showing_tooltip_arg*> arg) {
        if ( child<check_box>(ID_turn_off)->is_checked() )
            arg->tip.text = "";
        return event<WM_SHOWING_TIP>().HANDLED_BY(&me::on_showing_tip);
    }
};


namespace {
    tooltip_text sunday() {
        tooltip_text tip("Poor thing...");
        tip.title = "Working on sunday?";
        return tip;
    }
}

sample_dlg::sample_dlg() {
    tip_text(ID_remember, &sample_dlg::remember_str);
    tip_text(ID_me, &sample_dlg::pos_as_str);

    // days of the week
    add_tip_ctrl( create_wnd<tooltip_ctrl>(this,create_info().add_style(TTS_BALLOON)), "days");
    tip_ctrl(ID_mon, "days");
    tip_ctrl(ID_tue, "days");
    tip_ctrl(ID_wed, "days");
    tip_ctrl(ID_thu, "days");
    tip_ctrl(ID_fri, "days");
    tip_ctrl(ID_sat, "days");
    tip_ctrl(ID_sun, "days");
    tip_text(ID_sun, sunday);

    // "Turn off" checkbox
    wnd<tooltip_ctrl> turn_off = create_wnd<tooltip_ctrl>(this,create_info().add_style(TTS_BALLOON));
    turn_off->bg_color( color().blue(255) );
    turn_off->text_color( color(255,255,255) ); 
    add_tip_ctrl(turn_off, "off");
    tip_ctrl(ID_turn_off, "off");
}

sample_dlg::~sample_dlg() {
}

int sample_dlg::dialog_id() { return IDD_SAMPLE; }    

std::string sample_dlg::pos_as_str() const {
    return str_stream() << "x= " << cursor_pos().x << " ,y= " << cursor_pos().y;    
}


std::string sample_dlg::remember_str() const {
    return child<check_box>(ID_remember)->is_checked() ? "We remember you..." : "You'll need to logon next time too...";
}

