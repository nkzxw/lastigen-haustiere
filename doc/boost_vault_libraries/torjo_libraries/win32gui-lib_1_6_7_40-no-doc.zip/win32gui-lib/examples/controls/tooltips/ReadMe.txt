Shows how easy it is to use tooltips.

You can even have multiple types of tooltips in the same dialog.
And you can turn them off extremely easy.

And by the way, are you working on sunday?

