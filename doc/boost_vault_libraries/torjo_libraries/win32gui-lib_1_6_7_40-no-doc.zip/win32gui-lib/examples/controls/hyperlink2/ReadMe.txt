Shows how easy it is to create hyperlinks
at *dialog design time*.

Besides the regular hyperlinks, which when you click
on them do a "ShellExecute", you can use the text "click"
(as a link), in which case the link will generate a BN_CLICKED command
(it will behave as a button).

