// sample_dlg.h
#ifndef SAMPLE_DLG_H
#define SAMPLE_DLG_H

struct sample_dlg : wnd_extend<dialog,sample_dlg> {
    sample_dlg();
    ~sample_dlg();
    static int dialog_id();
};

#endif
