//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sample_start.rc
//
#define IDC_MYICON                      2
#define IDD_SAMPLE_START_DIALOG         102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_SAMPLE_START                107
#define IDI_SMALL                       108
#define IDC_SAMPLE_START                109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_SAMPLE                      129
#define ID_hyperlink                    1000
#define ID_splitter1                    53248
#define ID_splitter2                    53249
#define ID_splitter3                    53250
#define ID_splitter4                    53251
#define ID_splitter5                    53252
#define ID_splitter6                    53253
#define ID_splitter7                    53254
#define ID_splitter8                    53255
#define ID_splitter9                    53256
#define ID_splitter10                   53257
#define ID_splitter11                   53258
#define ID_splitter12                   53259
#define ID_splitter13                   53260
#define ID_splitter14                   53261
#define ID_splitter15                   53262
#define ID_splitter16                   53263
#define ID_splitter17                   53264
#define ID_splitter18                   53265
#define ID_splitter19                   53266
#define ID_splitter20                   53267
#define ID_splitter21                   53268
#define ID_splitter22                   53269
#define ID_splitter23                   53270
#define ID_splitter24                   53271
#define ID_splitter25                   53272
#define ID_splitter26                   53273
#define ID_splitter27                   53274
#define ID_splitter28                   53275
#define ID_splitter29                   53276
#define ID_splitter30                   53277
#define ID_hyperlink1                   53278
#define ID_hyperlink2                   53279
#define ID_hyperlink3                   53280
#define ID_hyperlink4                   53281
#define ID_hyperlink5                   53282
#define ID_hyperlink6                   53283
#define ID_hyperlink7                   53284
#define ID_hyperlink8                   53285
#define ID_hyperlink9                   53286
#define ID_hyperlink10                  53287
#define ID_hyperlink11                  53288
#define ID_hyperlink12                  53289
#define ID_hyperlink13                  53290
#define ID_hyperlink14                  53291
#define ID_hyperlink15                  53292
#define ID_litehtml1                   53293
#define ID_litehtml2                   53294
#define ID_litehtml3                   53295
#define ID_litehtml4                   53296
#define ID_litehtml5                   53297
#define ID_litehtml6                   53298
#define ID_litehtml7                   53299
#define ID_litehtml8                   53300
#define ID_litehtml9                   53301
#define ID_litehtml10                  53302
#define ID_litehtml11                  53303
#define ID_litehtml12                  53304
#define ID_litehtml13                  53305
#define ID_litehtml14                  53306
#define ID_litehtml15                  53307
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
