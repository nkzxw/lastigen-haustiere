Shows how easy it is to create a lite-html control
at *dialog design time*.

Also note that the only code in this sample is to create the dialog:
"create_modal_dlg<dialog>(null_wnd, create_info().id(IDD_SAMPLE) )  .wait();"
