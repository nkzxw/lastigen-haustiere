... Yes. The bitmap_button automatic handling works even for 
message boxes !!!
