// main.cpp 
#include <win32gui/frame.hpp>
#include "resource.h"

using namespace win32::gui;

int APIENTRY WinMain(HINSTANCE , HINSTANCE , LPTSTR , int ) {
    signal res = create_modal_dlg<dialog>(null_wnd,create_info().id(IDD_ask_type)).wait(wait_for::any_button_pushed).result;
    int question_type = MB_YESNO;
    if ( res == signal::cmd(IDC_yesno))
        question_type = MB_YESNO;
    else if ( res == signal::cmd(IDC_yesnocancel))
        question_type = MB_YESNOCANCEL;
    else if ( res == signal::cmd(IDC_okcancel))
        question_type = MB_OKCANCEL;
    else if ( res == signal::cmd(IDC_ok))
        question_type = MB_OK;


    msg_box(null_wnd, "How's that?", "Bitmap button", question_type);
}
