// sample_start.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "sample_dlg.h"

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
    create_modal_dlg<sample_dlg>(null_wnd)  .wait();
}
