Example of how easy it is to have nice bitmap buttons, with no code.
(only by using the Resource Editor)
