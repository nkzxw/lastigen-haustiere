#include "stdafx.h"
// sample_dlg.cpp
#include "resource.h"
#include "sample_dlg.h"
#include <win32gui/event_handler.hpp>
#include <win32gui/controls.hpp>

using namespace win32::gui;


struct sample_dlg_handler : event_handler<sample_dlg_handler, dialog, sample_dlg> {
    handle_event on_use_hot_track() {
        bool use = child<check_box>(ID_use_hot_track)->is_checked();
        for ( wnd_iterator<bitmap_button> begin = find_wnd_range<bitmap_button>(),end; begin != end ;++begin)
            begin->hot_track(use);
        return command<ID_use_hot_track>().HANDLED_BY(&me::on_use_hot_track);
    }

    handle_event on_toggle_green() {
        child(ID_green_house)->enable( !child(ID_green_house)->is_enabled() );
        return command<ID_toggle_green,BN_CLICKED>().HANDLED_BY(&me::on_toggle_green);
    }
    handle_event on_toggle_red() {
        child(ID_red_house)->enable( !child(ID_red_house)->is_enabled() );
        return command<ID_toggle_red,BN_CLICKED>().HANDLED_BY(&me::on_toggle_red);
    }
    handle_event on_toggle_blue() {
        child(ID_blue_house)->enable( !child(ID_blue_house)->is_enabled() );
        return command<ID_toggle_blue,BN_CLICKED>().HANDLED_BY(&me::on_toggle_blue);
    }
};


sample_dlg::sample_dlg() {
}

sample_dlg::~sample_dlg() {
}

int sample_dlg::dialog_id() { return IDD_SAMPLE; }
    