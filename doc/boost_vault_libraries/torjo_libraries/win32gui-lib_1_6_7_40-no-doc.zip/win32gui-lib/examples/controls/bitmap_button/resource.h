//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by sample_start.rc
//
#define IDC_MYICON                      2
#define IDD_SAMPLE_START_DIALOG         102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_SAMPLE_START                107
#define IDI_SMALL                       108
#define IDC_SAMPLE_START                109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_SAMPLE                      129
#define ID_red_house                    130
#define ID_green_house                  131
#define ID_blue_house                   132
#define ID_toggle_green                 133
#define ID_toggle_red                   134
#define ID_green_house4                 135
#define ID_toggle_blue                  135
#define ID_green                        136
#define ID_print                        137
#define ID_red                          138
#define ID_sound                        140
#define ID_yellow                       141
#define IDC_BUTTON2                     1001
#define ID_red_house2                   1001
#define IDC_BUTTON3                     1002
#define IDC_RADIO1                      1002
#define IDC_CHECK1                      1003
#define ID_use_hot_track                1003
#define IDC_CHECK3                      1008
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
