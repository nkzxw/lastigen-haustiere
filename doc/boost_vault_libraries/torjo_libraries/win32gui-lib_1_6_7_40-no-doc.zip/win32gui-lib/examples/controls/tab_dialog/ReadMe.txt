Tab dialogs - a smarter tab control.

You can also add dialogs/controls on a tab-dialog
at dialog design time.

Just a few easy steps - try it out and you'll see...
