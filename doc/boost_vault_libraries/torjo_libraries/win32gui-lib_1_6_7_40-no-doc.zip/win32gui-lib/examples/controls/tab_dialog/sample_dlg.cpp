#include "stdafx.h"
// sample_dlg.cpp
#include "resource.h"
#include "sample_dlg.h"
#include <win32gui/event_handler.hpp>
#include <win32gui/controls.hpp>

using namespace win32::gui;


struct sample_dlg_handler : event_handler<sample_dlg_handler, dialog, sample_dlg> {

    handle_event on_full_area() {
        bool full = child<check_box>(ID_full_area)->is_checked();
        sub_wnd<tab_dialog>()->full_area(full);
        return command<ID_full_area,BN_CLICKED>().HANDLED_BY(&me::on_full_area);
    }
};


sample_dlg::sample_dlg() {
    child<splitter>(ID_splitter2)->sizing(splitter::sizing_left_only);
}

sample_dlg::~sample_dlg() {
}

int sample_dlg::dialog_id() { return IDD_SAMPLE; }
    