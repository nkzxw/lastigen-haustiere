
// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#include "StdAfx.h"
#include ".\main_dlg.h"
#include "ui/frame_in_dialog.h"
#include "ui/files_dlg.h"
#include "resource.h"

using namespace win32::gui;

struct main_dlg_handler : event_handler<main_dlg_handler, main_dlg> {

    handle_event on_next() {
        find_wnd<files_dlg>()->send_command(ID_next_rc); // forward...
        return command<ID_next_rc>().HANDLED_BY(&me::on_next);
    }

    handle_event on_prev() {
        find_wnd<files_dlg>()->send_command(ID_prev_rc); // forward...
        return command<ID_prev_rc>().HANDLED_BY(&me::on_prev);
    }

    handle_event on_about() {
        create_modal_dlg<dialog>(self, create_info().id(IDD_ABOUTBOX) )  .wait();
        return command<ID_about>().HANDLED_BY(&me::on_about);
    }

    handle_event on_exit() {
        ::PostQuitMessage(0);
        return command<ID_exit>().HANDLED_BY(&me::on_exit);
    }

    handle_event on_tray_msg(l_param<int> msg) {
        if ( msg == WM_LBUTTONDOWN)
            toggle_show();
        if ( msg == WM_RBUTTONDOWN) {
            menu<owned> tray_mnu(IDR_rclick);
            tray_mnu.sub_menu(0).item_byid(ID_TRAY_SHOW, 
                menuitem_info().text(self->is_visible() ? "Hide" : "Show") );

            tray_mnu.sub_menu(0).run_popup( cursor_pos(), self, TPM_LEFTALIGN | TPM_BOTTOMALIGN);
        }
        return event<WM_TRAY_MSG>().HANDLED_BY(&me::on_tray_msg);
    }
    handle_event on_tray_showhide() {
        toggle_show();
        return command<ID_TRAY_SHOW>().HANDLED_BY(&me::on_tray_showhide);
    }

private:
    void toggle_show() {
        wnd<> top = top_parent();
        if ( top->is_visible() ) top->show(SW_HIDE);
        else {
            top->set_foreground();
            top->show();
        }
    }

};



main_dlg::main_dlg(void) : tray(raw_hwnd(), "Resource Splitter", IDI_SMALL) {
    child<splitter>(ID_splitter1)->sizing( splitter::sizing_bottom_only);
    mapping::replace_wnd<frame_in_dialog>( child(ID_cur_file) );
}

main_dlg::~main_dlg(void)
{
}


int main_dlg::dialog_id() {
    return IDD_main;
}

namespace { 
    using_dialog<main_dlg> using_;
}
