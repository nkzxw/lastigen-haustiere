
// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#include "stdafx.h"
#include "resource.h"

#include "parse_rc/parse_rc.h"
#include "parse_rc/parse_resource_h.h"
#include "parse_rc/parse_win32gui_rc2.h"
#include "split_into_files.h"
#include "template_file.h"
#include "util/string_util.h"
#include <direct.h>

#include "ui/main_dlg.h"
#include "ui/app_frame.h"
#include "util/cmd_line_util.h"
#include "persist_sl/registry_setting_storage.h"
#include "persist_sl/file_setting_storage.h"
using namespace persist;

void persist::on_initialize_default_config(configuration & cfg) {
#ifdef NDEBUG
    cfg.add_storage( "", new registry_setting_storage("CU/Software/WIN32GUI/Resource Splitter"));
#else
    // debugging...
    char buff[1024];
    _getcwd(buff,1024);
    cfg.add_storage( "", new file_setting_storage( std::string(buff) + "/rs.ini"));
#endif
}



void process_cmd_line() {
    std::string file_name = cmd_line().args()[1];
    try {
        fs::path dir = fs::path(file_name).branch_path();

        template_file_coll templ_coll = load_templates();
        rc_info rc = parse_rc_file( file_name);
        resource_h_info resource_h = parse_resource_h_file( (fs::path(file_name).branch_path() / "resource.h").string() );

        rc2_info rc2;
        rc2.read_from_file( (fs::path(file_name).branch_path() / "win32gui_res/win32gui.rc2").string(), resource_h);

        header_coll files = split_into_files( rc, resource_h, rc2, templ_coll);
        files = get_diff_files( header_coll(), files );
        write_diff_files( files, fs::path(file_name).branch_path().string() );
    } catch(...) {}
}



using namespace win32::gui;
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR, int) {
//    fs::path::default_name_check( fs::no_check);
    fs::path::default_name_check( fs::native);
    bool is_run_as_startup = false;
    if ( cmd_line().args().size() > 1) {
        is_run_as_startup = cmd_line().args()[1] == "-startup";
        if ( !is_run_as_startup) {
            // testing - just process the first argument...
            process_cmd_line();
            return 0;
        }
    }

    sdi_frame::set_class_info( sdi_frame::get_class_info().icon(IDI_SMALL) );
    wnd<sdi_frame> top = create_wnd<app_frame>( null_wnd );
    top->set_min_width( 670);
    top->set_min_height( 400);

    // toolbar
    wnd<rebar> rb = create_wnd<rebar>(top);
    wnd<toolbar> tools = create_wnd<toolbar>(IDR_actions, top);
    rb->add_band( rebar_band_info()
        .band_min_sizes(200, 24)
        .text("Actions:  ")
        .child(tools) );

    create_dlg<main_dlg>(top);
    if ( is_run_as_startup) {
        // workaround - I need to do this, so that the rebar is shown correctly
        top->wait(wait_for::destroy, 500);
        top->show(window_::show::hide);
    }
    top->wait();
    return 0;
}

