
// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#pragma once
#include "shellapi.h"
#include "template_file.h"

struct files_dlg_handler;

struct files_dlg : wnd_extend<dialog, files_dlg> {
    friend struct files_dlg_handler;

    files_dlg(void);
    ~files_dlg(void);
    static int dialog_id();

    void on_drop_files(HDROP h);

private:
    void add_file( const std::string & full_file_name);
    void load_files();
    void save_files();
    void select_file_at_idx(int idx);

private:
    bool has_files() const;
    void set_has_files(bool) {} // dummy - so that I can use has_files in set_cmd_enabler...

public:
    // if 1 - we're monitoring the files...
    // if 0 - we're not monitoring the files...
    int is_monitoring;

private:
    // templates - for when creating the files...
    template_file_coll m_file_templates;

};
