#pragma once

// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#include "template_file.h"

// forward declare
struct rc_info;
struct resource_h_info;
struct rc2_info;

// key:   the name of the file to generate
// value: the content of the file to generate
typedef std::map<std::string, std::string> header_coll;


header_coll split_into_files( const rc_info & rc, const resource_h_info & resource_h, const rc2_info & rc2, const template_file_coll & template_files);

header_coll get_diff_files(const header_coll & old_coll, const header_coll & new_coll);
void write_diff_files(const header_coll & coll, const std::string & dest_path);

std::string resource_type_to_type(const std::string & type);

