#pragma once


// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/


/*
    Represents a view frame that can be sitted within a dialog.

    It also inherits the good things of a view_frame - being able to reference a child window by name.
*/
struct frame_in_dialog :    wnd_extend<win32::gui::view_frame, frame_in_dialog>,
                            wnd_extend<win32::gui::children_all_area, frame_in_dialog> {

    static win32::gui::create_info def_create_info();
    frame_in_dialog();

    virtual void activate(win32::gui::hwnd_proxy hwnd);

private:
    HWND m_active_wnd; // the active window
};

