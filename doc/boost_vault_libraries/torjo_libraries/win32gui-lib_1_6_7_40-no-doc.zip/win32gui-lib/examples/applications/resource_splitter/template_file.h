#pragma once

// Key:   the name of the template file
// Value: the text of the template file
typedef std::map<std::string, std::string> template_file_coll;

template_file_coll load_templates();

