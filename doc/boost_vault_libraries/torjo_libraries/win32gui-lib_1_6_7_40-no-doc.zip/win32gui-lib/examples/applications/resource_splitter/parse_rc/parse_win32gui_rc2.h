#ifndef PARSE_RC2_HPP
#define PARSE_RC2_HPP

// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

struct rc_info ; 
struct resource_h_info;


struct rc2_info {
    // dialog_id -> script
    /* 
        VERY IMPORTANT:

        In the .rc2 file, we always keep dialog information by their dialog ID (an integer value).

        This is to guard against the fact that the user might rename a certain dialog.
        For example, he could rename the dialog IDD_titi into IDD_mumu.

        When we parse the .rc2 file, we would encounter something like:
        "IDD_titi RCDATA". But what if we can't find IDD_titi in the resource.h file?

        To guard against that, the simplest way is to keep the dialog ID as an integer from the beginning.
        So, if you take a look at an .rc2 file, you could see something like:
        "103 RCDATA".
    */
    typedef std::map<std::string, std::string> script_coll;

    typedef std::map<std::string, std::string> subclassing_coll;
    typedef std::map<std::string, std::string> window_to_surface_coll;

    void read_from_file(const std::string & file_name, const resource_h_info & resource_h);
    std::string write_to_str(const rc_info & rc, const resource_h_info & resource_h) const;

    std::string script(const std::string & dialog_id) const;
    void script(const std::string & dialog_id, const std::string & value);

    bool needs_recompute() const;
private:
    void process_subclassing(const rc_info & rc, const resource_h_info & resource_h) const;
    void process_window_to_surface(const rc_info & rc, const resource_h_info & resource_h) const;

private:
    script_coll m_scripts;

    // the string that should be written into an .rc2 file
    // since computing it could be expensive, we're caching it.
    mutable std::string m_str;

    // for a dialog_id -> if it needs subclassing + its window-to-surface correspondences
    mutable subclassing_coll m_subclassing;
    mutable window_to_surface_coll m_window_to_surface;
};



#endif
