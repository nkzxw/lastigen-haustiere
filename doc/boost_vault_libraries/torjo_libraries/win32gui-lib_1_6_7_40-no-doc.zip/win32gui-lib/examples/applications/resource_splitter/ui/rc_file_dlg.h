#pragma once


// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#include "template_file.h"
#include "split_into_files.h"
#include <win32gui/res.hpp>
#include "parse_rc/parse_win32gui_rc2.h"
#include "parse_rc/parse_resource_h.h"
#include "parse_rc/parse_rc.h"

struct rc_file_dlg_handler;

struct rc_file_dlg : wnd_extend<dialog, rc_file_dlg>, wnd_extend<resizable_wnd, rc_file_dlg> {
    typedef win32::gui::is_not_default_constructible construct_type;

    rc_file_dlg(const std::string & rc_file_name, const template_file_coll & file_templates);
    ~rc_file_dlg(void);
    static int dialog_id();

    void reload();

private:
    void log(const std::string & msg);
    std::string m_last_log_msg;

    void update_rc_tree(const rc_info & rc, const resource_h_info & resource_h);

private:
    friend struct rc_file_dlg_handler ;

    // name of the file we're monitoring...
    std::string m_rc_file_name;
    // ... and its corrsponding resource.h file...
    std::string m_resource_h_file_name;
    // ... and its corrsponding win32gui.rc2 file...
    std::string m_rc2_file_name;

    // templates - for when creating the files...
    template_file_coll m_file_templates;

    // the latest files - to write to HDD
    header_coll m_files;

    // the dialogs
    HTREEITEM m_dialogs_root;
    // the menus
    HTREEITEM m_menus_root;
    // the menu items
    HTREEITEM m_menu_items_root;
    // the Script root
    HTREEITEM m_script_root;

    // for an item, if it's a dialog, find out its dialog ID
    typedef std::map<HTREEITEM, std::string> item_to_dialog_id;
    item_to_dialog_id m_item_to_dialog_id;

    win32::gui::image_list<win32::gui::owned> m_tree_imgs;
    win32::gui::image_list<win32::gui::owned> m_list_imgs;

    // for fast comparison - see if anything changed...
    std::string m_old_rc_text;
    std::string m_old_resource_h_text;

    // information in the .rc & .h files
    rc_info m_rc;
    resource_h_info m_resource_h;

    // information to write into .rc2 - this includes the script that is shown in the right.
    // In others words, if the user changes the script, we should update the .rc2 file...
    rc2_info m_rc2;
};

