#pragma once

// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#include <win32gui/nonregular_wnd/tray_wnd.hpp>

/*
    Orchestrates the main logic
*/
struct main_dlg : wnd_extend<dialog, main_dlg> {
    main_dlg(void);
    ~main_dlg(void);

    static int dialog_id();

private:
    win32::gui::tray_wnd tray;
};
