#pragma once

// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/



// key:   ID name
// value: ID value
// Example: Key (ID_passw) -> Value (24103)
typedef std::map<std::string, std::string> name_to_value_coll;

// reverse of the above
typedef std::map<std::string, std::string> value_to_name_coll;

/*
    Contains information parsed from the resource.h file
*/
struct resource_h_info {
    resource_h_info ();

    name_to_value_coll m_name_to_value;
    // note: there might be multiple values mapped to a certain name...
    //       we only care about the last one...
    value_to_name_coll m_value_to_name;
};

bool operator==(const resource_h_info & a, const resource_h_info & b);



resource_h_info parse_resource_h_file(const std::string & file_name);

