#include "StdAfx.h"
#include ".\app_frame.h"
#include "util/version.h"

using namespace win32::gui;

struct app_frame_handler : event_handler<app_frame_handler, app_frame> {

    handle_event on_minimize(w_param<> status, mark_event_not_handled, answer a) {
        if ( status == SC_MINIMIZE) {
            self->show( window_::show::hide);
            a = event_is_handling;
        }
        return event<WM_SYSCOMMAND>().HANDLED_BY(&me::on_minimize);
    }

};

namespace {
    // helper - return our current version...
    std::string cur_version() {
        version::info ver;
        version::get_file_info(ver);
        return str_stream() << "v" << ver.major_ver << "." << ver.minor_ver << "." << ver.build_no;
    }

}

app_frame::app_frame(void) : extend_base( "Resource Splitter " + cur_version() ) {
}

app_frame::~app_frame(void)
{
}
