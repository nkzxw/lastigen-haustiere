For internal use only.
I use this and include the win32GUI source files as well. This makes it easier for me to recompile when I make small changes to the library.

