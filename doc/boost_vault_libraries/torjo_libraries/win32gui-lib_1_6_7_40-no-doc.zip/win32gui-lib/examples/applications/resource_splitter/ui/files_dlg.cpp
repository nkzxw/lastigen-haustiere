
// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#include "StdAfx.h"
#include ".\files_dlg.h"
#include "resource.h"
#include "ui/rc_file_dlg.h"
#include "ui/frame_in_dialog.h"

using namespace win32::gui;

struct files_dlg_handler : event_handler<files_dlg_handler, files_dlg> {
    enum {
        WM_LOAD_FILES = WM_APP + 1
    };

    void on_full_create() {
        // note: at this time, the frame-in-dialog is not created yet...
        post_msg(WM_LOAD_FILES);
    }

    handle_event on_load_files() {
        self->load_files();
        return event<WM_LOAD_FILES>().HANDLED_BY(&me::on_load_files);
    }

    handle_event on_drop_files(w_param<HDROP> h) {
        self->on_drop_files(h);
        return event<WM_DROPFILES>().HANDLED_BY(&me::on_drop_files);
    }

    handle_event on_next() {
        int idx = child<combo_box>(ID_rc_files)->sel() + 1;
        if ( idx >= child<combo_box>(ID_rc_files)->item_count() )
            idx = 0;
        self->select_file_at_idx(idx);

        return command<ID_next_rc>().HANDLED_BY(&me::on_next);
    }

    handle_event on_prev() {
        int idx = child<combo_box>(ID_rc_files)->sel() - 1;
        if ( idx < 0)
            idx = child<combo_box>(ID_rc_files)->item_count() - 1;
        self->select_file_at_idx(idx);

        return command<ID_prev_rc>().HANDLED_BY(&me::on_prev);
    }

    handle_event on_select() {
        int idx = child<combo_box>(ID_rc_files)->sel();
        self->select_file_at_idx(idx);
    
        return command<ID_rc_files,CBN_SELCHANGE>().HANDLED_BY(&me::on_select);
    }

    handle_event on_del() {
        std::string text = child(ID_rc_files)->text();
        if ( text.empty() ) return event_handled_early;

        bool do_del = msg_box(self, "Do you want to stop monitoring the\n" + text + " file?", "Stop Monitoring", MB_YESNO) == IDYES;
        if ( do_del) {
            find_wnd<frame_in_dialog>()->activate(null_wnd); // first, deactivate it...
            wnd<> to_del = find_wnd<frame_in_dialog>()->find_by_name(text);
            to_del->destroy();

            // remove it from the combo as well...
            wnd<combo_box> rc_files = child<combo_box>(ID_rc_files);
            int idx = rc_files->sel(); 
            rc_files->del_item(idx);
            if ( rc_files->item_count() > 0) 
                self->select_file_at_idx(0);
            self->save_files();
        }

        return command<ID_del>().HANDLED_BY(&me::on_del);
    }
};


files_dlg::files_dlg(void) {
    // load the file templates
    m_file_templates = load_templates();

    is_monitoring = 1;
    set_cmd_chooser( &files_dlg::is_monitoring, this)
        .for_id(ID_do_monitor, 1)
        .for_id(ID_do_not_monitor, 0);

    // FIXME bug here! - if uncomment this, the ID_*_rc commands won't be issued, even if they're enabled!
//    set_cmd_enabler( ID_next_rc, &files_dlg::has_files, &files_dlg::set_has_files, this);
//    set_cmd_enabler( ID_prev_rc, &files_dlg::has_files, &files_dlg::set_has_files, this);
}

files_dlg::~files_dlg(void)
{
}

bool files_dlg::has_files() const {
    return child<combo_box>(ID_rc_files)->item_count() > 0;
}


int files_dlg::dialog_id() {
    return IDD_files;
}


void files_dlg::on_drop_files(HDROP h) {
    int files_count = DragQueryFile(h, (UINT)-1, 0, 0);
    for ( int idx = 0; idx < files_count; ++idx) {
        int chars = DragQueryFile(h, idx, 0, 0);
        std::string file;
        file.resize( chars + 1);
        DragQueryFile(h, idx, &*file.begin(), chars + 1);
        if ( !file.empty() && file.end()[-1] == 0) file.erase( file.end() - 1); // erase ending '\0'
        add_file( file);
    }
    DragFinish(h);
    save_files();
}

void files_dlg::add_file(const std::string & file_name) {
    std::string full_file_name = fs::system_complete(file_name).string(); // make sure we're complete...

    if ( fs::extension(full_file_name) != ".rc") {
        msg_box(this, "Not an .rc file!", "Error", MB_OK | MB_ICONERROR);
        return;
    }

    // add it if not already exists...
    wnd<view_frame> frame = find_wnd<frame_in_dialog>();
    wnd<> w = frame->try_find_by_name(full_file_name);
    if ( !w)
        w = create_dlg<rc_file_dlg>( full_file_name, m_file_templates, frame );
    frame->activate(w);

    // update the combo...
    if ( child<combo_box>(ID_rc_files)->find_str_exact(full_file_name) < 0) {
        child<combo_box>(ID_rc_files)->add_item(full_file_name);
        child<combo_box>(ID_rc_files)->select_str(full_file_name);
    }
}


// loads the last known configuration...
void files_dlg::load_files() {
    int count = setting<int>("files.count");
    for ( int idx = 0; idx < count; ++ idx) {
        std::string name = setting<std::string>(str_stream() << "files." << idx << ".name");
        add_file( name);
    }
}

// saves this configuration...
void files_dlg::save_files() {
    int idx = 0;
    for ( wnd_iterator<rc_file_dlg> begin = find_wnd_range<rc_file_dlg>(), end = wnd_iterator<rc_file_dlg>(); begin != end; ++begin, ++idx)
        setting<std::string>(str_stream() << "files." << idx << ".name") = begin->text();
    setting<int>("files.count") = idx;
}

void files_dlg::select_file_at_idx(int idx) {
    wnd<combo_box> rc_files = child<combo_box>(ID_rc_files);
    if ( idx >= rc_files->item_count() ) return; // invalid index

    rc_files->sel(idx);
    std::string text = rc_files->item_text(idx);
    wnd<frame_in_dialog> frame = find_wnd<frame_in_dialog>();
    wnd<> file_wnd = frame->find_by_name(text);
    frame->activate(file_wnd);
}



