
// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#include "StdAfx.h"
#include ".\template_file.h"

namespace {
    std::string file_to_str(const std::string & file_name) {
        std::string body;
        std::ifstream file( file_name.c_str() );
        std::ostringstream out;
        out << file.rdbuf();
        body = out.str();
        return body;
    }
}


template_file_coll load_templates() {
    template_file_coll coll;
    coll[ "dialog" ]        = file_to_str( "dialog.hpp_template");
    coll[ "all_dialogs" ]   = file_to_str( "all_dialogs.hpp_template");
    coll[ "menus" ]         = file_to_str( "menus.hpp_template");
    coll[ "subclassing" ]   = file_to_str( "subclassing.hpp_template");

    coll[ "others" ]   = file_to_str( "others.hpp_template");
    return coll;
}

