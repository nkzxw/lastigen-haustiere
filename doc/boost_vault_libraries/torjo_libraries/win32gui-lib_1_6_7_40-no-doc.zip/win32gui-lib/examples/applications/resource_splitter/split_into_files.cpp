// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#include "StdAfx.h"
#include ".\split_into_files.h"
#include "parse_rc/parse_rc.h"
#include "parse_rc/parse_resource_h.h"
#include "parse_rc/parse_win32gui_rc2.h"
#include "util/string_util.h"
#include "util/version.h"

using namespace boost::rangelib;

namespace {

    // helper - return our current version...
    std::string cur_version() {
        version::info ver;
        version::get_file_info(ver);
        return str_stream() <<  ver.major_ver << "." << ver.minor_ver << "." << ver.build_no;
    }


    // converts name/value/type into an class to identify an ID with these...
    std::string nvt_to_id(const std::string name, const std::string & value, const std::string & type) {
        std::string id;
        /* OLD CODE, v1.0.1 
        id = str_stream() << "struct m_" << name << " {\n"
            << "    typedef " << type << " id_to_class;\n"
            << "    enum { id = " << value << " }; \n"
            << "    typedef ::win32::gui::events_for_class<id, id_to_class> ev;\n"
            << "};\n";
        */
        id = str_stream() << "struct m_" << name << "_ {\n"
            << "    typedef " << type << " id_to_class;\n"
            << "    enum { id = " << value << " }; \n"
            << "    typedef ::win32::gui::events_for_class<id, id_to_class> ev;\n"
            << "};\n\n"

            << "#ifndef m_" << name << "\n"
            << "#define m_" << name << " child<m_" << name << "_>()\n"
            << "#endif\n\n";

        return id;
    }

    // converts the name/value into a menu_ string
    std::string nv_to_menu(const std::string & name, const std::string & value) {
        std::string menu = str_stream() << "  enum { " << name << " = " << value << " };";
        return menu;
    }




    // processes the dialog files from the .rc and resource.h file
    void process_dialog_files( 
            const rc_info & rc, 
            const resource_h_info & resource_h, 
            const template_file_coll & template_files,
            header_coll & files) {
        typedef rc_info::set set;
        for ( set::const_iterator begin = rc.m_dialogs.begin(), end = rc.m_dialogs.end(); begin != end; ++begin) {
            std::string dlg_name = *begin;
            // ignore dialog prefix and convert to lowercase
            if ( dlg_name.find("IDD_") == 0)
                dlg_name = dlg_name.substr(4);
            dlg_name = locase(dlg_name);
            if ( dlg_name.empty() ) {
                assert(false); continue; // should never have an empty dialog name...
            }
            if ( isdigit(dlg_name[0]) )
                continue; // ignore dialogs with the ID as a number...
            
            std::string body = template_files.find("dialog")->second;
            str_replace(body, "$dialog_name$", dlg_name);

            // resove IDs
            rc_element_value rc_value = rc.m_elements.find( rc_element_key(*begin,"dialog") )->second;
            typedef rc_element_value::children_array array;
            // ... in case there are some IDs we can't match - we assume they are defined in some other file.
            //     we will #undefine them...
            std::string ids_to_undefine;
            std::string ids;
            //std::string forward_declares;
            std::string dlg_on_dlg_declares;
            std::string ctl_typedefs;
            
            // set the dialog's ID
            /*
                Note: this makes it easy to define the static dialog_id() function.
                Just write this:
                int my_dialog::dialog_id() { return dialog_id_; }
            */
            std::string dlg_id;
            if ( resource_h.m_name_to_value.find(*begin) != resource_h.m_name_to_value.end() )
                dlg_id = resource_h.m_name_to_value.find(*begin)->second;
            else {
                dlg_id = *begin;
                ids_to_undefine = "#undef " + *begin + "\n";
            }
            ids = "enum { dialog_id_ = " + dlg_id + " };\n"; // the dialog's ID

            for ( array::const_iterator b = rc_value.children.begin(), e = rc_value.children.end() ; b != e; ++b) {
                std::string original_name = b->name, type = resource_type_to_type(b->type);
                assert( !original_name.empty() ); // this should never happen - we should always have a non-empty name...
                if ( original_name == "IDC_STATIC") 
                    continue; // ignore unnamed statics ...
                if ( type.empty() )
                    continue; // we can't handle this type... (could be an activeX or so...)

                std::string name = original_name; // name  - the name of the ID (example: m_user_name)
                std::string value;                // value - the value of this ID (example: 13442)
                adjust_id_name_and_type(name, type);
                // is this a dialog on another dialog (lookup by name, not by ID) ?
                bool is_dlg_on_dlg = rc.m_dialogs.find(original_name) != rc.m_dialogs.end();
                if ( is_dlg_on_dlg) {
                    type = name + "_dlg";
                    dlg_on_dlg_declares += "  struct " + type + "; \n";
                }

                // find out what we need to write to the file...
                std::string id_body; // the body for this ID...
                bool is_number = isdigit(original_name[0]) != 0;
                if ( is_number) {
                    // it's a number - like '13422'
                    if ( resource_h.m_value_to_name.find(original_name) != resource_h.m_value_to_name.end() ) {
                        name = resource_h.m_value_to_name.find(original_name)->second;
                        value = original_name;
                        adjust_id_name(name);
                        id_body = nvt_to_id(name, value, type);
                    }
                    else
                        id_body = str_stream() << "// " << original_name << " - cannot find value for this ID...";
                }
                else {
                    // it is an ID, like, ID_user_name
                    if ( resource_h.m_name_to_value.find(original_name) != resource_h.m_name_to_value.end() ) {
                        // found the corresponding value...
                        value = resource_h.m_name_to_value.find(original_name)->second;
                        id_body = nvt_to_id(name, value, type);
                    }
                    else {
                        // we don't know the value of this ID (could not be matched from the resource.h file)
                        // we assume it's been define somewhere else...
                        // example: IDOK, IDCANCEL, IDYES, etc.
                        value = original_name;
                        id_body = nvt_to_id(name, value, type);
                        ids_to_undefine += str_stream() << "#undef " << value << "\n";
                    }
                    // update the ctl:: typedefs
                    // example: 'typedef ::some_dlg_::user_name user_name';
                    ctl_typedefs += "typedef  m_" + name + "_ " + name + ";\n";
                }
                ids += id_body + "\n";
                /*if ( type.find( "::win32::gui::") == 0) {
                    std::string forward_class = type.substr(14);
                    forward_declares += "    struct " + forward_class + ";\n";
                }*/
            }

            str_replace(body, "$ids$", ids);
            str_replace(body, "$undefine_dialog_ids$", ids_to_undefine);
            //str_replace(body, "$forward_declares$", forward_declares);
            str_replace(body, "$dlg_on_dlg_declares$", dlg_on_dlg_declares);
            str_replace(body, "$ctl_typedefs$", ctl_typedefs);
            str_replace(body, "$version$", cur_version() );
            files[ dlg_name + ".hpp" ] = body;
        }
    }


    // used_names - sometimes by mistake different IDs end up being the same name - avoid that
    //              (example: ID_exit and IDM_EXIT)
    std::string get_menu_item_body(const std::string & menu_item_name, const resource_h_info & resource_h, std::set<std::string> & used_names) {
        std::string original_name = menu_item_name;

        std::string name = original_name; // name  - the name of the ID (example: m_user_name)
        std::string value;                // value - the value of this ID (example: 13442)
        adjust_id_name(name);
        while ( used_names.find(name) != used_names.end() )
            name += "_";
        used_names.insert(name);

        // find out what we need to write to the file...
        std::string menu_item_body; // the body for this ID...
        bool is_number = isdigit(original_name[0]) != 0;
        if ( is_number) {
            // it's a number - like '13422'
            if ( resource_h.m_value_to_name.find(original_name) != resource_h.m_value_to_name.end() ) {
                name = resource_h.m_value_to_name.find(original_name)->second;
                value = original_name;
                adjust_id_name(name);
                menu_item_body = nv_to_menu(name, value);
            }
            else
                menu_item_body = str_stream() << "// " << original_name << " - cannot find name for this ID...";
        }
        else {
            // it is an ID, like, ID_user_name
            if ( resource_h.m_name_to_value.find(original_name) != resource_h.m_name_to_value.end() ) {
                // found the corresponding value...
                value = resource_h.m_name_to_value.find(original_name)->second;
                menu_item_body = nv_to_menu(name, value);
            }
            else {
                // we don't know the value of this ID (could not be matched from the resource.h file)
                // we assume it's been define somewhere else...
                // example: IDOK, IDCANCEL, IDYES, etc.
                value = original_name;
                menu_item_body = nv_to_menu(name, value);
            }
        }
        return menu_item_body;
    }

    // used_names - sometimes by mistake different IDs end up being the same name - avoid that
    //              (example: ID_exit and IDM_EXIT)
    std::string get_res_body(const std::string & original_name, const resource_h_info & resource_h, std::set<std::string> & used_names) {
        std::string name = original_name;
        adjust_id_name(name);
        // make sure name is unique
        while ( rng::coll_find( used_names, name) ) name += "_"; 
        used_names.insert(name);

        std::string value;
        bool is_number = isdigit(original_name[0]) != 0;
        if ( is_number) {
            
            if ( crange<const value_to_name_coll> r = rng::coll_find( resource_h.m_value_to_name, original_name)) {
                name = r->second;
                value = original_name;
                adjust_id_name(name);
            }
            else
                return str_stream() << "// " << original_name << " - cannot find name for this ID";
        }
        else {
            // an ID, like ID_user_name
            if ( crange<const name_to_value_coll> r = rng::coll_find( resource_h.m_name_to_value, original_name))
                value = r->second;
            else
                // we assume it's defined somewhere else
                value = original_name;
        }
        return str_stream() << "enum { " << name << " = " << value << " }; ";
    }


    // processes the menu file...
    void process_menu_file( 
            const rc_info & rc, 
            const resource_h_info & resource_h, 
            const template_file_coll & template_files,
            header_coll & files) {
        typedef rc_info::set set;
        std::string menu_items;
        std::string menus;

        // process menu items
        std::set<std::string> used_names; // avoid using the same name twice...
        for ( set::const_iterator begin = rc.m_menu_items.begin(), end = rc.m_menu_items.end(); begin != end; ++begin) 
            menu_items += get_menu_item_body(*begin, resource_h, used_names) + "\n";

        // process menus
        std::set<std::string> used_menu_names;
        for ( set::const_iterator begin = rc.m_menus.begin(), end = rc.m_menus.end(); begin != end; ++begin) {
            menu_items += get_menu_item_body(*begin, resource_h, used_names) + " // menu group \n";
            menus += get_menu_item_body(*begin, resource_h, used_menu_names) + "\n";
        }

        std::string body = template_files.find("menus")->second;
        str_replace( body, "$menu_items$", menu_items);
        str_replace( body, "$menus$", menus);
        str_replace(body, "$version$", cur_version() );

        files[ "menus.hpp" ] = body;
    }


    // processes another type of resource (other than menu or dialog)
    void process_other_resource(
            const rc_info & rc, 
            const resource_h_info & resource_h, 
            const template_file_coll & template_files,
            header_coll & files,
            const std::string & resource_type) {

        typedef rc_info::set set;
        const set & other_res = rng::coll_find( rc.m_others, resource_type)->second;

        std::set<std::string> used_res_names;
        std::string items;
        for ( crange<const set> r(other_res); r; ++r)
            items += get_res_body(*r, resource_h, used_res_names) + "\n";

        std::string body = template_files.find("others")->second;
        str_replace( body, "$items$", items);
        str_replace( body, "$res_type$", resource_type);
        str_replace(body, "$version$", cur_version() );

        files[ resource_type + "s.hpp" ] = body;
    }

    void process_other_resources(
            const rc_info & rc, 
            const resource_h_info & resource_h, 
            const template_file_coll & template_files,
            header_coll & files) {

        for ( crange<const rc_info::resource_coll> r(rc.m_others); r; ++r)
            process_other_resource(rc, resource_h, template_files, files, r->first);
    }


}



std::string resource_type_to_type(const std::string & type) {
    std::string word;
    { std::stringstream in(type);
      in >> word;
    }

    if ( word == "auto3state")              return "::win32::gui::check_box";
    else if ( word == "autocheckbox")       return "::win32::gui::check_box";
    else if ( word == "autoradiobutton")    return "::win32::gui::radio_button";
    else if ( word == "checkbox")           return "::win32::gui::check_box";
    else if ( word == "combobox")           return "::win32::gui::combo_box";
    else if ( word == "control")            return "::win32::gui::window_base";
    else if ( word == "ctext")              return "::win32::gui::label";
    else if ( word == "defpushbutton")      return "::win32::gui::button";
    else if ( word == "edittext")           return "::win32::gui::edit";
    else if ( word == "groupbox")           return "::win32::gui::group_box";
    else if ( word == "icon")               return "::win32::gui::label";
    else if ( word == "listbox")            return "::win32::gui::list_box";
    else if ( word == "ltext")              return "::win32::gui::label";
    else if ( word == "pushbox")            return "::win32::gui::check_box";
    else if ( word == "pushbutton")         return "::win32::gui::button";
    else if ( word == "radiobutton")        return "::win32::gui::radio_button";
    else if ( word == "rtext")              return "::win32::gui::label";
    else if ( word == "scrollbar")          return "::win32::gui::scroll_bar";
    else if ( word == "state3")             return "::win32::gui::check_box";

    else if ( word == "control/button")                 {
        if ( type.find("checkbox") != std::string::npos)
            return "::win32::gui::check_box";
        else if ( type.find("radiobutton") != std::string::npos)
            return "::win32::gui::radio_button";
        return "::win32::gui::button";
    }
    else if ( word == "control/edit") {
        if ( type.find("es_multiline") )
            return "::win32::gui::multi_edit";
        return "::win32::gui::edit";
    }
    else if ( word == "control/static")                 {
        return "::win32::gui::label";
    }
    else if ( word == "control/sysdatetimepick32")      return "::win32::gui::date_time_ctrl";
    else if ( word == "control/sysmonthcal32")          return "::win32::gui::month_cal_ctrl";
    else if ( word == "control/sysanimate32")           return "::win32::gui::animate_ctrl";
    else if ( word == "control/msctls_progress32")      return "::win32::gui::progress_bar";
    else if ( word == "control/msctls_trackbar32")      return "::win32::gui::slider_ctrl";
    else if ( word == "control/msctls_updown32")        return "::win32::gui::spin_button";
    else if ( word == "control/scrollbar")              return "::win32::gui::scroll_bar";
    else if ( word == "control/systabcontrol32")        return "::win32::gui::tab_ctrl";
    else if ( word == "control/combobox")               return "::win32::gui::combo_box";
    else if ( word == "control/listbox")                return "::win32::gui::list_box";
    else if ( word == "control/systreeview32")          return "::win32::gui::tree_ctrl";
    else if ( word == "control/sysheader32")            return "::win32::gui::header_ctrl";
    else if ( word == "control/rebarwindow32")          return "::win32::gui::rebar";
    else if ( word == "control/toolbarwindow32")        return "::win32::gui::toolbar";
    else if ( word == "control/msctls_statusbar32")     return "::win32::gui::status_bar";
    else if ( word == "control/syslistview32")          return "::win32::gui::list_ctrl";
    // Steven
    else if ( word.find("control/richedit") == 0)       return "::win32::gui::rich_edit";
    else
        return ""; // could be an activeX???
}




/**
    Splits the information from the .rc / resource.h files
    into multiple files (dialogs,menus,etc.)
*/
header_coll split_into_files( const rc_info & rc, const resource_h_info & resource_h, const rc2_info & rc2, const template_file_coll & template_files) {
    header_coll files;
    process_dialog_files( rc, resource_h, template_files, files);
    process_menu_file( rc, resource_h, template_files, files);
    process_other_resources( rc, resource_h, template_files, files);

    files[ "win32gui.rc2" ] = rc2.write_to_str(rc, resource_h);
    return files;
}



// returns only the files that are different
header_coll get_diff_files(const header_coll & old_coll, const header_coll & new_coll) {
    header_coll result = new_coll;
    for ( header_coll::iterator begin = result.begin(), end = result.end(); begin != end; ) {
        std::string name = begin->first;
        bool same = ( old_coll.find(name) != old_coll.end() ) && (old_coll.find(name)->second == begin->second);
        if ( same) {
            header_coll::iterator prev = begin;
            ++begin;
            result.erase(prev);
        }
        else
            ++begin;            
    }
    return result;
}


void write_diff_files(const header_coll & coll, const std::string & dest_path) {
    fs::path dest = fs::path(dest_path) / "win32gui_res";
    if ( !fs::exists(dest) )
        fs::create_directory(dest);

    for ( header_coll::const_iterator begin = coll.begin(), end = coll.end(); begin != end; ++begin) {
        fs::path dest_file = dest / (begin->first);
        std::ofstream out( dest_file.string().c_str());
        out << begin->second;
    }
}

