#include "StdAfx.h"
#include ".\parse_win32gui_rc2.h"

#include "parse_rc/parse_resource_h.h"
#include "parse_rc/parse_rc.h"
#include "util/string_util.h"
#include "util/version.h"

using namespace win32::gui;
using detail::get_block_body;

using namespace boost::rangelib;


namespace {
    // adjusts a line that was read from an rc2 file
    void adjust_line_from_rc2(std::string & line) {
        str_replace(line, "\\n", "\n");
        str_replace(line, "\\r", "\r");
        str_replace(line, "\\0", "\0");
//        str_replace(line, "\\\"", "\"");

        str_replace(line, "\\x22", "\"");
    }

    // adjusts a line, so that it can be written to an rc2 file
    void adjust_line_to_rc2(std::string & line) {
        line += "\n";

        str_replace(line, "\n", "\\n");
        str_replace(line, "\r", "\\r");
        //str_replace(line, "\"", "\\\"");
        // VC misinterprets \" in .rc files
        str_replace(line, "\"", "\\x22");
    }

}

void rc2_info::read_from_file(const std::string & file_name, const resource_h_info & resource_h) {
    m_str.erase();
    m_scripts.clear();

    // read the file
    std::string body;
    { std::ifstream file( file_name.c_str() );
      std::ostringstream out;
      out << file.rdbuf();
      body = out.str();
    }

    std::istringstream in(body);
    std::string line;
    // first 3 lines:
    // #ifdef APSTUDIO_INVOKED
    // #error this file is not editable by Microsoft Visual C++
    // #endif //APSTUDIO_INVOKED
    std::getline( in, line);
    std::getline( in, line);
    std::getline( in, line);

    bool inside_dialog_info = false;
    rc2_info result;
    std::string dialog_id ; // the curent dialog - we're reading info from.
    std::string dialog_info;

    while ( std::getline(in,line) ) {
        str_trim(line);
        if ( line.empty() ) continue;

        if ( inside_dialog_info) {
            if ( line != "END") {
                // should be like "information", or "information"
                if ( line.end()[-1] == ',')
                    line = line.substr(0, line.size() - 1);
                assert( line[0] == '"' && line.end()[-1] == '"');
                if ( !dialog_id.empty() ) {
                    line = line.substr(1, line.size() - 2);
                    adjust_line_from_rc2(line);
                    dialog_info += line;
                }
                else
                    ; // this is an unknown/invalid dialog. Simply ignore it...
            }
            else {

                inside_dialog_info = false; // end of it
                if ( !dialog_id.empty() ) {
                    std::string script = get_block_body(dialog_info, "script");
                    str_trim(script);
                    if ( !script.empty())
                        m_scripts[dialog_id] = script;
                }
                else
                    ; // this is an unknown/invalid dialog. Simply ignore it...
                dialog_info.erase();
            }
        }
        else {
            // we're reading the dialog info header right now
            // ("<dialog_name> RCDATA" and "BEGIN")
            inside_dialog_info = true;
            dialog_id.erase(); // invalid dialog, so far

            std::istringstream line_in(line);
            std::string dialog_name, rcdata;
            line_in >> dialog_name >> rcdata;
            assert(rcdata == "RCDATA");
            if ( !dialog_name.empty()) {
                if ( isdigit(dialog_name[0]) ) {
                    std::istringstream word_in(dialog_name);
                    word_in >> dialog_id;
                }
                else {
                    if ( resource_h.m_name_to_value.find( dialog_name) != resource_h.m_name_to_value.end())
                        dialog_id = resource_h.m_name_to_value.find( dialog_name)->second;
                    else
                        ; // unknown dialog
                }
            }
            else 
                assert(false); // empty dialog name...

            std::getline(in, line);
            str_trim(line);
            assert( line == "BEGIN"); // the beginning of the dialog's info
        }
    }

}

// sets the script for this dialog
void rc2_info::script(const std::string & dialog_id, const std::string & value) {
    if ( m_scripts[dialog_id] != value) {
        m_scripts[dialog_id] = value;
        // we need to be recomputed (write_to_str) ...
        m_str.clear();
    }
}

std::string rc2_info::script(const std::string & dialog_id) const {
    if ( crange<const script_coll> r = rng::coll_find(m_scripts, dialog_id))
        return r->second;
    else
        return "";
}



void rc2_info::process_subclassing(const rc_info & rc, const resource_h_info & resource_h) const {
    m_subclassing.clear();

    typedef rc_info::set set;
    for ( crange<const set> r_dialog(rc.m_dialogs); r_dialog; ++r_dialog) {
        std::string dlg_name = *r_dialog;
        if ( dlg_name.empty() ) {
            assert(false); continue; // should never have an empty dialog name...
        }
        std::string dlg_value;
        if ( isdigit(dlg_name[0]) )
            dlg_value = dlg_name; // the dialog is specified by a number ID
        else {
            if ( resource_h.m_name_to_value.find(dlg_name) != resource_h.m_name_to_value.end())
                dlg_value = resource_h.m_name_to_value.find(dlg_name)->second;
        }
        if ( dlg_value.empty() ) {
            assert(false); continue; // should never have an empty dialog name...
        }
        
        // see about each control
        std::string subclassed_items;
        rc_element_value rc_value = rc.m_elements.find( rc_element_key(dlg_name,"dialog") )->second;
        typedef rc_element_value::children_array array;
        for ( crange<const array> r_controls(rc_value.children); r_controls; ++r_controls)
            if ( r_controls->name.find("_typeis_") != std::string::npos) {
                std::string name = r_controls->name, type;
                adjust_id_name_and_type(name, type);
                std::string value;
                if ( crange<const name_to_value_coll> r_value = rng::coll_find(resource_h.m_name_to_value, r_controls->name))
                    value = r_value->second;
                if ( !value.empty())
                    subclassed_items +=  value + " " + type + "\n";
                else
                    assert(false); // don't know the value for this ID???
            }

        if ( !subclassed_items.empty()) {
            // create the extra resource for this dialog,
            // containing all the controls that are subclassed.
            m_subclassing[dlg_value] = subclassed_items;
        }
    }

}

void rc2_info::process_window_to_surface(const rc_info & rc, const resource_h_info & resource_h) const {
    m_window_to_surface.clear();

    typedef rc_info::set set;
    for ( crange<const set> r_dialog(rc.m_dialogs); r_dialog; ++r_dialog) {
        std::string dlg_name = *r_dialog;
        if ( dlg_name.empty() ) {
            assert(false); continue; // should never have an empty dialog name...
        }
        std::string dlg_value;
        if ( isdigit(dlg_name[0]) )
            dlg_value = dlg_name; // the dialog is specified by a number ID
        else {
            if ( resource_h.m_name_to_value.find(dlg_name) != resource_h.m_name_to_value.end())
                dlg_value = resource_h.m_name_to_value.find(dlg_name)->second;
        }
        if ( dlg_value.empty() ) {
            assert(false); continue; // should never have an empty dialog name...
        }
        
        // see about each control
        std::string wnd_to_surface_items;
        rc_element_value rc_value = rc.m_elements.find( rc_element_key(dlg_name,"dialog") )->second;
        typedef rc_element_value::children_array array;
        for ( crange<const array> r_controls(rc_value.children); r_controls; ++r_controls) {
            std::string name = r_controls->name, type;
            adjust_id_name_and_type(name, type);

            std::string value;
            if ( crange<const name_to_value_coll> r_value = rng::coll_find(resource_h.m_name_to_value, r_controls->name))
                value = r_value->second;
            if ( !value.empty())
                wnd_to_surface_items += value + " " + name + "\n";
            else
                assert(false); // don't know the value for this ID???
        }

        if ( !wnd_to_surface_items.empty()) {
            // create the extra resource for this dialog,
            // containing all the controls that are wnd_to_surface.
            m_window_to_surface[dlg_value] = wnd_to_surface_items;
        }
    }
}


namespace {
    // helper - return our current version...
    std::string cur_version() {
        version::info ver;
        version::get_file_info(ver);
        return str_stream() <<  ver.major_ver << "." << ver.minor_ver << "." << ver.build_no;
    }
}
/** 
    Creates the .rc2 file' contents. If it can, it uses the cached version.
*/
std::string rc2_info::write_to_str(const rc_info & rc, const resource_h_info & resource_h) const {
    m_str.erase();

    process_subclassing(rc, resource_h);
    process_window_to_surface(rc, resource_h);

    typedef std::set<std::string> set;
    set dialogs;
    for ( crange<const script_coll> r_script(m_scripts); r_script; ++r_script)
        dialogs.insert( r_script->first);
    for ( crange<const subclassing_coll> r_subclassing(m_subclassing); r_subclassing; ++r_subclassing)
        dialogs.insert( r_subclassing->first);
    for ( crange<const window_to_surface_coll> r_window_to_surface(m_window_to_surface); r_window_to_surface; ++r_window_to_surface)
        dialogs.insert( r_window_to_surface->first);

    for ( crange<const set> r(dialogs); r; ++r) {
        std::string dlg_info;
        dlg_info += "version { " + cur_version() + " }\n";

        if ( crange<const window_to_surface_coll> window_to_surface = rng::coll_find(m_window_to_surface,*r))
            dlg_info += "window_to_surface {\n" + window_to_surface->second + "\n}; ";

        if ( crange<const subclassing_coll> subclassing = rng::coll_find(m_subclassing,*r))
            dlg_info += "subclassing {\n" + subclassing->second + "\n}; ";

        if ( crange<const script_coll> script = rng::coll_find(m_scripts,*r))
            dlg_info += "script {\n" + script->second + "\n}; ";

        std::string dlg_name;
        if ( isdigit( (*r)[0]))
            dlg_name = *r; // it's a number ID
        else {
            if ( crange<const value_to_name_coll> name = rng::coll_find(resource_h.m_value_to_name,*r) )
                dlg_name = name->second;
        }
        if ( !dlg_name.empty()) {
            // convert into .rc2 format
            m_str += str_stream() << "\n\n" + dlg_name << " RCDATA\nBEGIN\n";
            std::istringstream in(dlg_info);
            std::string line;
            while ( std::getline(in, line)) {
                adjust_line_to_rc2(line);
                m_str += '"' + line + "\",\n";
            }
            m_str += "\n\"\\0\"" // the ending nul character
                     "\nEND\n";
        }
        else
            assert(false); // unknown dialog? 
    }

    if ( !m_str.empty()) 
        // append MSVC needed prefix
        m_str = 
            "#ifdef APSTUDIO_INVOKED\n"
            "#error this file is not editable by Microsoft Visual C++\n"
            "#endif //APSTUDIO_INVOKED\n\n" + m_str;
    return m_str;
}

bool rc2_info::needs_recompute() const {
    // if str is empty, something related to the scripts is dirty.
    return m_str.empty();
}
