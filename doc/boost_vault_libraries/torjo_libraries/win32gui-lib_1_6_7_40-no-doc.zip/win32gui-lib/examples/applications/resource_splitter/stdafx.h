// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include <win32gui/window.hpp>
#include <win32gui/event_handler.hpp>
#include <win32gui/controls.hpp>
#include <win32gui/frame.hpp>


// Win32GUI Window base class 
using win32::gui::window_base;
using win32::gui::create_wnd;
// ... null window
using win32::gui::null_wnd;

// for extending windows/dialogs
using win32::gui::wnd_extend;

// Dialog class
using win32::gui::dialog;
using win32::gui::create_dlg;
using win32::gui::create_modal_dlg;

// Resizing Ability
using win32::gui::resizable_wnd;

// STL
#include <map>
#include <set>
#include <vector>
#include <string>
#include <algorithm>

#include <sstream>
#include <fstream>

#include "str_stream.hpp"
using boost::str_stream;


// Boost
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/operations.hpp>
#include <boost/filesystem/convenience.hpp>
namespace fs = boost::filesystem;

#include <persist_sl/setting.h>
using persist::setting;

#include <boost/rangelib/range.hpp>
#include <boost/rangelib/algo.hpp>
using boost::rangelib::crange;
using boost::rangelib::irange;

