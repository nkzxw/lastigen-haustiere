
// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#include "StdAfx.h"
#include ".\rc_file_dlg.h"
#include "resource.h"

#include "parse_rc/parse_rc.h"
#include "parse_rc/parse_resource_h.h"
#include "ui/files_dlg.h"
#include "parse_rc/parse_rc_add_other_rc_file.h"
#include "util/string_util.h"

using namespace boost::rangelib;

namespace {
    int TIMER_MONITOR = 1;
    int TIMER_SAVE_RC2 = 2;

    // identify icons
    namespace img {
        const int root = 0;
        const int dialog_root = 1;
        const int menu_item_root = 1;
        const int menu_root = 1;
        const int menu_item = 2;
        const int menu = 3;
        const int dialog = 4;
        const int control = 5;
    };

    std::string file_to_str(const std::string & file_name) {
        std::string body;
        std::ifstream file( file_name.c_str() );
        std::ostringstream out;
        out << file.rdbuf();
        body = out.str();
        return body;
    }
}



using namespace win32::gui;
using win32::gui::detail::ignore_quoted_string;

struct rc_file_dlg_handler : event_handler< rc_file_dlg_handler, rc_file_dlg> {
    HTREEITEM m_old_sel;
    rc_file_dlg_handler() : m_old_sel(0) {
        int timer_ms = setting<int>("app.monitor_ms", persist::err::set_def(500) );
        self->set_timer(TIMER_MONITOR, timer_ms);
        
        timer_ms = setting<int>("app.save_rc2_ms", persist::err::set_def(1500) );
        self->set_timer(TIMER_SAVE_RC2, timer_ms);

        on_res_change();
    }

    handle_event on_timer(w_param<int> id, answer a) {
        if ( id == TIMER_MONITOR) {
            if ( find_wnd<files_dlg>()->is_monitoring)
                self->reload();
            else
                self->log("Not monitoring at this time...");
        }
        else if ( id == TIMER_SAVE_RC2) {
            if ( find_wnd<files_dlg>()->is_monitoring)
                save_rc2();
        }
        else
            a = event_not_handled;
        return event<WM_TIMER>().HANDLED_BY(&me::on_timer);
    }

    handle_event on_res_change() {
        wnd<tree_ctrl> res = child<tree_ctrl>(ID_resources);
        HTREEITEM sel = res->sel();
        if ( sel == m_old_sel)
            return event_handled_early; // sel not changed

        if ( m_old_sel) {
            // save the old selection
            std::string dialog_id = item_to_dialog_id(m_old_sel);
            if ( !dialog_id.empty()) 
                self->m_rc2.script(dialog_id, child(IDC_script)->text() );
        }

        std::string dialog_id = item_to_dialog_id(sel);
        if ( !dialog_id.empty()) {
            std::string script = self->m_rc2.script(dialog_id);
            if ( script.empty() )
                script = load_default_script(sel);
            str_replace(script, "\n", "\r\n");
            str_replace(script, "\r\r\n", "\r\n");

            child(IDC_script)->text( script );
            child(IDC_script)->enable(true);
            child(IDC_clean)->enable(true);
            child(IDC_reset)->enable(true);
        }
        else {
            child(IDC_script)->text("");
            child(IDC_script)->enable(false);
            child(IDC_clean)->enable(false);
            child(IDC_reset)->enable(false);
        }
        return notify<ID_resources,TVN_SELCHANGED>().HANDLED_BY(&me::on_res_change);
    }

    handle_event on_clean() {
        child(IDC_script)->text("");
        return command<IDC_clean,BN_CLICKED>().HANDLED_BY(&me::on_clean);
    }
    handle_event on_reset() {
        wnd<tree_ctrl> res = child<tree_ctrl>(ID_resources);
        HTREEITEM sel = res->sel();

        std::string script = load_default_script(sel);
        str_replace(script, "\n", "\r\n");
        str_replace(script, "\r\r\n", "\r\n");

        child(IDC_script)->text( script );
        return command<IDC_reset,BN_CLICKED>().HANDLED_BY(&me::on_reset);
    }


private:
    // adjusts the script text - making sure it's got matching { and }
    void adjust_script_text(std::string & script) {
        int indent = 0;
        std::string dest ;
        dest.reserve( script.size());
        for ( std::string::const_iterator b = script.begin(), e = script.end(); b != e; ++b) {
            if ( *b == '"') {
                std::string::const_iterator end_of_str = b;
                ignore_quoted_string(script, end_of_str);
                dest += std::string(b, end_of_str);
                b = end_of_str;
                --b;
                continue;
            }

            if ( *b == '{') ++indent;
            if ( *b == '}') --indent;

            while ( indent < 0) {
                dest += '{';
                ++indent;
            }
            dest += *b;
        }

        while ( indent > 0) {
            dest += '}';
            --indent;
        }
        script = dest;
    }

    void save_rc2() {
        // save the current selection
        wnd<tree_ctrl> res = child<tree_ctrl>(ID_resources);
        HTREEITEM sel = res->sel();
        if ( !sel) return;
        std::string dialog_id = item_to_dialog_id(sel);
        if ( dialog_id.empty()) return; // not editing a dialog

        std::string script = child(IDC_script)->text();
        adjust_script_text(script);
        self->m_rc2.script(dialog_id, script );
        if ( !self->m_rc2.needs_recompute())
            return; // nothing changed (in the script)...

        std::ofstream out( self->m_rc2_file_name.c_str());
        out << self->m_rc2.write_to_str(self->m_rc, self->m_resource_h);
    }


    // if the item is a dialog, or child of it, it return the dialog's ID
    std::string item_to_dialog_id(HTREEITEM item) {
        wnd<tree_ctrl> res = child<tree_ctrl>(ID_resources);
        std::string dialog_id;
        while ( item) {
            if ( crange<rc_file_dlg::item_to_dialog_id> r = rng::coll_find(self->m_item_to_dialog_id,item)) {
                dialog_id = r->second;
                break;
            }
            item = res->parent_item(item);
        }
        return dialog_id;
    }

    std::string load_default_script(HTREEITEM item) {
        if ( item == self->m_script_root)
            return file_to_str("root.script_template");
        else
            return file_to_str("non_root.script_template");
    }
};

// FIXME (future) Allow for all types of resources to be included into a file
// Like, icon_::resource_types, bitmap_::resouce_types, etc.
// TODO: bitmap_, icon_, cursor_ and string_


rc_file_dlg::rc_file_dlg(const std::string & file_name, const template_file_coll & file_templates) 
        : m_rc_file_name(file_name), m_file_templates(file_templates), m_tree_imgs(IDB_resource_types,16), m_list_imgs(IDB_subclass_types,16) {

    add_resizable_ctrl(ID_resources, size_y);
    add_resizable_ctrl(IDC_log, size_x | move_y);
    add_resizable_ctrl(IDC_script, size_xy);
    add_resizable_ctrl(IDC_clean, move_xy);
    add_resizable_ctrl(IDC_reset, move_xy);

    parse_rc_add_other_rc_file(file_name);

    text(file_name);
    m_resource_h_file_name = (fs::path(file_name).branch_path() / "resource.h").string();
    m_rc2_file_name = (fs::path(file_name).branch_path() / "win32gui_res/win32gui.rc2").string();

    m_script_root = child<tree_ctrl>(ID_resources)->add_root_item( tv_item().text("Script Root").image(img::dialog_root) );
    m_dialogs_root = child<tree_ctrl>(ID_resources)->add_root_item( tv_item().text("Dialogs").image(img::dialog_root) );
    m_menus_root = child<tree_ctrl>(ID_resources)->add_root_item( tv_item().text("Menus").image(img::menu_root) );
    m_menu_items_root = child<tree_ctrl>(ID_resources)->add_root_item( tv_item().text("Menu Items").image(img::menu_item_root) );

    // update for the first time...
    wnd<tree_ctrl> rc_tree = child<tree_ctrl>(ID_resources);
    rc_tree->images(TVSIL_NORMAL, m_tree_imgs.raw_handle() );

    // we need to parse the .rc2 file, since the user could have edited some of the (dialog) scripts.
    // thus, we need to read them, so that next time we override the .rc2 file, previous changes will be preserved
    m_resource_h = parse_resource_h_file( m_resource_h_file_name);
    m_rc2.read_from_file( m_rc2_file_name, m_resource_h);

    reload();
    rc_tree->expand(m_dialogs_root);
    rc_tree->expand(m_menus_root);
    rc_tree->expand(m_menu_items_root);

    rc_tree->sel( m_script_root);
}

rc_file_dlg::~rc_file_dlg(void)
{
}

int rc_file_dlg::dialog_id() {
    return IDD_rc_file;
}

void rc_file_dlg::log(const std::string & msg) {
    if ( m_last_log_msg == msg) return; // don't write the same thing twice...

    time_t now = time(0); tm now_det = *localtime(&now);
    std::string log_text = asctime(&now_det);
    *log_text.rbegin() = ' '; // replace the enter...
    log_text += msg + "\r\n" + child(IDC_log)->text();
    log_text = log_text.substr(0, 8192); // don't keep too much text...
    child(IDC_log)->text( log_text);

    m_last_log_msg = msg;
}


// reloads the resource file, and checks the changes
void rc_file_dlg::reload() {
    if ( !fs::exists(m_rc_file_name) ) {
        log( str_stream() << m_rc_file_name << " does not exist...");
        return;
    }
    if ( !fs::exists(m_resource_h_file_name) ) {
        log( str_stream() << m_resource_h_file_name << " does not exist...");
        return;
    }

    std::string new_rc_text = file_to_str(m_rc_file_name);
    std::string new_resource_h_text = file_to_str(m_resource_h_file_name);
    if ( new_rc_text == m_old_rc_text && new_resource_h_text == m_old_resource_h_text)
        return; // nothing changed...
    // something changed...
    m_old_rc_text = new_rc_text;
    m_old_resource_h_text = new_resource_h_text;

    m_rc = parse_rc_file( m_rc_file_name);
    m_resource_h = parse_resource_h_file( m_resource_h_file_name);

    header_coll new_files = split_into_files( m_rc, m_resource_h, m_rc2, m_file_templates);
    header_coll diff = get_diff_files(m_files, new_files);
    if ( !diff.empty() ) {
        m_files = new_files;
        write_diff_files( diff, fs::path(m_rc_file_name).branch_path().string() );
        update_rc_tree(m_rc, m_resource_h);
        log( "Refreshed...");
        m_last_log_msg = ""; // so that the "Refreshed..." msg is written each time there's a diff...
    }
}


namespace {
    // finds the child that STARTS with the given name
    // if not found, returns null
    HTREEITEM find_tree_child(const wnd<tree_ctrl> & tree, const std::string & child_name, HTREEITEM parent) {
        assert(parent); // we should have a valid parent to search in...
        HTREEITEM child = tree->first_child(parent);
        while ( child) {
            if ( tree->item(child).text().find(child_name) == 0)
                return child; // found!
            child = tree->next_sibling(child);
        }
        return 0;
    }

    // walks through all the parent' children, and removes all children that are not in the given array
    void remove_tree_children_not_in_array(wnd<tree_ctrl> & tree, HTREEITEM parent, const std::set<HTREEITEM> & children) {
        std::vector<HTREEITEM> to_erase;
        HTREEITEM child = tree->first_child(parent);
        while ( child) {
            if ( children.find(child) == children.end() )
                to_erase.push_back(child);
            child = tree->next_sibling(child);
        }

        for ( crange<std::vector<HTREEITEM> > r(to_erase); r; ++r)
            tree->del_item( *r);
    }

}

void rc_file_dlg::update_rc_tree(const rc_info & rc, const resource_h_info & resource_h) {
    typedef rc_info::set set;
    wnd<tree_ctrl> rc_tree = child<tree_ctrl>(ID_resources);

    //
    // update dialogs
    m_item_to_dialog_id.clear();
    m_item_to_dialog_id[ m_script_root] = "1"; // root is itentified as '1'
    std::set<HTREEITEM> existing_dialogs;
    for ( crange<const set> r(rc.m_dialogs); r; ++r) {
        std::string original_name = *r;
        std::string name = original_name;
        adjust_id_name(name);
        std::string ui_name = name + " (" + original_name + ")";
        HTREEITEM child = find_tree_child(rc_tree, name + " (", m_dialogs_root);
        if ( child)
            // update its text, just in case
            rc_tree->item(child, tv_item().text(ui_name) );
        else
            // does not exist, add it now
            child = rc_tree->add_item(m_dialogs_root, tv_item().text(ui_name).image(img::dialog) );
        existing_dialogs.insert(child);

        // update the item_to_dialog_id
        std::string dialog_id ;
        if ( isdigit(original_name[0]))
            dialog_id = original_name;
        else if ( crange<const name_to_value_coll> value = rng::coll_find(resource_h.m_name_to_value, original_name))
            dialog_id = value->second;
        if ( !dialog_id.empty())
            m_item_to_dialog_id[child] = dialog_id;
    }
    remove_tree_children_not_in_array(rc_tree, m_dialogs_root, existing_dialogs);

    // update dialog controls
    for ( crange<const set> r(rc.m_dialogs); r; ++r) {
        std::string dlg_name = *r;
        adjust_id_name(dlg_name);
        HTREEITEM dlg_root = find_tree_child(rc_tree, dlg_name + " (", m_dialogs_root);
        assert( dlg_root); // this dialog should exist!

        typedef rc_element_value::children_array array;
        std::set<HTREEITEM> existing_items;
        for ( crange<const array> control_r(rc.m_elements.find( rc_element_key(*r,"dialog") )->second.children); control_r; ++control_r) {
            std::string original_name = control_r->name;
            std::string type = resource_type_to_type( control_r->type);
            std::string name = original_name;
            adjust_id_name(name);

            bool is_dlg_on_dlg = rc.m_dialogs.find(original_name) != rc.m_dialogs.end();
            if ( is_dlg_on_dlg)
                type = name + "_dlg - dialog-on-dialog";

            // if our own - ignore prefix...
            if ( type.find("::win32::gui") == 0) type = type.substr(14); 
            std::string ui_name = name + " (" + type + ")";
            HTREEITEM child = find_tree_child(rc_tree, name + " (", dlg_root);
            if ( child)
                // update its text, just in case
                rc_tree->item(child, tv_item().text(ui_name) );
            else
                // does not exist, add it now
                child = rc_tree->add_item(dlg_root, tv_item().text(ui_name).image(img::control) );
            existing_items.insert(child);
        }
        remove_tree_children_not_in_array(rc_tree, dlg_root, existing_items);
    }

    // update menu items
    std::set<HTREEITEM> existing_menu_items;
    for ( crange<const set> r(rc.m_menu_items); r; ++r) {
        std::string original_name = *r;
        std::string name = original_name;
        adjust_id_name(name);
        std::string ui_name = name + " (" + original_name + ")";
        HTREEITEM child = find_tree_child(rc_tree, name + " (", m_menu_items_root);
        if ( child)
            // update its text, just in case
            rc_tree->item(child, tv_item().text(ui_name) );
        else
            // does not exist, add it now
            child = rc_tree->add_item(m_menu_items_root, tv_item().text(ui_name).image(img::menu_item) );
        existing_menu_items.insert(child);    
    }
    remove_tree_children_not_in_array(rc_tree, m_menu_items_root, existing_menu_items);


    // update menus
    std::set<HTREEITEM> existing_menus;
    for ( crange<const set> r(rc.m_menus); r; ++r) {
        std::string original_name = *r;
        std::string name = original_name;
        adjust_id_name(name);
        std::string ui_name = name + " (" + original_name + ")";
        HTREEITEM child = find_tree_child(rc_tree, name + " (", m_menus_root);
        if ( child)
            // update its text, just in case
            rc_tree->item(child, tv_item().text(ui_name) );
        else
            // does not exist, add it now
            child = rc_tree->add_item(m_menus_root, tv_item().text(ui_name).image(img::menu) );
        existing_menus.insert(child);    
    }
    remove_tree_children_not_in_array(rc_tree, m_menus_root, existing_menus);

//    rc_tree->invalidate();
}


