#ifndef APP_FRAME_H
#define APP_FRAME_H

#pragma once

struct app_frame_handler;

struct app_frame : wnd_extend<win32::gui::sdi_frame, app_frame> {
    app_frame(void);
    ~app_frame(void);

    friend struct app_frame_handler;
};

#endif

