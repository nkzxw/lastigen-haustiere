
// Win32 GUI Generics - Resource Splitter
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// To see the version you have now, read win32gui/version.txt
//
// You can find the latest version of this library at http://www.torjo.com/win32gui/

#include "StdAfx.h"
#include ".\frame_in_dialog.h"
#include "ui/files_dlg.h"

using namespace win32::gui;
struct frame_in_dialog_handler : event_handler<frame_in_dialog_handler, view_frame, frame_in_dialog> {
    handle_event on_paint() {
        PAINTSTRUCT ps;
        HDC dc = ::BeginPaint(self->raw_hwnd(), &ps);
        rectangle r = self->client_rect();
        ::FillRect(dc, &r, (HBRUSH) (COLOR_3DFACE+1) );
        ::EndPaint(self->raw_hwnd(), &ps);
        return event<WM_PAINT>().HANDLED_BY(&me::on_paint);
    }

    handle_event on_drop_files(w_param<HDROP> h) {
        find_wnd<files_dlg>()->on_drop_files(h);
        return event<WM_DROPFILES>().HANDLED_BY(&me::on_drop_files);
    }
};



create_info frame_in_dialog::def_create_info() {
    // first, register class (note: might already be registered  - that's ok)
    WNDCLASSEX info = window_base::class_info().wnd_class_name("frame-in-dialog").raw_info();
    ::RegisterClassEx( &info );
    try { window_class_info::from_name( info.lpszClassName, (HINSTANCE)info.hInstance);
    } catch( std::exception &) {
        assert(false);
    }

    return create_info().class_name( info.lpszClassName)
            .style(     WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_CHILD)
            .ex_style(  WS_EX_WINDOWEDGE | WS_EX_ACCEPTFILES)
            ;
}

frame_in_dialog::frame_in_dialog() : m_active_wnd(0) {
}


// activates the given window - if hwnd is null, it hides all children...
void frame_in_dialog::activate(hwnd_proxy hwnd) {
    if ( hwnd == m_active_wnd) return; // same window...

    if ( hwnd)
        find_by_hwnd(hwnd)->show();
    if ( m_active_wnd)
        find_by_hwnd(m_active_wnd)->show(SW_HIDE); // hide previously active window
    m_active_wnd = hwnd;
}
