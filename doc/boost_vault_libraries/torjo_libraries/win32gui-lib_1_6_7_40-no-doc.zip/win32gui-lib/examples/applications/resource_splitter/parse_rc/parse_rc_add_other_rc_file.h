#pragma once

void parse_rc_add_other_rc_file(const std::string & file_name);

