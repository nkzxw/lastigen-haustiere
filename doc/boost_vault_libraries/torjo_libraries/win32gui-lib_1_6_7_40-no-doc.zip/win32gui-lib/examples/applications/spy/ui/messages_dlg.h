#pragma once

#include "spy_event.h"
#include "id_to_name.h"

struct messages_dlg_handler;

struct messages_dlg :   wnd_extend<dialog, messages_dlg>, 
                        wnd_extend<resizable_wnd, messages_dlg> {
public:
    messages_dlg(void);
    ~messages_dlg(void);
    static int dialog_id();

private:
    friend struct messages_dlg_handler;

    struct friendly_info {
        friendly_info(const friendly_spy_event & event = friendly_spy_event(), const name_pair & names = name_pair() ) 
            : event(event), friendly_names(names) {}

        // the event
        friendly_spy_event event;

        // friendly names, for the control and its parent
        name_pair friendly_names;
    };

    // key - the event's ID
    typedef std::map<int, friendly_info> friendly_coll;
    friendly_coll m_events;
};
