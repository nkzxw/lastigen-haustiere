#pragma once

#include "filter.h"

struct id_to_name;
struct filter_dlg_handler ;

struct filter_dlg : wnd_extend<dialog, filter_dlg>, wnd_extend<resizable_wnd, filter_dlg> {
public:
    filter_dlg(void);
    ~filter_dlg(void);
    static int dialog_id();

    const filter_type &filter() const { return m_filter; }
    void refresh_filter(const id_to_name & names);

private:
    friend struct filter_dlg_handler ;

    filter_type m_filter;
};
