#include "StdAfx.h"
#include ".\id_to_name.h"
#include "util/string_util.h"
#include "parse_rc/parse_rc.h"
#include "parse_rc/parse_resource_h.h"

using namespace boost::rangelib;

id_to_name::id_to_name(fs::path resource_path) : m_resource_path(resource_path) {
    if ( !resource_path.empty())
        load();
}

id_to_name::~id_to_name(void)
{
}


name_pair id_to_name::names(int control_id, int parent_id) const {
    int adjusted_parent_id = parent_id;
    if ( rng::coll_find(m_dialog_ids, control_id))
        // it's a dialog
        adjusted_parent_id = -1;

    if ( crange<const id_to_name_coll> r_name = rng::coll_find(m_id_to_name, id_pair(control_id,adjusted_parent_id)))
        return r_name->second;
    else 
        return name_pair( str_stream() << control_id, str_stream() << parent_id);
}

namespace {
    // returns the name to the .rc file
    fs::path rc_file(fs::path dir) {
        for ( fs::directory_iterator begin(dir), end; begin != end; ++begin)
            if ( locase(fs::extension(*begin)) == ".rc")
                return *begin;
        // .rc file not found!
        assert(false);
        return dir / "not_found.rc";
    }
}

// loads the IDs <-> names information, from the resource.h and .rc files
void id_to_name::load() {
    m_dialogs.clear();
    m_dialog_ids.clear();
    m_id_to_name.clear();

    rc_info rc = parse_rc_file( rc_file(m_resource_path).string() );
    resource_h_info res_h = parse_resource_h_file( (m_resource_path / "resource.h").string() );
    // standard IDs
    res_h.m_name_to_value["IDOK"] = "1";
    res_h.m_name_to_value["IDCANCEL"] = "2";
    res_h.m_name_to_value["IDABORT"] = "3";
    res_h.m_name_to_value["IDRETRY"] = "4";
    res_h.m_name_to_value["IDIGNORE"] = "5";
    res_h.m_name_to_value["IDYES"] = "6";
    res_h.m_name_to_value["IDNO"] = "7";
    res_h.m_name_to_value["IDCLOSE"] = "8";
    res_h.m_name_to_value["IDHELP"] = "9";
    
    typedef std::map<std::string,int> name_to_id_coll;
    name_to_id_coll dialog_name_to_id;

    // find the dialogs first
    for ( crange<const rc_info::set> r_dialog(rc.m_dialogs); r_dialog; ++r_dialog)
        if ( crange<const name_to_value_coll> r_name = rng::coll_find(res_h.m_name_to_value, *r_dialog) ) {
            // we have a dialog
            std::istringstream id_in(r_name->second);
            int id = 0;
            id_in >> id;
            assert(id > 0); // should be a valid dialog ID
            m_dialog_ids.insert(id);
            m_dialogs[ *r_dialog ] = control_array();
            m_id_to_name[ id_pair(id,-1) ] = name_pair(*r_dialog,"");
            dialog_name_to_id[ *r_dialog ] = id;
        }
        else
            // don't know the dialog's ID?
            assert(false);

    // now, find each of the dialog's children (controls)
    for ( crange<const rc_info::set> r_dialog(rc.m_dialogs); r_dialog; ++r_dialog) 
        if ( rng::coll_find(m_dialogs, *r_dialog)) {
            rc_element_key dialog_key(*r_dialog, "dialog");
            rc_element_value dialog_children = rc.m_elements[dialog_key];

            for ( crange<rc_element_value::children_array> r_child(dialog_children.children); r_child; ++r_child) {
                std::string name = r_child->name;
                int id = 0;
                std::istringstream id_in(res_h.m_name_to_value[name]);
                id_in >> id;
                if ( id <= 0) {
                    // this name does not have a corresponding ID
                    //
                    // it might happen when you're using IDs included from .h files other than resource.h
                    continue;
                }
                int dialog_id = dialog_name_to_id[ *r_dialog ];

                // ... don't care about its type...
                if ( name.find("_typeis_") != std::string::npos)
                    name = name.substr(0, name.find("_typeis_"));
                m_dialogs[ *r_dialog].push_back(name);
                m_id_to_name[ id_pair(id, dialog_id) ] = name_pair(name, *r_dialog);
            }
        }
}
