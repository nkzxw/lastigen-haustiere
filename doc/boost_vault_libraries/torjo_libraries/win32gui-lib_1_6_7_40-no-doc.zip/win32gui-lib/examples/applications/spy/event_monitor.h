#pragma once

#include "spy_event.h"


typedef std::vector<friendly_spy_event> spy_event_array;


/** 
    Monitors for messages from a certain win32gui log file
*/
struct event_monitor {
    event_monitor();
    ~event_monitor(void);

    void monitor_file(fs::path file);

    friendly_spy_event get_event(int event_id) const;

    int begin_event_id() const;
    int end_event_id() const;

    void get_events(const std::vector<int> & ids, spy_event_array & msgs) const;
private:
    void get_event_impl(int event_id, friendly_spy_event & result) const;
    void clear();

private:
    void do_monitor();
    void process_raw_events();

private:
    mutable critical_section m_cs;

    // the file we're monitoring
    fs::path m_monitor_file;

    // the max. number of events we keep internally
    int m_max_event_count;

    typedef std::vector<spy_event> raw_event_array;
    raw_event_array m_raw_events;

    typedef std::vector<friendly_spy_event> event_array;
    event_array m_events;

    // this is the ID of the first user-friendly event we're holding...
    int m_first_event_id;
};
