// sample_start.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "ui/main_dlg.h"
#include <win32gui/frame.hpp>
#include "util/cmd_line_util.h"

int APIENTRY WinMain(HINSTANCE , HINSTANCE ,LPTSTR, int) {
    fs::path::default_name_check( fs::native);

    using namespace win32::gui;
    wnd<> top = create_wnd<sdi_frame>("Win32GUI Spy++", null_wnd);
    wnd<main_dlg> dlg = create_dlg<main_dlg>(top);

    cmd_line cmd;
    if ( cmd.args().size() > 1) 
        dlg->monitor_file( cmd.args()[1] );

    top->wait();
}
