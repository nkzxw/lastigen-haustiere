#include "StdAfx.h"
#include ".\filter.h"

filter_type::filter_type(void) : m_show_all(false)
{
}

filter_type::~filter_type(void)
{
}


void filter_type::add_valid_name(const name_pair & n) { 
    m_valid_names.insert(n); 
//    ::OutputDebugString( (str_stream() << "Add valid names: " << n.name << "/" << n.parent_name << "\n").c_str() );
}
void filter_type::del_valid_name(const name_pair & n) { 
    m_valid_names.erase(n); 
//    ::OutputDebugString( (str_stream() << "Del valid names: " << n.name << "/" << n.parent_name << "\n" ).c_str() );
}


void filter_type::clear() {
    m_valid_names.clear();
//    ::OutputDebugString( "clear valid names\n");
}

bool filter_type::matches_name(const name_pair & n) const {
    if ( m_show_all)
        return true;

    int control_id = -2;
    std::istringstream in(n.name);
    in >> control_id;
    if ( control_id != -2)
        /* if the name is a number, that means it's got an unknown ID. Always show it visually.
        */
        return true;

    return m_valid_names.find(n) != m_valid_names.end();
}

void filter_type::show_all(bool val) {
    m_show_all = val;
}


