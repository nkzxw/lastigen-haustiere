#pragma once

struct name_pair {
    name_pair(const std::string & name = "", const std::string & parent_name = "") : name(name), parent_name(parent_name) {}

    std::string name;
    // if it's a dialog, then then parent_name is empty (we don't care who the parent is)
    std::string parent_name;

    friend inline bool operator<(const name_pair & a, const name_pair & b) {
        if ( a.parent_name != b.parent_name) return a.parent_name < b.parent_name;
        return a.name < b.name;
    }
};


/** 
    Translates the a pair of IDs into a pair of names.
    In other words, translates ID codes into user-friendly names - the names
    from the resource.h and XX.rc file

*/
struct id_to_name {
    id_to_name(fs::path resource_path);
    ~id_to_name(void);

    typedef std::vector<std::string> control_array;
    // each dialog has some controls in it
    typedef std::map<std::string,control_array> dialog_coll;

    const dialog_coll & dialogs() const { return m_dialogs; }

    name_pair names(int control_id, int parent_id) const;

private:
    void load();

private:
    // the path where the resource files are found.
    fs::path m_resource_path;

    dialog_coll m_dialogs;

    struct id_pair {
        id_pair(int control_id, int parent_id) : control_id(control_id), parent_id(parent_id) {}

        int control_id;
        int parent_id;
        friend inline bool operator<(const id_pair & a, const id_pair & b) {
            if ( a.control_id != b.control_id) return a.control_id < b.control_id;
            return a.parent_id < b.parent_id;
        }
    };

    // here, we know which IDs are dialog IDs.
    typedef std::set<int> id_set;
    id_set m_dialog_ids;

    typedef std::map<id_pair, name_pair> id_to_name_coll;
    id_to_name_coll m_id_to_name;
};
