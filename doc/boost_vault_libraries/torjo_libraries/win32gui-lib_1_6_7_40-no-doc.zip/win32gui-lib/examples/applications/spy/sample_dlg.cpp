#include "stdafx.h"
// sample_dlg.cpp
#include "resource.h"
#include "sample_dlg.h"
#include <win32gui/event_handler.hpp>

using namespace win32::gui;


struct sample_dlg_handler : event_handler<sample_dlg_handler, dialog, sample_dlg> {
};


sample_dlg::sample_dlg() {
}

sample_dlg::~sample_dlg() {
}

int sample_dlg::dialog_id() { return IDD_SAMPLE; }
    