#include "StdAfx.h"
#include ".\filter_dlg.h"
#include <win32gui/res.hpp>

#include "id_to_name.h"

#include "win32gui_res/filter.hpp"
#include "win32gui_res/bitmaps.hpp"

using namespace win32::gui;
using namespace win32::gui::res_id;
using namespace boost::rangelib;

namespace {
    namespace node {
        enum {
            root = 1,
            dialog = 4,
            control = 5
        };
    }
}

struct filter_dlg_handler : event_handler<filter_dlg_handler, filter_dlg> {
    enum {
        POST_CLICK = WM_APP + 1
    };

    image_list<owned> m_images;

    filter_dlg_handler() : m_images(bitmap_::names, 16) {
        m_list->images( tree_ctrl_::images::normal, m_images);
    }

    handle_event on_click() {
        // finding out if an item is checked or not is too soon now...
        post_msg(POST_CLICK);
        return event_ex<m_list_::ev::clicked>().HANDLED_BY(&me::on_click);
    }

    handle_event on_post_click() {
        point cursor = cursor_pos(m_list);
        HTREEITEM clicked_item = m_list->hit_test(cursor).first;
        if ( clicked_item != 0) {
            HTREEITEM parent = m_list->parent_item(clicked_item);
            bool is_root = parent == 0;
            if ( !is_root) {
                std::string control_name = m_list->item(clicked_item).text();
                std::string dialog_name = m_list->item(parent).text();
                bool parent_is_root = dialog_name == "Dialogs";
                if ( parent_is_root)
                    dialog_name = "";

                bool is_checked = m_list->is_checked(clicked_item);
                if ( is_checked)
                    self->m_filter.add_valid_name( name_pair(control_name, dialog_name));
                else
                    self->m_filter.del_valid_name( name_pair(control_name, dialog_name));
            }
        }
        return event<POST_CLICK>().HANDLED_BY(&me::on_post_click);
    }

    handle_event on_show_all_click() {
        self->m_filter.show_all( m_show_all->is_checked());
        return event_ex<m_show_all_::ev::clicked>().HANDLED_BY(&me::on_show_all_click);
    }

};


filter_dlg::filter_dlg(void) {
    add_resizable_ctrl(m_list_::id, size_xy);
    add_resizable_ctrl(m_show_all_::id, move_xy);
}

filter_dlg::~filter_dlg(void)
{
}

int filter_dlg::dialog_id() { return dialog_id_; }

void filter_dlg::refresh_filter(const id_to_name & names) {
    m_list->del_all_items();
    m_list->set_redraw(false);
    m_filter.clear();

    HTREEITEM root = m_list->add_root_item( tv_item().text("Dialogs").image(node::root));
    m_list->chk_state(root, tree_ctrl_::chk_state::not_set);

    typedef id_to_name::dialog_coll dialog_coll ;
    typedef id_to_name::control_array control_array;
    for ( crange<const dialog_coll> r_dialog(names.dialogs()); r_dialog; ++r_dialog) {
        HTREEITEM cur_dlg = m_list->add_item(root, tv_item().text(r_dialog->first).image(node::dialog) );
        m_list->check(cur_dlg, true);
        m_filter.add_valid_name( name_pair(r_dialog->first,"") ); // for dialog: no parent

        for ( crange<const control_array> r_control(r_dialog->second); r_control; ++r_control) {
            HTREEITEM cur_control = m_list->add_item(cur_dlg, tv_item().text(*r_control).image(node::control) );
            m_list->check(cur_control, true);
            m_filter.add_valid_name( name_pair(*r_control, r_dialog->first) );
        }
    }
    m_list->set_redraw(true);
    m_list->invalidate();
}



