#pragma once

#include "id_to_name.h"

/** 
    Represents a filter - for filter_typeing spied messages
*/
struct filter_type {
    filter_type(void);
    ~filter_type(void);

    void add_valid_name(const name_pair & n) ;
    void del_valid_name(const name_pair & n) ;

    bool matches_name(const name_pair & n) const;
    void clear();

    void show_all(bool val);

private:
    bool m_show_all;

    typedef std::set<name_pair> set;
    set m_valid_names;
};
typedef filter_type filter;

