#pragma once

#include <win32gui/spy/spy.hpp>

using win32::gui::spy_event;

struct event_monitor;

const int INVALID_PARENT_ID = -2;


/** 
    The spy message we're showing to the user
*/
struct friendly_spy_event {
    friendly_spy_event();

    // if true, this event is complete. There is nothing more to update.
    bool is_complete() const { 
        return spent_time_ms >= 0 && (parent_id != INVALID_PARENT_ID);
    }

    void mark_complete() {
        spent_time_ms = 0;
        parent_id = -1;        
    }

    // the class name of the window this message is for. Note that it does not contain
    // any spaces (it can be read back as a word)
    std::string class_name;

    // In order to uniquely identify the control this message is for. 
    int control_id;
    // (by knowing the parent (dialog), we can find out the user-friendly name of this control, 
    //  like, ID_user_name or so)
    int parent_id;

    // the indenting of this message (for instance, if this message is a message
    // of another message, and so on).
    int indent;

    // raw message
    HWND h;
    UINT msg;
    WPARAM w;
    LPARAM l;

    DWORD thread_id;

    time_t start_time;

    // the time of milliseconds spent in this message
    // if -1, we don't know yet
    int spent_time_ms;

    // position of the mouse, when this message happened
    win32::gui::point pos;
    win32::gui::point client_pos;

    // extra user-friendly properties to show.
    typedef std::map<std::string, std::string> coll;
    coll extras;

};

bool operator==(const friendly_spy_event & first, const friendly_spy_event & second);
inline bool operator!=(const friendly_spy_event & first, const friendly_spy_event & second) {
    return !(first == second);
}


