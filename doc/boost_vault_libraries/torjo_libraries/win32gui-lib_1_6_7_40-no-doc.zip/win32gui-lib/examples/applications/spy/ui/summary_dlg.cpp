#include "StdAfx.h"
#include ".\summary_dlg.h"

#include "win32gui_res/summary.hpp"

summary_dlg::summary_dlg(void)
{
}

summary_dlg::~summary_dlg(void)
{
}

int summary_dlg::dialog_id() { return dialog_id_; }
