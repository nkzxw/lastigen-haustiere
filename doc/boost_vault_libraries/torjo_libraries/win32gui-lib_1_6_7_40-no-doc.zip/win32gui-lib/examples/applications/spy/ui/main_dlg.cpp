#include "StdAfx.h"
#include ".\main_dlg.h"
#include "event_monitor.h"
#include "id_to_name.h"
#include "util/string_util.h"

#include "ui/filter_dlg.h"
#include "win32gui_res/main.hpp"

using namespace win32::gui;

struct main_dlg_handler : event_handler<main_dlg_handler, main_dlg> {
    handle_event on_drop_files(w_param<HDROP> h) {
        self->on_drop_files(h);
        return event<WM_DROPFILES>().HANDLED_BY(&me::on_drop_files);
    }

};


main_dlg::main_dlg(void) : m_monitor(new event_monitor), m_id_to_name(new id_to_name( fs::path() ) ) {
}

main_dlg::~main_dlg(void)
{
}

int main_dlg::dialog_id() { return dialog_id_; }

const event_monitor& main_dlg::monitor() const {
    return *m_monitor;
}


void main_dlg::on_drop_files(HDROP h) {
    int files_count = DragQueryFile(h, (UINT)-1, 0, 0);
    for ( int idx = 0; idx < files_count; ++idx) {
        int chars = DragQueryFile(h, idx, 0, 0);
        std::string file;
        file.resize( chars + 1);
        DragQueryFile(h, idx, &*file.begin(), chars + 1);
        if ( !file.empty() && file.end()[-1] == 0) file.erase( file.end() - 1); // erase ending '\0'

        if ( locase(fs::extension(file)) == ".txt") {
            monitor_file(file);
            break; // we're interested only in the first file
        }
        else if ( fs::is_directory(file)) {
            monitor_file(file);
            break; // we're interested only in the first file
        }
    }
    DragFinish(h);
}

namespace {
    // returns true if the directory contains the resource files ( resource.h and an .rc file)
    bool has_resource_files(fs::path dir) {
        bool has_rc = false;
        bool has_resource_h = false;

        for ( fs::directory_iterator begin(dir), end ; begin != end; ++begin) {
            if ( locase(fs::extension(*begin)) == ".rc")
                has_rc = true;
            if ( locase(begin->leaf()) == "resource.h")
                has_resource_h = true;
        }
        return has_rc && has_resource_h;        
    }
}
// monitors (spies) on this file
void main_dlg::monitor_file(fs::path file) {
    if ( fs::is_directory(file))
        // when monitoring a directory - actually monitoring its spy file...
        file = file / "win32gui_spy.txt";
    m_file_name->text(file.string());

    m_monitor->monitor_file( file);

    fs::path dir = file.branch_path();
    fs::path res_dir;
    if ( has_resource_files( dir))
        res_dir = dir;
    else if ( has_resource_files( dir / ".."))
        res_dir = dir / "..";
    else if ( has_resource_files( dir / ".." / ".."))
        res_dir = dir  / ".." / "..";

    m_id_to_name = shared_ptr<id_to_name>(new id_to_name(res_dir));
    find_wnd<filter_dlg>()->refresh_filter( names() );
}


const id_to_name& main_dlg::names() const {
    return *m_id_to_name;
}


