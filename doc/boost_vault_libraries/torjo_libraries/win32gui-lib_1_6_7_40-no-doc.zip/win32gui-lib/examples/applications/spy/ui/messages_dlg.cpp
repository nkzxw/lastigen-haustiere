#include "StdAfx.h"
#include ".\messages_dlg.h"
#include "filter.h"

#include "ui/main_dlg.h"
#include "ui/filter_dlg.h"
#include "ui/summary_dlg.h"

#include "event_monitor.h"
#include <time.h>
#include <iomanip>

#include "win32gui_res/messages.hpp"
#include "win32gui_res/summary.hpp"

using namespace win32::gui;
using namespace boost::rangelib;

namespace {
    int MONITOR_TIMER = unique_timer_id();

    std::string indent_spaces(int indent) {
        switch ( indent) {
        case 0: return "";
        case 1: return "    ";
        case 2: return "        ";
        case 3: return "            ";
        case 4: return "                ";
        case 5: return "                    ";
        default: {
            std::string s;
            s.resize(indent * 4);
            return s;
                 }

        }
    }
}

struct messages_dlg_handler : event_handler<messages_dlg_handler, messages_dlg> {
    handle_event on_timer(wm::timer::arg a, mark_event_not_handled) {
        if ( a.timer_id == MONITOR_TIMER)
            refresh_events();
        return event_ex<wm::timer>().HANDLED_BY(&me::on_timer);
    }

private:
    typedef messages_dlg::friendly_info friendly_info;
    
    void update_event_visually(int list_index, const friendly_info & info) {
        std::string event_name ;
        bool event_name_found = false;
        if ( crange<const friendly_spy_event::coll> r = rng::coll_find( info.event.extras, "event") ) {
            event_name_found = true;
            event_name = r->second;
        }
        else
            event_name = str_stream() << info.event.msg;

        std::string class_name = info.event.class_name;
        if ( class_name == "#32770") class_name = "dialog";
        std::ostringstream text;
        text << indent_spaces(info.event.indent)
             << info.friendly_names.name << " [" << class_name << "] "
             << event_name;
    
        bool has_extra = (info.event.extras.size() > 1 && event_name_found) ||
            (info.event.extras.size() > 0 && !event_name_found);
        if ( has_extra) {
            // extra information
            text << " (";
            bool is_first_extra = true;
            for ( crange<const friendly_spy_event::coll> r(info.event.extras); r; ++r)
                if ( r->first != "event") {
                    if ( !is_first_extra) text << ", ";
                    text << r->first << "=" << r->second;
                    is_first_extra = false;
                }
            text << ")";
        }

        std::string duration;
        tm t = *localtime(&info.event.start_time);
        duration = str_stream() 
            // the duration...
            << std::setw(3) << std::setfill('0') << (info.event.spent_time_ms / 1000) << "."
            << std::setw(3) << std::setfill('0') << (info.event.spent_time_ms % 1000) << " ("
            // and the start time
            << std::setw(2) << std::setfill('0') << t.tm_hour << ":"
            << std::setw(2) << std::setfill('0') << t.tm_min  << ":"
            << std::setw(2) << std::setfill('0') << t.tm_sec << ")";

        std::string pos = str_stream() 
            << std::setw(3) << std::setfill('0') << info.event.client_pos.x << ":"
            << std::setw(3) << std::setfill('0') << info.event.client_pos.y << " ("
            << std::setw(3) << std::setfill('0') << info.event.pos.x << ":"
            << std::setw(3) << std::setfill('0') << info.event.pos.y << ")";

        m_list->item(list_index, 1, lv_item().text(text.str()));
        m_list->item(list_index, 2, lv_item().text(duration) );
        m_list->item(list_index, 3, lv_item().text(pos));
    }

    // refreshes the events - based on the current filter
    void refresh_events() {
        const filter & filt = find_wnd<filter_dlg>()->filter();

        typedef std::set<int> set;
        set to_del;
        set to_update;
        set to_add;

        const event_monitor & monitor = find_wnd<main_dlg>()->monitor();
        const id_to_name & translator = find_wnd<main_dlg>()->names();
        int begin_id = monitor.begin_event_id(), end_id = monitor.end_event_id();

        // first, see which elements need updating, and which need deletion
        typedef messages_dlg::friendly_coll coll;
        for ( crange<coll> r_event(self->m_events); r_event; ++r_event) {
            bool still_exists = r_event->first >= begin_id && r_event->first < end_id;
            if ( still_exists) {
                friendly_spy_event & cur_event = r_event->second.event;
                // see if needs update
                if ( !cur_event.is_complete() ) {
                    // recalculate
                    friendly_spy_event update = monitor.get_event( r_event->first);
                    if ( update != cur_event) {
                        cur_event = update;
                        r_event->second.friendly_names = translator.names( cur_event.control_id, cur_event.parent_id );
                        to_update.insert( r_event->first);
                    }
                }
                else
                    ; // this is already complete - nothing to update anymore

                // see if still matches filter
                if ( filt.matches_name( r_event->second.friendly_names)  )
                    ; // still ok
                else {
                    // does not match filter
                    to_update.erase( r_event->first);
                    to_del.insert( r_event->first);
                }
            }
            else
                to_del.insert( r_event->first);
        }

        // FIXME when monitoring for adding, I can optimize it - that is,
        // I need to read all events, only if the filter changes!

        // now, see which elements should be added
        //
        // read all events
        std::vector<int> all_ids;
        all_ids.reserve( end_id - begin_id);
        for ( int idx = begin_id; idx < end_id; ++idx) all_ids.push_back(idx);
        spy_event_array all_events;
        monitor.get_events(all_ids, all_events);
        int cur_event_id = begin_id;
        for ( crange<const spy_event_array> r_event(all_events); r_event; ++r_event, ++cur_event_id) 
            if ( !rng::coll_find(self->m_events, cur_event_id)) {
                name_pair names = translator.names( r_event->control_id, r_event->parent_id);
                if ( filt.matches_name( names))
                    to_add.insert(cur_event_id);
            }
            else
                ; // event already exists

        if ( to_del.empty() && to_update.empty() && to_add.empty())
            return; // nothing to update..

        // we want to also keep the current selection...
        int old_sel = m_list->sel();
        int sel_event_id = -1;
        if (old_sel >= 0 && !self->m_events.empty())
            sel_event_id = rng::advanced(self->m_events.begin(),old_sel)->first;
        // see if we're to show the last event as selected
        bool is_sel_last = (old_sel < 0) || (sel_event_id > -1 && sel_event_id == self->m_events.rbegin()->first);

        m_list->set_redraw(false);

        // first, do update
        for ( crange<const set> r_update(to_update); r_update; ++r_update) {
            coll::iterator event = self->m_events.find( *r_update);
            int list_index = (int)std::distance( self->m_events.begin(), event);
            update_event_visually( list_index, event->second); 
        }

        // do deletions
        for ( crange<const set> r_del(to_del); r_del; ++r_del) {
            coll::iterator event = self->m_events.find( *r_del);
            int list_index = (int)std::distance( self->m_events.begin(), event);
            m_list->del_item(list_index);
            self->m_events.erase( *r_del);
        }

        // do additions
        for ( crange<const set> r_add(to_add); r_add; ++r_add) {
            int id = *r_add;
            const friendly_spy_event & new_event = all_events[id - begin_id];
            name_pair names = translator.names( new_event.control_id, new_event.parent_id);
            coll::iterator inserted = self->m_events.insert( std::make_pair(id, friendly_info(new_event,names)) ).first;
            int list_index = (int)std::distance( self->m_events.begin(), inserted);
            m_list->insert_item( list_index, lv_item().text(str_stream() << id) );
            update_event_visually(list_index, inserted->second);
        }

        int new_sel;
        if ( is_sel_last) 
            new_sel = m_list->item_count() - 1;
        else {
            coll::iterator found = self->m_events.lower_bound(sel_event_id);
            new_sel = (int)std::distance(self->m_events.begin(), found);
        }
        if ( new_sel > 0) {
            m_list->sel(new_sel);
            m_list->ensure_visible(new_sel);
        }

        m_list->set_redraw(true);
        m_list->invalidate();

        // update summary
        find_wnd<summary_dlg>()->child<summary_::m_description_>()->text( 
            str_stream() << "Total <font color=green>" << end_id 
                << "</font> , Filtered <font color=blue>" << (int)self->m_events.size() << "</font>"
            );
    }


};


messages_dlg::messages_dlg(void) {
    add_resizable_ctrl(m_list_::id, size_xy);

    m_list->add_col( lv_col().text("ID").width(50) );
    m_list->add_col( lv_col().text("Message").width(400) );
    m_list->add_col( lv_col().text("Duration").width(150) );
    m_list->add_col( lv_col().text("Mouse Pos").width(100) );

    m_list->extended_style( m_list->extended_style() | list_ctrl_::extended_style::full_row_select);
    set_timer(MONITOR_TIMER, 700);
}

messages_dlg::~messages_dlg(void)
{
}

int messages_dlg::dialog_id() { return dialog_id_; }
