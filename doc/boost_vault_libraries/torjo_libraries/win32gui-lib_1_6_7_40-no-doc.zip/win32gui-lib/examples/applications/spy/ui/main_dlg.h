#pragma once
#include "shellapi.h"


struct main_dlg_handler;
struct event_monitor;
struct id_to_name;

struct main_dlg : wnd_extend<dialog, main_dlg> {
public:
    main_dlg(void);
    ~main_dlg(void);
    static int dialog_id();

    const event_monitor& monitor() const;
    const id_to_name& names() const;

    void monitor_file(fs::path file);
private:
    friend struct main_dlg_handler;
    void on_drop_files(HDROP h);

private:
    shared_ptr<event_monitor> m_monitor;
    shared_ptr<id_to_name> m_id_to_name;
};
