#pragma once

struct summary_dlg : wnd_extend<dialog,summary_dlg> {
public:
    summary_dlg(void);
    ~summary_dlg(void);
    static int dialog_id();
};
