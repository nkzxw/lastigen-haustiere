#include "StdAfx.h"
#include ".\event_monitor.h"
#include <boost/thread/thread.hpp>
#include "util/string_util.h"

using namespace boost::rangelib;

event_monitor::event_monitor() : m_max_event_count(5000), m_first_event_id(0) {
    // make sure very few reallocations
    m_events.reserve(m_max_event_count);

    using namespace boost;
    thread( bind(&event_monitor::do_monitor, this));
    thread( bind(&event_monitor::process_raw_events, this));
}

event_monitor::~event_monitor(void) {
}

// clears all monitored events
void event_monitor::clear() {
    scoped_lock lk(m_cs);
    m_raw_events.clear();
    m_events.clear();
    m_first_event_id = 0;
}

namespace {
    void remove_trailing_spaces(std::string & str) {
        while ( !str.empty() && isspace(*str.rbegin()))
            str.resize( str.size() - 1);
    }
}


// monitors the file, and adds raw events, as it reads them
void event_monitor::do_monitor() {
    fs::path file ;
    { scoped_lock lk(m_cs);
      file = m_monitor_file; }

    // the last known size of the file we're monitoring
    int old_size = 0;
    while ( true) {
        ::Sleep(200);

        fs::path cur_file;
        { scoped_lock lk(m_cs);
          cur_file = m_monitor_file; }
        if ( file != cur_file) {
            // we've started monitoring a new file
            clear();
            file = cur_file;
            old_size = 0;
            continue;
        }
        if ( file.empty())
            continue; // no file to monitor, yet

        int new_size = (int)fs::file_size(file);
        if ( new_size == old_size) continue;
    
        if ( new_size < old_size) {
            // file is rewritten at this moment
            clear();
            old_size = 0;
        }

        std::ifstream in( file.string().c_str(), std::ios::in | std::ios::binary );
        in.seekg( old_size);

        raw_event_array new_events;
        std::string line;
        if ( old_size <= 0) {
            // note: first line - the version
            std::getline(in, line);
        }

        while ( std::getline(in, line)) {
            if ( line.empty() ) continue;
            remove_trailing_spaces(line);
            std::istringstream line_in(line);
            spy_event msg;
            if ( line_in >> msg) {
                new_events.push_back(msg);
                old_size = in.tellg();
            }
        }

        if ( !new_events.empty()) {
            scoped_lock lk(m_cs);
            m_raw_events.insert(m_raw_events.end(), new_events.begin(), new_events.end());
        }
    }
}

namespace {
    // reads:
    // - a value, or 
    // - a string, which is surrounded by quotes
    //   If the string contains inner quotes, they are doubled.
    std::string read_val_or_str(std::istream & in) {
        std::string str;

        char ch = 0;
        in >> ch;
        if ( !in) 
            return str; // already failed
        if ( ch == '"') {
            while ( in) {
                ch = in.get();
                if ( ch == '"') {
                    ch = in.get();
                    if ( ch == '"')
                        str += ch;
                    else {
                        if (in)
                            in.putback(ch);
                        else 
                            // we've read the last character, which is 
                            // the ending of the string
                            //
                            // if we ended up here, we have not failed...
                            in.clear();
                        return str;
                    }
                }
                else
                    str += ch;            
            }
        }
        else { 
            // read up to the first space and/or punctuation
            in.putback(ch);
            in >> str;
        }
        return str; 
    }

    typedef std::map<std::string, std::string> name_to_value_coll;
    name_to_value_coll name_to_value_pairs(const std::string & pairs) {
        std::istringstream in(pairs);

        name_to_value_coll nv;
        while ( in) {
            std::string name;
            std::string val;
            std::getline(in, name, '=');
            str_trim(name);
            if ( !name.empty()) {
                val = read_val_or_str(in);
                if ( name != "[eor]")
                    nv[name] = val;
                else
                    ; // this signals end-of-record
            }
        }
        return nv;
    }


    struct spy_info {
        spy_info( const spy_event & e = spy_event() ) : m_event(e), spent_time_ms(-1), indent(0), friendly_id(-1) {
            extras = name_to_value_pairs(m_event.extra);
        }

        // if true, this is a fully read event
        bool is_complete() const {
            return spent_time_ms >= 0 && (m_event.parent_id != INVALID_PARENT_ID);
        }

        // marks this as a fully read event;
        // useful when we're holding a too-old event
        void mark_complete() {
            spent_time_ms = 0;
            m_event.parent_id = -1;        
        }

        void set_parent_id(int id) {
            m_event.parent_id = id;
        }

        // don't allow to modify event, since 'extras' depends on it
        const spy_event & event() const { return m_event; }
    private:
        spy_event m_event;

    public:
        // how many millisecs have been spent here?
        // if -1, we don't yet know
        int spent_time_ms;

        // the event' indent - if -1, we don't yet know it.
        int indent;

        // the ID of the matched friendly message, if any
        int friendly_id;

        // the extra information for this event, translated into name-to-value pairs
        name_to_value_coll extras;
    };


    typedef shared_ptr<spy_info> spy_info_ptr;
    typedef std::vector<spy_info_ptr> spy_info_array;

    bool is_complete(const spy_info_ptr & val) { return val->is_complete(); }  

    struct thread_info {
        thread_info() : cur_indent(0) {}

        spy_info_array events;
        int cur_indent;
    };

    // appends all values from src, to dest. If they already exist, it overrides them
    void update_extra(name_to_value_coll & dest, const name_to_value_coll & src) {
        for ( crange<const name_to_value_coll> r(src); r; ++r)
            dest[ r->first ] = r->second;
    }


    friendly_spy_event create_friendly_event(const spy_info & raw) {
        friendly_spy_event friendly;
        friendly.class_name = raw.event().class_name;
        friendly.control_id = raw.event().control_id;
        friendly.parent_id = raw.event().parent_id;
        friendly.indent = raw.indent;
        friendly.h = raw.event().h;
        friendly.msg = raw.event().msg;
        friendly.l = raw.event().l;
        friendly.w = raw.event().w;
        friendly.thread_id = raw.event().thread_id ;
        friendly.start_time = raw.event().start_time;
        friendly.spent_time_ms = raw.spent_time_ms ;
        friendly.pos = raw.event().pos ;
        friendly.client_pos = raw.event().client_pos ;
        friendly.extras = raw.extras ;
        return friendly;
    }

    void update_friendly_event(friendly_spy_event & friendly, const spy_info & raw) {

        // Note: the commented ones could not change

        //friendly.class_name = raw.event().class_name;
        //friendly.control_id = raw.event().control_id;
        friendly.parent_id = raw.event().parent_id;
        //friendly.indent = raw.indent;
        //friendly.h = raw.event().h;
        //friendly.msg = raw.event().msg;
        //friendly.l = raw.event().l;
        //friendly.w = raw.event().w;
        //friendly.thread_id = raw.event().thread_id ;
        //friendly.start_time = raw.event().start_time;
        friendly.spent_time_ms = raw.spent_time_ms ;
        //friendly.pos = raw.event().pos ;
        //friendly.client_pos = raw.event().client_pos ;
        friendly.extras = raw.extras ;
    }


}




// processes the raw events, and turns them into user-friendly events
void event_monitor::process_raw_events() {
    // contains all events that are not yet fully processed
    spy_info_array queue;
    // Key = thread_id
    typedef std::map<DWORD, thread_info> thread_coll; 
    // for a given thread, contains all its events that are not matched yet
    thread_coll thread_queue;

    typedef std::map<HWND, spy_info_array> unresolved_parent_coll;
    // for some events, we might not know the parent's ID yet. Until we do find the parent's ID,
    // we keep them here
    unresolved_parent_coll unresolved_parents;

    while ( true) {
        ::Sleep(200);
        bool events_have_been_cleared;
        { scoped_lock lk(m_cs);
          events_have_been_cleared = m_raw_events.empty(); }
        if ( events_have_been_cleared) {
            // the file has changed, or has been cleared
            queue.clear();
            thread_queue.clear();
          }
          
        raw_event_array unprocessed;
        { scoped_lock lk(m_cs);
          std::swap(unprocessed, m_raw_events);
        }
        // process the events
        for ( crange<raw_event_array> r_unprocessed(unprocessed); r_unprocessed; ++r_unprocessed) {
            spy_info_ptr new_event = spy_info_ptr(new spy_info(*r_unprocessed));
            DWORD thread_id = new_event->event().thread_id;
            // ... the thread this event belongs to
            thread_info & event_thread = thread_queue[thread_id];
            if ( new_event->event().is_start) {
                // it's the "start" of a new event
                new_event->indent = event_thread.cur_indent++;
                event_thread.events.push_back( new_event);
                queue.push_back( new_event);
                if ( new_event->event().parent_id == INVALID_PARENT_ID)
                    unresolved_parents[ new_event->event().h ].push_back( new_event);
                else {
                    // it's a valid parent ID. If so, update all invalid records so far, for this handle
                    crange<unresolved_parent_coll> r_unresolved = rng::coll_find(unresolved_parents, new_event->event().h);
                    if ( r_unresolved) {
                        // yup, there are a few invalid ones...
                        int parent_id = new_event->event().parent_id;
                        for ( crange<spy_info_array> r_invalid(r_unresolved->second); r_invalid; ++r_invalid)
                            (*r_invalid)->set_parent_id(parent_id);
                    }
                    unresolved_parents.erase( new_event->event().h );
                }
            }
            else {
                // it's the "end" of an event, let's look for it(s start)!
                int event_id = new_event->event().unique_id;
                // it should be exactly the last element in our queue...
                bool found = !event_thread.events.empty() && (event_thread.events.back()->event().unique_id == event_id);
                if ( found) {
                    spy_info & last = *(event_thread.events.back());
                    // there should have passed some time between start & end...
                    assert( new_event->event().clock_time >= last.event().clock_time);
                    double spent_secs = ((double)new_event->event().clock_time - (double)last.event().clock_time) / CLOCKS_PER_SEC;
                    last.spent_time_ms = (int)(spent_secs * 1000);
                    // note: on end of event, we might have more "extra" information.
                    update_extra(last.extras, new_event->extras );

                    // ... the next event, if it's a "start" event, will have the same indent
                    event_thread.cur_indent = last.indent;
                    // the event has been matched. No need to keep it here anymore
                    event_thread.events.erase( event_thread.events.end() - 1);
                }
                else
                    // this "end" event should have had a corresponding "start"
                    assert(false);
            }
        }

        {
        // update their friendly counterparts
        scoped_lock lk(m_cs);
        for ( crange<spy_info_array> r_queue(queue); r_queue; ++r_queue) {
            spy_info & cur_event = **r_queue;
            // ... if true, we have a friendly-event correspondence
            bool has_correspondence = (cur_event.friendly_id != -1);
            bool needs_update = !has_correspondence || cur_event.is_complete();
            if ( needs_update) {
                // update the friendly counterpart
                bool is_new = cur_event.friendly_id == -1;
                if ( is_new) {
                    // we'll create the friendly event now
                    friendly_spy_event friendly_event = create_friendly_event(cur_event);
                    m_events.push_back( friendly_event);
                    cur_event.friendly_id = m_first_event_id + (int)m_events.size() - 1;
                }
                else {
                    // existing friendly event
                    int friendly_idx = cur_event.friendly_id - m_first_event_id ;
                    bool still_exists = (friendly_idx >= 0) && (friendly_idx < (int)m_events.size());
                    if ( still_exists)
                        update_friendly_event( m_events[friendly_idx], cur_event);
                    else
                        // event is too old, mark for removal
                        cur_event.mark_complete();
                }
            }
        }
        } // scoped_lock

        // erase all complete events (they don't need any more updating) ...
        using namespace boost;
        rng::erase(queue, rng::remove_if(queue, &is_complete ));

        // if we have too many friendly events, erase the oldest
        { scoped_lock lk(m_cs);
          if ( (int)m_events.size() > m_max_event_count) {
            int to_erase_count = (int)m_events.size() - m_max_event_count;
            m_events.erase( m_events.begin(), m_events.begin() + to_erase_count);
            m_first_event_id += to_erase_count;
          }
        }
    }
}


/** 
    Returns the events from the given array.
*/
void event_monitor::get_events(const std::vector<int> & ids, spy_event_array & msgs) const {
    msgs.clear();
    msgs.resize( ids.size() ); // make sure there there will be no reallocations 
    scoped_lock lk(m_cs);

    spy_event_array::iterator cur_msg = msgs.begin();
    typedef std::vector<int> array;
    for ( crange<const array> r(ids); r; ++r, ++cur_msg)
        get_event_impl(*r, *cur_msg);
}


/** 
    returns the event having this ID, or an empty event if this event does not exist. 

    To see if this event exists, the event_id should be in the 
    [ begin_event_id(), end_event_id() ) interval
*/
friendly_spy_event event_monitor::get_event(int event_id) const {
    friendly_spy_event e;
    {
    scoped_lock lk(m_cs);
    get_event_impl(event_id, e);
    }
    return e;
}


/** 
    returns the event having this ID, or an empty event if this event does not exist. 

    To see if this event exists, the event_id should be in the 
    [ begin_event_id(), end_event_id() ) interval

    @remarks caller is responsible for locking the function.
*/
void event_monitor::get_event_impl(int event_id, friendly_spy_event & result) const {
    event_id -= m_first_event_id;
    if ( event_id >= 0 && event_id < (int)m_events.size())
        result = m_events[event_id];
    else
        result = friendly_spy_event();
}



// returns the first event ID
int event_monitor::begin_event_id() const {
    scoped_lock lk(m_cs);
    return m_first_event_id;
}

// returns the end-passed-one event ID (that is, you go from begin to <end)
int event_monitor::end_event_id() const {
    scoped_lock lk(m_cs);
    return m_first_event_id + (int)m_events.size();
}

void event_monitor::monitor_file(fs::path file) {
    scoped_lock lk(m_cs);
    m_monitor_file = file;
}




