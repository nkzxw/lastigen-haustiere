#include "StdAfx.h"
#include ".\spy_event.h"

friendly_spy_event::friendly_spy_event() : indent(0), h(0), msg(0), w(0), l(0), thread_id(0), start_time(0), spent_time_ms(-1) {
}


bool operator==(const friendly_spy_event & first, const friendly_spy_event & second) {
    return first.class_name == second.class_name &&
        first.control_id == second.control_id &&
        first.parent_id == second.parent_id &&
        first.indent == second.indent &&
        first.h == second.h &&
        first.msg == second.msg &&
        first.w == second.w &&
        first.l == second.l &&
        first.thread_id == second.thread_id &&
        first.start_time == second.start_time &&
        first.spent_time_ms == second.spent_time_ms &&
        first.pos == second.pos &&
        first.client_pos == second.client_pos &&
        first.extras == second.extras;
}


