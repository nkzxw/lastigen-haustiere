

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "stdafx.h"
// main_dlg.cpp
#include "main_dlg.h"
#include <win32gui/event_handler.hpp>

#include "setting/computer.h"

#include "ui/explorer_dlg.h"
#include "ui/settings_dlg.h"
#include "ui/enter_settings_dlg.h"
#include "ui/tab_forward_ctrl.h"

#include "ui/panes/right_pane_explorer_dlg.h"
#include "ui/build/single_build_dlg.h"
#include "ui/build_statistics/build_statistics_dlg.h"

// FIXME for Resource Splitter, I should forward declare the setting_combo
#include "ui/setting_combo.h"
#include "ui/browse_button.h"


#include "win32gui_res/main.hpp"
#include "win32gui_res/explorer.hpp"
#include "win32gui_res/settings.hpp"
#include "win32gui_res/enter_settings.hpp"
#include "win32gui_res/right_pane_explorer.hpp"

#include "win32gui_res/aboutbox.hpp"
#include "win32gui_res/single_build.hpp"


using namespace win32::gui;
using namespace win32::gui::res_id;

namespace {
    int TIMER_SAVE = unique_timer_id();
}

struct main_dlg_handler : event_handler<main_dlg_handler, main_dlg> {

    handle_event on_timer(wm::timer::arg a, mark_event_not_handled) {
        if ( a.timer_id == TIMER_SAVE)
            do_save_settings();
        return event_ex<wm::timer>().HANDLED_BY(&me::on_timer);
    }

    handle_event on_about() {
        create_modal_dlg<dialog>(window()->top_parent(), create_info().id(aboutbox_::dialog_id_)).wait();
        return command<menu_::tool_about>().HANDLED_BY(&me::on_about);
    }

    handle_event on_exit() {
        ::PostQuitMessage(0);
        return command<menu_::tool_exit>().HANDLED_BY(&me::on_exit);
    }

    handle_event on_tool_build() {
        find_wnd<single_build_dlg>()->send_command(single_build_::m_build_::id);
        return command<menu_::tool_build>().HANDLED_BY(&me::on_tool_build);
    }
    handle_event on_tool_rebuild() {
        find_wnd<single_build_dlg>()->send_command(single_build_::m_rebuild_::id);
        return command<menu_::tool_rebuild>().HANDLED_BY(&me::on_tool_rebuild);
    }
    handle_event on_tool_clean() {
        find_wnd<single_build_dlg>()->send_command(single_build_::m_clean_::id);
        return command<menu_::tool_clean>().HANDLED_BY(&me::on_tool_clean);
    }

    handle_event on_tool_show_statistics() {
        create_dlg<build_statistics_dlg>(null_wnd);
        return command<menu_::tool_show_statistics>().HANDLED_BY(&me::on_tool_show_statistics);
    }


private:
    void do_save_settings() {
        using persist::setting;
        bool do_save_all = setting<bool>("app.do_save_all", persist::err::set_def(true) );
        if ( do_save_all)
            user_comp().save_all_setting_values();
    }
};

namespace {
    void focus_from_explorer(wnd<> &before, wnd<> & after) {

        if ( find_wnd<right_pane_explorer_dlg>()->child<tab_dialog>(right_pane_explorer_::m_tabdialog1_::id)->sel() == 0) {
            // focus to "Settings"
            after = find_wnd<settings_dlg>()->child<settings_::m_dirs_>();
            before = find_wnd<settings_dlg>()->child<settings_::m_compiler_>();
        }
        else
            ; // focus on another window than "Settings"
    }

    void focus_from_setting_from_setting_dirs(wnd<> & before, wnd<> & after) {
        after = find_wnd<settings_dlg>()->sub_wnd<enter_settings_dlg>()->child<enter_settings_::m_sett_list_>();
        //before = find_wnd<settings_dlg>()->child<settings_::m_dirs>();
        before = after;
    }

    void focus_from_compiler(wnd<> & before, wnd<> & after) {
        after = find_wnd<explorer_dlg>()->child<explorer_::m_dirs_>();
        //before = find_wnd<settings_dlg>()->child<settings_::m_compiler>();
        before = after;
    }

    void focus_from_enter_settings(wnd<> & before, wnd<> & after) {
        after = find_wnd<settings_dlg>()->child<settings_::m_configuration_>();
        before = find_wnd<settings_dlg>()->child<settings_::m_dirs_>();
    }
}


main_dlg::main_dlg() {
    set_timer(TIMER_SAVE, 1000);

    // allow Tab-key to work as expected...
    find_wnd<explorer_dlg>()->child<tab_forward_ctrl>(explorer_::m_forwardtab1_::id)->call_on_focus( focus_from_explorer);
    find_wnd<settings_dlg>()->child<tab_forward_ctrl>(settings_::m_forwardtab2_::id)->call_on_focus( focus_from_setting_from_setting_dirs);
    find_wnd<settings_dlg>()->child<tab_forward_ctrl>(settings_::m_forwardtab1_::id)->call_on_focus( focus_from_compiler);
    find_wnd<settings_dlg>()->sub_wnd<enter_settings_dlg>()->child<tab_forward_ctrl>(enter_settings_::m_forwardtab1_::id)->call_on_focus( focus_from_enter_settings);
}

main_dlg::~main_dlg() {
}

int main_dlg::dialog_id() { return dialog_id_; }

