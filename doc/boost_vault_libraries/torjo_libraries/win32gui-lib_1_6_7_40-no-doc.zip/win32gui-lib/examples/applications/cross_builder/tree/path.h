

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "tree/tree.h"
#include <stdexcept>
#include "setting/name.h"

namespace tree {

namespace detail {
    // splits the path, into the first directory, and the rest
    inline std::pair<std::string,std::string> sub_path(const std::string & path) {
        std::string norm = normalized_path_name(path);
        std::string::size_type found = norm.find("/");
        std::string dir = norm.substr(0, found);
        std::string child_path = found != std::string::npos ? norm.substr( found + 1) : ""; 
        return std::make_pair(dir, child_path);
    }

    template<class item_type, class item_ref> item_ref& sub_item_at_path_impl(item_ref &t, const std::string & path) {

        std::pair<std::string,std::string> split = sub_path(path);
        item_ref * child_item = t.child_by_name(split.first);
        if ( !child_item)
            PWC_THROW std::runtime_error("path not found: ");

        if ( split.second.empty() )
            return *child_item;
        else
            return sub_item_at_path_impl<item_type, item_ref>( *child_item, split.second);
    }

    template<class item_type, class item_ptr> item_ptr exists_item_at_path_impl(item_ptr t, const std::string & path) {

        std::pair<std::string,std::string> split = sub_path(path);
        item_ptr child_item = t->child_by_name(split.first);
        if ( !child_item)
           return 0;

        if ( split.second.empty() )
            return child_item;
        else
            return exists_item_at_path_impl<item_type, item_ptr>( child_item, split.second);
    }

}


/**
    finds the item at the given path

    Convention: 
    the path is like a file system path
    Each "A/B" means find B as a child of A

    @remarks
    Pre-condition: It assumes the path exists. Otherwise, an exception is thrown
*/
template<class e> item<e> & sub_item_at_path(item<e> & t, const std::string & path) {
    std::pair<std::string,std::string> split = detail::sub_path(path);
    if ( split.second.empty() )
        if ( split.first == t.name() ) 
            return t; // it's the root
        else
            // the path should always start with the t's name
            PWC_THROW std::runtime_error("path not found: ");
    return detail::sub_item_at_path_impl< item<e>, item<e> >(t, split.second);
}

template<class e> const item<e> & sub_item_at_path(const item<e> & t, const std::string & path) {
    std::pair<std::string,std::string> split = detail::sub_path(path);
    if ( split.second.empty() )
        if ( split.first == t.name() ) 
            return t; // it's the root
        else
            // the path should always start with the t's name
            PWC_THROW std::runtime_error("path not found: ");
    return detail::sub_item_at_path_impl< item<e>, item<e> const>(t, split.second);
}


template<class e> bool exists_item_at_path(const item<e> & t, const std::string & path) {
    std::pair<std::string,std::string> split = detail::sub_path(path);
    if ( split.second.empty() )
        if ( split.first == t.name() ) 
            return true; // it's the root
        else
            // the path should always start with the t's name
            return false;
    return detail::exists_item_at_path_impl< item<e>, item<e> const * >(&t, split.second) != 0;
}



} // namespace tree
