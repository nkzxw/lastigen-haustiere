

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "tree/tree.h"
#include "setting/setting.h"
#include "setting/setting_rule.h"

struct compiler_metadata;
typedef shared_ptr<compiler_metadata> metadata_ptr;


/** 
    @brief Keeps meta-information about a compiler

*/
struct compiler_metadata {
    compiler_metadata(fs::path dir_name, const std::string & name, metadata_ptr parent);
    ~compiler_metadata(void);

    struct dir {
        typedef enum type {
            all,
            exclude_compiler_specific
        };
    };

    std::string friendly_name() const;
    std::string full_name() const;

    tree::item<> get_dir_tree(dir::type type = dir::all ) const;

    /**
        @brief contains the settings that exist in a given metadata directory

        Metadata directories are virtual directories, that are read
        from metadata files.
    */
    struct dir_settings {
        dir_settings();

        // a user-friendly directory description
        //
        // FIXME show it!
        std::string description;

        // the settings that are found in this directory
        // (note: the same setting can be found in multiple directories)
        typedef std::vector<setting> array;
        array settings;

        // if true, this is a compiler-specific directory.
        bool is_compiler_specific;
    };

    dir_settings get_settings_at_dir(const std::string & metadata_dir_name) const;
    setting get_setting(std::string name) const;

    typedef std::vector<setting_rule> rule_array;
    rule_array rules() const;
private:
    void load_settings();
    void load_rules();

private:
    mutable critical_section m_cs;

    // the settings - each setting is uniquely identified by its normalized name.
    //                Cannot have two settings that have the same name.
    typedef std::map<std::string, setting> setting_coll;
    setting_coll m_settings;

    // the directory we've read the compiler meta-data from.
    fs::path m_dir;

    // the name that uniquely identifies this compiler
    std::string m_full_name;

    // the parent we're refining, or null if none.
    //
    // Just like any other type of data we deal with (in the User Interface),
    // meta-data can be inherited
    metadata_ptr m_parent;

    // the directory structure
    tree::item<dir_settings> m_dir_settings;

    rule_array m_rules;
};

