
// Utility Library
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
#pragma once

// reads and writes strings from/to streams

namespace io {
    
    /**
    Reads/writes strings
        
    If string contains quotes and/or spaces and/or delimeter, it's escaped:
    - quotes are pre- and appended to the stream
    - every string inner quote is doubled

    The reverse happens at reading.
    */

    struct read_str {
        read_str(std::string & val) : val(val) {}   
        mutable std::string & val;
    };

    struct write_str {
        write_str(const std::string & val) : val(val) {}
        const std::string & val;
    };

    std::ostream & operator<<(std::ostream & out, const write_str & write);
    std::istream & operator>>(std::istream & in, const read_str & read);
}

