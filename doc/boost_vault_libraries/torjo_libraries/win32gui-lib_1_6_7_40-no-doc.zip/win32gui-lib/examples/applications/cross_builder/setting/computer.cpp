

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/



/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\computer.h"
#include "tree/tree.h"
#include "tree/algorithm.h"
#include "tree/path.h"
#include "tree/fs.h"
#include "main/app.h"

#include <boost/rangelib/transform.hpp>

using namespace boost::rangelib;

bool operator<(const setting_for_compilers & first, const setting_for_compilers & second) {
    if ( first.sett.name != second.sett.name) return first.sett.name < second.sett.name;

    crange<const setting_for_compilers::compilers_set> r_first(first.compilers);
    crange<const setting_for_compilers::compilers_set> r_second(second.compilers);
    while ( r_first && r_second) {
        if ( *r_first != *r_second) return *r_first < *r_second;
        ++r_first;
        ++r_second;
    }

    if ( r_first && !r_second) 
        return false; // first has more elements, thus it's greater
    if ( !r_first && r_second)
        return true; // second has more elements, thus first < second

    // they're equal
    return false;
}

bool operator==(const setting_for_compilers & first, const setting_for_compilers & second) {
    return first.sett.is_same(second.sett) &&
        first.compilers == second.compilers;
}




computer::computer(void) : m_metadata("root"), m_compilers("root") {
    load_compiler_metadata();
    load_compilers();
}

computer::~computer(void)
{
}


namespace {
    // multiple settings coming from a certain compiler
    // first -> the settings
    // second -> the compiler name
    typedef std::pair<compiler_metadata::dir_settings, std::string> compiler_settings;
    typedef std::vector<compiler_settings> compiler_settings_array;

    typedef std::vector< compiler_metadata::dir_settings> dir_settings_array;
    typedef std::vector< const tree::item<metadata_ptr>* > meta_ptr_array;
    void append_settings_dir(
            const tree::item<metadata_ptr> & dir, 
            const meta_ptr_array & , 
            computer & user_computer,
            const std::string& dir_name, 
            compiler_settings_array & dir_setts) {
        if ( !dir.info) 
            return;
        compiler_ptr comp = user_computer.get_upper_most_compiler_for_metadata(dir.info->full_name());
        if ( !comp) 
            return;

        dir_setts.push_back( 
            compiler_settings( 
                dir.info->get_settings_at_dir(dir_name), 
                comp->path().string() ));
    }

    bool is_same_setting(const setting & first, const setting_for_compilers & second) {
        return first.is_same(second.sett);
    }

    setting_for_compiler_array merge_dir_settings(const compiler_settings_array & a) {
        // If multiple compilers have the same setting, with different types,
        // each is a different setting
        setting_for_compiler_array result;
        // for each compiler that matches a setting, append its meta name
        for ( crange<const compiler_settings_array> r(a); r; ++r) {
            for ( crange<const compiler_metadata::dir_settings::array> cur_set(r->first.settings); cur_set; ++cur_set) 
                if ( crange<setting_for_compiler_array> found = rng::find_if(result, boost::bind(is_same_setting,*cur_set,_1) ))
                    // same setting, new compiler
                    found->compilers.insert(r->second);
                else {
                    // this is a new setting/new compiler
                    result.push_back(*cur_set);
                    result.back().compilers.insert(r->second);
                }
        }

        // FIXME in the future, this might not stand (max_size = a.size())
        //       That is, if the user has selected multiple compilers (like: MSVC7.1,gcc),
        //       even though we show "All", a setting may apply to only two compilers
        int max_size = (int)a.size();
        for ( crange<setting_for_compiler_array> r(result); r; ++r)
            if ( r->compilers.size() == max_size) {
                r->compilers.clear();
                r->compilers.insert( "root/C++" ); // FIXME what about when having multiple tools?
            }

        // within these compilers, if there are any A and B such that A is a subcompiler of B, eliminate A
        for ( crange<setting_for_compiler_array> r(result); r; ++r)
            if ( r->compilers.size() > 1) {
                // at least two compilers
                std::string to_erase = "dummy";
                while ( !to_erase.empty() ) {
                    to_erase = "";
                    typedef setting_for_compilers::compilers_set set;
                    for ( crange<set> compiler_a(r->compilers); compiler_a; ++compiler_a) {
                        crange<set> compiler_b(compiler_a);
                        ++compiler_b;
                        for ( ; compiler_b; ++compiler_b) {
                            if ( compiler_a->find(*compiler_b) == 0) {
                                to_erase = *compiler_a; // A is a subcompiler of B
                                break;
                            }
                            if ( compiler_b->find(*compiler_a) == 0) {
                                to_erase = *compiler_b; // B is a subcompiler of A
                                break;
                            }
                        }
                        if ( !to_erase.empty() ) break;
                    }

                    if ( !to_erase.empty() )
                        r->compilers.erase(to_erase);
                }
            }

        return result;
    }
}

/** 
    Returns the settings from a directory, for a given compiler (or all compilers).
*/
setting_for_compiler_array computer::get_settings_at_dir(std::string compiler_name, std::string dir_name) const {
    dir_name = normalized_path_name(dir_name);
    compiler_name = normalized_path_name(compiler_name);
    if ( compiler_name == "root/C++") {
        // note: we will take all settings from possible multiple compilers.
        using namespace boost;
        compiler_settings_array dirs;
        tree::for_each(m_metadata, bind(append_settings_dir,_1,_2, ref(user_comp()), dir_name, ref(dirs)) );
        return merge_dir_settings(dirs);
    }
    else {
        compiler_ptr comp = tree::sub_item_at_path(m_compilers, compiler_name).info;
        metadata_ptr meta;
        if ( comp )
            meta = comp->metadata();
        if ( meta) {
            setting_for_compiler_array result;
            rng::copy(meta->get_settings_at_dir(dir_name).settings, std::back_inserter(result) );
            for( crange<setting_for_compiler_array> r(result); r; ++r)
                r->compilers.insert( comp->path().string() );
            return result;
        }
    }
    // no settings...
    return setting_for_compiler_array();
}

namespace {

    struct create_meta_tree {
        typedef tree::item<metadata_ptr> meta_item;
        create_meta_tree(meta_item &meta_val) : meta_val(meta_val) {}
        meta_item &meta_val;

        void operator()(const tree::item<> & meta_dir, const std::vector<tree::item<>* > & ascendants) {

            std::string path = ""; // find out path to this directory
            for ( crange<const std::vector<tree::item<>* > > r(ascendants); r; ++r)
                path += "/" + (*r)->name();
            std::string meta_name = meta_dir.name();
            meta_item * parent = 0;
            if ( !path.empty() )
                parent = &tree::sub_item_at_path(meta_val, "root" + path);
            else
                parent = &meta_val;

            std::string dir_name = (std::string)persist::setting<std::string>("app.home") + "/root/Compiler Metadata";
            // the name that uniquely identifies a compiler metadata 
            std::string full_name = "root" + path + "/" + meta_name;
            dir_name += path + "/" + meta_name;
            parent->children.push_back(meta_name);
            parent->children.back().info = metadata_ptr(new compiler_metadata(dir_name, full_name, parent->info));
        }
    };
}

void computer::load_compiler_metadata() {
    tree::item<> metadata = tree::descendant_directory_tree( 
        (std::string)persist::setting<std::string>("app.home") + "/root/Compiler Metadata/C++" );
    tree::for_each<tree::parent_first>(metadata, create_meta_tree(m_metadata) );
}

namespace {

    struct create_compiler_tree {
        typedef tree::item<metadata_ptr> meta_item;
        typedef tree::item<compiler_ptr> compiler_item;
        create_compiler_tree (compiler_item & compiler_root, meta_item &meta_root) : compiler_root(compiler_root),meta_root(meta_root) {}
        
        compiler_item & compiler_root;
        meta_item & meta_root;

        void operator()(const tree::item<> & compiler_dir, const std::vector<tree::item<>* > & ascendants) {

            std::string path = ""; // find out path to this directory
            for ( crange<const std::vector<tree::item<>* > > r(ascendants); r; ++r)
                path += "/" + (*r)->name();
            std::string compiler_name = compiler_dir.name();

            compiler_item * parent = 0;
            if ( !path.empty() ) {
                if ( tree::exists_item_at_path(compiler_root,"root" + path) )
                    parent = &tree::sub_item_at_path(compiler_root, "root" + path);
                else {
                    BOOST_LOG(err) << "parent compiler not found " << path;
                    return;
                }
            }
            else
                parent = &compiler_root;

            std::string dir_name = (std::string)persist::setting<std::string>("app.home") + "/root/Compilers";
            dir_name += path + "/" + compiler_name;

            // find out its corresponding metadata
            std::string meta_name;
            { fs::path p = dir_name;
            while ( !fs::exists( p / "meta.txt") && !p.empty() )
                p = p.branch_path();
            if ( !p.empty() ) {
                std::ifstream in( (p / "meta.txt").string().c_str() );
                std::getline(in, meta_name);
            }
            }
            std::string compiler_path = "root" + path + "/" + compiler_name;
            metadata_ptr meta;
            if ( !meta_name.empty() ) {
                meta = tree::sub_item_at_path( meta_root, "root/" + meta_name).info;

                parent->children.push_back(compiler_name);
                parent->children.back().info = compiler_ptr(new compiler(meta, compiler_path, dir_name));
            }
            else if ( compiler_name == "C++") {
                // root compiler
                parent->children.push_back(compiler_name);
                parent->children.back().info = compiler_ptr(new compiler( metadata_ptr(), compiler_path, dir_name));
            }
            else
                BOOST_LOG(err) << "invalid compiler " << compiler_name;
        }
    };

}

void computer::load_compilers() {
    tree::item<> compilers = tree::descendant_directory_tree( 
        (std::string)persist::setting<std::string>("app.home") + "/root/Compilers/C++" );
    tree::for_each<tree::parent_first>(compilers, create_compiler_tree(m_compilers, m_metadata) );

}

/** represents the user's Computer*/
namespace {
//    static computer c;
}
computer & user_comp() {
    static computer c;
    return c;
}



tree::item<compiler_ptr> computer::get_compiler_tree() const {
    return m_compilers;
}


namespace {
    typedef shared_ptr< tree::item<> > tree_item_ptr;
    struct merge_compiler_trees {
        merge_compiler_trees(tree_item_ptr & dirs_item) : dirs_item(dirs_item) {}
        tree_item_ptr &dirs_item; // the item that will contain all setting directories

        template<class ignore> void operator()(const tree::item<compiler_ptr> & comp, const ignore&) {
            if ( !comp.info) 
                return; // does not hold any metadata
            metadata_ptr meta = comp.info->metadata();
            if ( meta) {
                // ignore all compiler-specific directories
                if ( dirs_item.get() != 0)
                    *dirs_item = tree::sorted_merge( *dirs_item, meta->get_dir_tree(compiler_metadata::dir::exclude_compiler_specific) );
                else
                    dirs_item = tree_item_ptr(new tree::item<>(meta->get_dir_tree(compiler_metadata::dir::exclude_compiler_specific) ) );
            }
        }
    };

}

/** 
    Returns the tree of directories that contain settings,
    for the given compiler path 
*/
tree::item<> computer::get_compiler_setting_dir_tree(const std::string & compiler_path) const {
    if ( compiler_path == "root/C++") {
        // merge all
        tree_item_ptr t;
        tree::for_each( m_compilers, merge_compiler_trees(t) );
        return *t;
    }
    else {
        metadata_ptr meta = tree::sub_item_at_path( m_compilers, compiler_path).info->metadata();
        return meta->get_dir_tree();
    }
}

namespace {
    typedef std::vector<compiler_ptr> compiler_array;
    typedef std::vector<const tree::item<compiler_ptr>* > tree_item_array;
    void add_compiler_to_array(compiler_array & a, metadata_ptr meta, const tree::item<compiler_ptr> & comp, const tree_item_array & ascendants) {
        if ( comp.info)
            if ( comp.info->metadata() == meta)
                a.push_back(comp.info);
    }

    bool by_len(const std::string & a, const std::string & b) {
        return a.size() < b.size();
    }
    std::string get_compiler_path(compiler_ptr c) { return c->path().string(); }
}


/** 
    For a given compiler-metadata, there might be multiple compilers that are based on it.

    It returns the upper-most compiler that is based on this metadata (all the other 
    compilers that are based on this metadata are descendants from this).

    If more than one upper-most compilers are found, it returns null.
*/
compiler_ptr computer::get_upper_most_compiler_for_metadata(const std::string & metadata_path) const {
    compiler_array compilers;
    metadata_ptr meta = tree::sub_item_at_path(m_metadata, metadata_path).info;
    using namespace boost;
    tree::for_each( m_compilers, bind(add_compiler_to_array,ref(compilers),meta,_1,_2) );
    if ( compilers.empty() ) {
        BOOST_LOG(dbg) << "getting compiler for " << metadata_path << " no compilers ";
        return compiler_ptr();
    }

    typedef std::vector<std::string> path_array;
    path_array paths;
    using namespace boost;
    rng::copy( transformed(compilers, get_compiler_path), std::back_inserter(paths));
    // upper-most path comes first
    rng::sort(paths, by_len);

    // the first path, must be an ascendant to all the other paths.
    std::string upper_most = paths[0];
    for ( crange<const path_array> r(paths); r; ++r) {
        bool is_upper = r->find(upper_most) == 0;
        if ( !is_upper) {
            BOOST_LOG(dbg) << "getting compiler for " << metadata_path << " two or more compilers exist";
            return compiler_ptr(); // two or more upper-most compilers exist
        }
    }
    // find upper-most compiler
    for ( crange<compiler_array> r(compilers); r; ++r)
        if ( (*r)->path() == upper_most) {
            BOOST_LOG(dbg) << "getting compiler for " << metadata_path << " - is: " << upper_most ;
            return *r;
        }

    assert(false); // should never end up here
    return compiler_ptr(); 
}




compiler_ptr computer::get_compiler(const std::string & compiler_path) const {
    try {
        return tree::sub_item_at_path(m_compilers, compiler_path).info;
    } catch(...) {
        throw std::runtime_error("compiler " + compiler_path + " not found");
    }
}


logical_path_setting_values_ptr computer::setting_values(const logical_path & path) {
    return m_sett.setting_values(path);
}

void computer::save_all_setting_values() {
    m_sett.save_all();
}


