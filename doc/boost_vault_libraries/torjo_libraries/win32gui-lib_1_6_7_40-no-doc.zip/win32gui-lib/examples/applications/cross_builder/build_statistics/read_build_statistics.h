

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "build/logical_path.h"
#include "setting/configuration.h"
#include "build_statistics/build_statistics.h"

namespace build_statistics {

/** 
    @brief Allow access to build statistics for a directory/compiler/config that has already been built.
*/
struct read_for_dir {
    read_for_dir(const logical_path & root, const std::string & build_prefix);


    struct path_statistics {
        path_statistics(fs::path path, const path_info & stats) : path(path), stats(stats) {}
        fs::path path;
        build_statistics::path_info stats;
    };
    typedef std::vector<path_statistics> statistics_array;

    const statistics_array & stats() { return m_stats; }
    bool has_path_stats(const logical_path & path) const;
    path_statistics path_stats(const logical_path & path) const;

private:
    void read();

private:
    // what to prepend, when persisting statistics
    std::string m_build_prefix;

    // the project's root
    logical_path m_root;

    statistics_array m_stats;

    typedef std::map<std::string, int> statistics_idx_coll;
    statistics_idx_coll m_path_to_idx;
};


}
