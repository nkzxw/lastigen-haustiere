#ifndef BOOST_OSTREAM_ITERATOR_HPP
#define BOOST_OSTREAM_ITERATOR_HPP

#include <boost/iterator.hpp>
#include <iterator>

namespace boost {
     namespace detail {
         template<class char_type, class traits_type>
         struct ostream_write_helper {
             typedef ::std::basic_ostream<char_type,traits_type> ostream_type;
             typedef ostream_write_helper<char_type,traits_type> self_type;
             ostream_write_helper( ostream_type * out, const char_type * delim)
                 : m_out( out), m_delim( delim) {}

             template< class T> self_type& operator=( const T & val) {
                 *m_out << val;
                 if ( m_delim)
                     *m_out << m_delim;
                 return *this;
             }
         private:
             ostream_type *m_out;
             const char_type * m_delim;
         };
     }

template< class char_type, class traits_type>
class ostream_iterator_t
: public ::boost::iterator< ::std::output_iterator_tag, 
::boost::detail::ostream_write_helper<char_type,traits_type> > {
         typedef ::std::basic_ostream<char_type,traits_type> ostream_type;
         typedef ::boost::detail::ostream_write_helper<char_type,traits_type> 
write_helper;
         typedef ostream_iterator_t<char_type,traits_type> self_type;
public:

	ostream_iterator_t(ostream_type& out, const char_type * delim)
         : m_out( &out), m_delim( delim) {}

	write_helper operator*() {
         return write_helper( m_out, m_delim);
     }
	self_type& operator++() {return *this; }
	self_type operator++(int) {return *this; }
private:
     ostream_type *m_out;
     const char_type * m_delim;
};


template< class c, class t>
inline ostream_iterator_t<c,t> ostream_iterator( ::std::basic_ostream<c,t> & 
out, const c * delim = 0) {
     return ostream_iterator_t<c,t>( out, delim);
}

}

#endif // BOOST_OSTREAM_ITERATOR_HPP

