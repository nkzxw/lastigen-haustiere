

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "setting/setting.h"

struct setting_array_dlg_handler ;

/** 
    @brief manages a setting that is of an array type

    Note that every entry that is empty is simply ignored, when calculating the result.
*/
struct setting_array_dlg :  wnd_extend<dialog, setting_array_dlg>, 
                            wnd_extend<resizable_wnd, setting_array_dlg> {
    setting_array_dlg(void);
    ~setting_array_dlg(void);
    static int dialog_id();

    // what to call when the user exits, by saving or cancel 
    boost::function<void()> on_exit;

    void do_edit(const std::string & str, sett::type type);
    void set_initial_enums(const setting::enum_array & enums, const std::string & initial_sel);

    std::string selected_values() const;

    sett::type type() const { return m_type; }

private:
    friend struct setting_array_dlg_handler ;
    // the type of setting we're editing.
    sett::type m_type;

    // in case it's an enumeration, this contains the array of available enums
    setting::enum_array m_enums;

    // the initial selection(s)
    std::string m_initial_sel;

    // if true, the user cancelled the editing
    bool m_cancelled;
};
