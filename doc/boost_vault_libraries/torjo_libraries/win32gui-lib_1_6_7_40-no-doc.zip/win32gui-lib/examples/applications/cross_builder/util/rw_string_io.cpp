
// Utility Library
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
#include "StdAfx.h"
#include ".\rw_string_io.h"

namespace io {
    using namespace boost::rangelib;

    bool is_delimeter(char ch) {
        return ch == '/' || ch == ',' || ch == ';';
    }

    std::ostream & operator<<(std::ostream & out, const write_str & write) {
        bool contains_quote = write.val.find('"') != std::string::npos;
        bool contains_space = write.val.find(' ') != std::string::npos;
        bool contains_delim = rng::find_if(write.val, is_delimeter);

        if ( contains_quote || contains_space || contains_delim) {
            out << '"';
            for ( crange<const std::string> r(write.val); r; ++r)
                if ( *r == '"') out << "\"\"";
                else out << *r;
            return out << '"';
        }
        else
            return out << write.val;
    }

    std::istream & operator>>(std::istream & in, const read_str & read) {
        read.val.erase();
        char ch = 0;
        in >> ch;
        if ( !in) 
            return in; // already failed
        if ( ch == '"') {
            while ( in) {
                ch = in.get();
                if ( ch == '"') {
                    ch = in.get();
                    if ( ch == '"')
                        read.val += ch;
                    else {
                        if (in)
                            in.putback(ch);
                        else 
                            // we've read the last character, which is 
                            // the ending of the string
                            //
                            // if we ended up here, we have not failed...
                            in.clear();
                        return in;
                    }
                }
                else
                    read.val += ch;            
            }
        }
        else { 
            // read up to the first space and/or punctuation
            read.val += ch;
            while ( true) {
                ch = in.get();
                if ( isspace(ch) || is_delimeter(ch) ) {
                    in.putback(ch);
                    break;
                } 
                else if ( in) 
                    read.val += ch;                    
                else {
                    in.clear();
                    break;
                }
            }
        }
        return in; 
    }

}