// Persist Settings Library
//
// Copyright 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

// registry_setting_storage.h: interface for the registry_setting_storage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REGISTRY_SETTING_STORAGE_H__6F7D67B8_2749_4689_8102_9A35ACD5F11D__INCLUDED_)
#define AFX_REGISTRY_SETTING_STORAGE_H__6F7D67B8_2749_4689_8102_9A35ACD5F11D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning (disable :4786) // msvc

#include "setting_storage.h"

namespace persist {

class registry_setting_storage  : public setting_storage
{
public:
	registry_setting_storage( const std::string & root);
	virtual ~registry_setting_storage();
	void save(const err::handler & h );

    void get_setting( const std::string & name, std::string & value, std::string & error) const;
    void set_setting( const std::string & name, const std::string & value, std::string & error);
    void enum_settings( std::map<std::string,std::string> & values, std::string & error) const ;

private:
    std::string m_root;
};


} // namespace persist

#endif // !defined(AFX_REGISTRY_SETTING_STORAGE_H__6F7D67B8_2749_4689_8102_9A35ACD5F11D__INCLUDED_)
