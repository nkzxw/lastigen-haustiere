

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "stdafx.h"
// enter_settings_dlg.cpp
#include "enter_settings_dlg.h"
#include <win32gui/event_handler.hpp>

#include "ui/setting_combo.h"
#include "ui/browse_button.h"
#include "ui/setting_array_dlg.h"
#include "ui/settings_dlg.h"
#include "util/string_util.h"

#include "win32gui_res/enter_settings.hpp"
#include "win32gui_res/settings.hpp"
#include "win32gui_res/bitmaps.hpp"

using namespace win32::gui;
using namespace win32::gui::res_id;
using namespace boost::rangelib;

namespace {
    // images for values column
    namespace node { 
        namespace val {
            enum type {
            inherited = 0,
            overridden = 1
            };
        }

        namespace name {
            enum type {
                none = 1
            };
        }
    }

}




struct enter_settings_dlg_handler : event_handler<enter_settings_dlg_handler, enter_settings_dlg> {
    enum {
        REFRESH_SETTINGS = WM_APP + 20
    };

    // the setting we're editing right now
    struct edited_sett {
        edited_sett() : key( setting() ) {}
        int idx;
        setting_for_compilers key;
    };
    edited_sett m_edited_sett;

    // we keep a cached copy, to see when the settings change. If we refresh, but settings
    // have not changed, we should remember the last selection...
    setting_for_compiler_array m_cached_setts;

    //image_list<owned> m_images;
    image_list<shared> m_images;

    enter_settings_dlg_handler() : m_images( bitmap_::setting_nodes, 16) {
        using namespace boost;
        m_cur_setting->on_exit = bind( mem_fn(&me::on_save_setting), this);
        m_setting_array->on_exit = bind( mem_fn(&me::on_save_setting_array), this);

        m_browse->on_after_browse = bind( mem_fn(&me::on_after_browse), this, _1);
        m_browse->on_cancel_browse = bind( mem_fn(&me::on_cancel_browse), this);

        m_sett_list->images( list_ctrl_::images::small_, m_images);
        m_description->text("");
    }

    handle_event on_refresh_settings() {
        window()->set_redraw(false);
        refresh_settings();
        window()->set_redraw(true);
        window()->invalidate();
        return event<REFRESH_SETTINGS>().HANDLED_BY(&me::on_refresh_settings);
    }

    handle_event on_key_down(m_sett_list_::ev::key_down::arg a) {
        if ( a.key_code == VK_RIGHT)
            edit_setting();
        return event_ex<m_sett_list_::ev::key_down>().HANDLED_BY(&me::on_key_down);
    }

    handle_event on_sett_click() {
        point cursor = cursor_pos( m_sett_list );
        list_ctrl::subitem_hit_test_result res = m_sett_list->subitem_hit_test(cursor);
        if ( res.item >= 0 && res.subitem == 1) {
            m_sett_list->sel(res.item);
            edit_setting();
        }
        return event_ex<m_sett_list_::ev::clicked>().HANDLED_BY(&me::on_sett_click);
    }

    handle_event on_item_change() {
        // adjust "Browse" button
        int sel = m_sett_list->sel();
        bool we_have_sel_and_focus = sel >= 0 && get_focus_wnd() == m_sett_list;
        if ( we_have_sel_and_focus ) {
            bool show_browse = (self->m_setts[sel].sett.type == sett::file || self->m_setts[sel].sett.type == sett::dir)
                && !self->m_setts[sel].sett.is_array;
            if ( show_browse) {
                rectangle r = m_sett_list->sub_item_rect( sel, 1);
                r = r.convert( m_sett_list, window() );
                r.left = r.right - m_browse->client_rect().width();
                m_browse->move(r);
            }
            m_browse->show( show_browse ? window_::show::show_ : window_::show::hide);
        } 
        else 
            m_browse->show(window_::show::hide);

        // show description
        if ( sel >= 0) {
            setting cur_set = self->m_setts[ sel ].sett;
            std::string desc = "<b>" + cur_set.name.user_friendly + "</b><br>";
            if ( !cur_set.description.empty())  desc += cur_set.description;
            else                                desc += cur_set.name.user_friendly; // no description
            m_description->text(desc);
        }
        return event_ex<m_sett_list_::ev::item_changed>().HANDLED_BY(&me::on_item_change);
    }

private:
    // the string to show to the user...
    std::string setting_value_str(setting_for_compilers key) {
        std::string value;
        if ( crange<enter_settings_dlg::setting_value_coll> r = rng::coll_find(self->m_values,key)) 
            value = r->second.current.value().user_friendly;
        return value;
    }

    bool is_setting_inherited(setting_for_compilers key) {
        bool is = false;
        if ( crange<enter_settings_dlg::setting_value_coll> r = rng::coll_find(self->m_values,key)) {
            if ( r->second.current == r->second.inherited)
                if ( !r->second.is_overridden)
                    is = true;
        }
        return is;
    }

    void refresh_settings() {
        m_sett_list->del_all_items();
        if ( self->m_setts.empty() ) return;

        bool settings_have_changed = m_cached_setts != self->m_setts;
        m_cached_setts = self->m_setts;
        int old_sel = settings_have_changed ? 0 : m_sett_list->sel();

        load_settings();

        // if for same compiler, hide 3rd col.
        m_sett_list->col(2, lv_col().width(
            (self->m_show == enter_settings_dlg::hide_applies_to_compilers_col) ? 0 : 150) );

        for( crange<const setting_for_compiler_array> r = self->m_setts; r; ++r) {
            m_sett_list->add_item( 
                lv_item().text(r->sett.name.user_friendly).image(node::name::none) );
            int last = m_sett_list->item_count() - 1;
            m_sett_list->item( last, 1, 
                lv_item().text( setting_value_str(*r) )
                    .image( is_setting_inherited(*r) ? node::val::inherited : node::val::overridden ));

            std::string compiler_names;
            for ( crange<const setting_for_compilers::compilers_set> compiler_name(r->compilers); compiler_name; ++compiler_name) {
                if ( !compiler_names.empty() ) compiler_names += ", ";
                compiler_names += user_comp().get_compiler(*compiler_name)->friendly_name();
            }
            m_sett_list->item( last, 2, lv_item().text(compiler_names) );
        }

        m_sett_list->sel(old_sel);
    }

    void load_settings() {
        typedef logical_path_setting_values_ptr ptr;
        if ( self->m_path.is_empty())
            return; // nothing to load...

        ptr sv = user_comp().setting_values( self->m_path);
        for ( crange<const setting_for_compiler_array> r(self->m_setts); r; ++r) {
            fixed_setting_value fixed_val;
            fixed_val.inherited = fixed_val.current = setting_value::mixed();
            setting_key key;
            key.name = r->sett.name.normalized;
            key.config = self->m_config;
            key.setting_mode = setting_key::mode::before; // FIXME - allow "after" as well
            if ( !r->compilers.empty() ) {
                key.compiler = *(r->compilers.begin());
                fixed_val = sv->get_value( r->sett, key);
            }
            for ( crange<const setting_for_compilers::compilers_set> comp(r->compilers); comp; ++comp) {
                key.compiler = *comp;
                fixed_val = fixed_val.merge_with( sv->get_value(r->sett, key) );
            }
            self->m_values[ *r ] = fixed_val;
        }
        
    }
    
    void edit_setting() {
        int sel = m_sett_list->sel();
        if ( sel < 0) 
            return;
        setting set = self->m_setts[ sel ].sett;
        m_edited_sett.idx = m_sett_list->sel();
        m_edited_sett.key = self->m_setts[ sel ];

        if ( set.is_array) {
            show_setting_as_array();
            return;
        }

        fixed_setting_value fixed_val;
        if ( crange<enter_settings_dlg::setting_value_coll> r= rng::coll_find( self->m_values, m_edited_sett.key))
            fixed_val = r->second;

        typedef std::vector<std::string> array;
        array choices;
        switch ( set.type ) {
            case sett::dir:     /* falls through */
            case sett::double_: /* falls through */
            case sett::file:    /* falls through */
            case sett::int_:    /* falls through */
            case sett::string:  
                if ( !fixed_val.current.value().user_friendly.empty() )
                    choices.push_back(fixed_val.current.value().user_friendly);
                break;
            case sett::enum_:   for ( crange<const setting::enum_array> r(set.enums); r; ++r) choices.push_back(r->user_friendly); break;
            default: assert(false);
        }
        choices.push_back("[not set]");
        // add default
        int idx_default = -1;
        if ( !set.default_val.user_friendly.empty() ) {
            std::string def = set.default_val.user_friendly;
            bool default_amongst_choices = false;
            idx_default = 0;
            for ( crange<array> r(choices); r; ++r, ++idx_default)
                if ( *r == def) {
                    default_amongst_choices = true;
                    break;
                }
            if ( !default_amongst_choices) {
                choices.push_back( set.default_val.user_friendly);
                idx_default = (int)choices.size() - 1;
            }
        }
        choices.push_back( "[inherit from parent]");

        // find out what is to be currently selected
        std::string cur_sel = fixed_val.current.value().user_friendly;
        bool inheriting_from_parent = ( fixed_val.current == fixed_val.inherited);

        int idx_initial_choise = 0;
        for ( crange<array> r(choices); r; ++r, ++idx_initial_choise)
            if ( *r == cur_sel) break;
        if (inheriting_from_parent)
            idx_initial_choise = (int)choices.size() - 1; // inheriting from parent - last choice.
        // we should have found a current item to select!
        if ( idx_initial_choise >= (int)choices.size() )
            idx_initial_choise = -1; // could be an invalid choice?

        bool is_fixed_combo = set.type == sett::enum_;
        rectangle cur_set_rect = m_sett_list->sub_item_rect( m_sett_list->sel(), 1);
        cur_set_rect = cur_set_rect.convert(m_sett_list, window()); // relative to ourselves.
        // ... in case the "Browse" is visible, we'll let it show
        if ( m_browse->is_visible() ) 
            cur_set_rect.right = m_browse->window_rect(rel_to_parent).left;
        // adjust browsing
        if ( set.type == sett::dir) m_browse->browse( browse_button::browse_::dir);
        else if ( set.type == sett::file) m_browse->browse( browse_button::browse_::file);
        m_cur_setting->move(cur_set_rect);
        m_cur_setting->show();
        m_cur_setting->do_edit(
            choices, 
            idx_initial_choise, 
            idx_default,
            (is_fixed_combo ? setting_combo::drop_type::fixed : setting_combo::drop_type::open),
            (is_fixed_combo ? setting_combo::drop_now::open : setting_combo::drop_now::closed ) );
        bool is_number = set.type == sett::int_ || set.type == sett::double_;
        bool is_enum = set.type == sett::enum_;
        m_cur_setting->constraint( is_number ? setting_combo::constraint_::number : 
        (is_enum ? setting_combo::constraint_::enum_ : setting_combo::constraint_::string));
    }

    void show_setting_as_array() {
        int sel = m_sett_list->sel();
        setting set = self->m_setts[ sel ].sett;

        fixed_setting_value fixed_val;
        if ( crange<enter_settings_dlg::setting_value_coll> r= rng::coll_find( self->m_values, m_edited_sett.key))
            fixed_val = r->second;
        m_setting_array->do_edit( fixed_val.current.value().user_friendly, set.type);
        // adjust setting array dialog position
        rectangle cur_set_rect = m_sett_list->sub_item_rect( m_sett_list->sel(), 1);
        cur_set_rect = cur_set_rect.convert(m_sett_list, window()); // relative to ourselves.
        rectangle array_rect = cur_set_rect;
        array_rect.top = cur_set_rect.bottom;
        array_rect.bottom = array_rect.top + m_setting_array->client_rect().height();
        m_setting_array->move(array_rect);
        m_setting_array->show();
        // FIXME - see if enum!
    }

    void on_save_setting() {
        std::string selected_val = m_cur_setting->selected_value();
        name_pair new_val = name_from_user_entered_string(selected_val); // ... by default

        if ( selected_val == "[inherit from parent]") {
            // inherit from parent
            self->m_values[m_edited_sett.key].current = self->m_values[m_edited_sett.key].inherited;
            self->m_values[m_edited_sett.key].is_overridden = false;
        }
        else {
            // adjust value
            setting set = self->m_setts[m_edited_sett.idx].sett;
            if ( set.type == sett::enum_) {
                // enumeration - get the internal name (not the user-friendly one)
                for ( crange<setting::enum_array> r(set.enums); r; ++r)
                    if ( locase(r->user_friendly) == locase(selected_val)) {
                        new_val = *r;
                        break;
                    }
            }
            self->m_values[m_edited_sett.key].current.value( new_val);
            self->m_values[m_edited_sett.key].is_overridden = true;
        }

        persist_save();

        m_sett_list->item( m_edited_sett.idx, 1, lv_item()
            .text( setting_value_str(m_edited_sett.key) )
            .image( is_setting_inherited(m_edited_sett.key) ? node::val::inherited : node::val::overridden  ) );
    }

    void on_save_setting_array() {
        std::string selected_val = m_setting_array->selected_values();
        name_pair new_val = name_from_user_entered_string(selected_val); // ... by default
        if ( locase(selected_val) == locase(self->m_values[m_edited_sett.key].current.value().user_friendly) )
            return; // the same value - the user has not changed anything

        self->m_values[m_edited_sett.key].is_overridden = true;
        self->m_values[m_edited_sett.key].current.value( new_val);

        persist_save();

        m_sett_list->item( m_edited_sett.idx, 1, lv_item()
            .text( setting_value_str(m_edited_sett.key) )
            .image( is_setting_inherited(m_edited_sett.key) ? node::val::inherited : node::val::overridden  ) );
    }

    /** 
        persists this saving...
    */
    void persist_save() {
        typedef logical_path_setting_values_ptr ptr;
        ptr sv = user_comp().setting_values( self->m_path);
        for ( crange<const setting_for_compilers::compilers_set> r(m_edited_sett.key.compilers); r; ++r) {
            setting_key key;
            key.name = m_edited_sett.key.sett.name.normalized;
            key.config = self->m_config;
            key.setting_mode = setting_key::mode::before; // FIXME - allow "after" as well
            key.compiler = *r;
            sv->set_value(m_edited_sett.key.sett,key, self->m_values[m_edited_sett.key]);
        }

        if ( persist::setting<bool>("app.dbg.save_after_each_modify") )
            sv->save(); // simpler to debug
    }


    void on_after_browse(const std::string & path) {
        if ( locase(path) == locase(self->m_values[m_edited_sett.key].current.value().user_friendly) )
            return; // the same value

        if ( locase(path) == self->m_values[m_edited_sett.key].inherited.value() ) {
            self->m_values[m_edited_sett.key].current = self->m_values[m_edited_sett.key].inherited;
            self->m_values[m_edited_sett.key].is_overridden = false;
        }
        else {
            self->m_values[m_edited_sett.key].current.value( name_from_user_entered_string(path) );
            self->m_values[m_edited_sett.key].is_overridden = true;
        }

        persist_save();

        m_sett_list->item( m_edited_sett.idx, 1, lv_item()
            .text( setting_value_str(m_edited_sett.key) )
            .image( is_setting_inherited(m_edited_sett.key) ? node::val::inherited : node::val::overridden  ) );
        m_sett_list->set_focus();
    }

    void on_cancel_browse() {
        m_sett_list->set_focus();
    }

};


enter_settings_dlg::enter_settings_dlg() : m_path(""), m_config( configuration::root() ) {
    DWORD old = m_sett_list->extended_style();
    m_sett_list->extended_style(old | 
        list_ctrl_::extended_style::grid_lines | list_ctrl_::extended_style::sub_item_images);

    m_sett_list->add_col( lv_col().text("Name").width(250) );
    m_sett_list->add_col( lv_col().text("Value").width(250) );
    m_sett_list->add_col( lv_col().text("Applies to compiler(s)").width(150) );

//    mapping::remap_wnd<setting_combo>( child(m_cur_setting_::id) );
  //  mapping::remap_wnd<browse_button>( child(m_browse_::id) );
    // we need to be repainted/receive clicks, and we're on top of the settings list
    m_browse->bring_to_top();
}

enter_settings_dlg::~enter_settings_dlg() {
}

int enter_settings_dlg::dialog_id() { return dialog_id_; }

void enter_settings_dlg::show_settings(const setting_for_compiler_array & setts, show_type show) {
    m_values.clear();
    m_setts = setts;
    m_show = show;
    post_msg(enter_settings_dlg_handler::REFRESH_SETTINGS);
}


/** 
    Sets the logical path to show the settings for. When loading/saving settings, we'll always
    relate to this path.
*/
void enter_settings_dlg::path(const logical_path & p) {
    if ( m_path != p) {
        m_path = p;
        post_msg(enter_settings_dlg_handler::REFRESH_SETTINGS);
    }
}


void enter_settings_dlg::config(const configuration & config) {
    if ( config != m_config) {
        m_config = config;
        post_msg(enter_settings_dlg_handler::REFRESH_SETTINGS);
    }
}
