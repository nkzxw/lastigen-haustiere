

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\perform_build_dlg.h"

#include "win32gui_res/perform_build.hpp"
#include "main/app.h"
#include "setting/compiler.h"
#include "setting/computer.h"

#include "build/resolve_parameter.h"
#include "build/build.h"
#include "build/apply_rules.h"

#include "util/string_util.h"
#include "util/rw_string_io.h"
#include "util/command_util.h"
#include "util/file_util.h"
#include <time.h>
#include <direct.h>

#include <sys/types.h>
#include <sys/stat.h>

#include "ui/build_progress/built_applications_dlg.h"
#include "ui/build_statistics/build_statistics_list_dlg.h"
#include "build_statistics/write_build_statistics.h"
#include "build_statistics/read_build_statistics.h"

using namespace win32::gui;
using namespace boost::rangelib;

typedef build_statistics::path_info stats_path_info;
using build_statistics::read_for_dir;
using build_statistics::write_for_dir;

namespace {
    bool is_project_path(const logical_path & path, compiler_ptr comp, configuration config) {
        std::string val = get_setting_value("is project", path, comp, config);
        bool is = val != "0";
        if (!is) 
            return false;

        // note: if the project is excluded, don't build it at all...
        bool needs_compile = get_setting_value("exclude_from_build", path, comp, config) == "0";
        return needs_compile;
    }

    std::string project_name(const logical_path & path, compiler_ptr comp, configuration config) {
        return resolve_value( "$(project_name)", path, comp, config);
    }

    int file_size_no_throw(fs::path file) {
        if ( !fs::exists(file) ) return 0;

        try {
            return (int)fs::file_size(file);
        } catch(...) {
            return 0;
        }
    }
}


struct perform_build_dlg_handler : event_handler<perform_build_dlg_handler, perform_build_dlg> {
    void on_full_create() {
        self->m_build_wnd = self.to_wnd();
    }

    handle_event on_stop() {
        m_ok->enable(true);
        self->add_summary_msg("\n*** Stopped");
        self->add_detail_msg("\n*** Stopped");
        m_stop->enable(false);
        scoped_lock lk(self->m_cs);
        self->m_do_cancel = true;
        return event_ex<m_stop_::ev::clicked>().HANDLED_BY(&me::on_stop);
    }

    handle_event on_ok() {
        // FIXME there is a bug in win32gui here. Somehow, I reference some memory after being deleted
        // (I get a HEAP exception)
        self->destroy();
        return event_ex<m_ok_::ev::clicked>().HANDLED_BY(&me::on_ok);
    }


    handle_event on_cancel() {
        { scoped_lock lk(self->m_cs);
        self->m_do_cancel = true; }
        // FIXME there is a bug in win32gui here. Somehow, I reference some memory after being deleted
        // (I get a HEAP exception)
        self->destroy();
        return event_ex<m_cancel_::ev::clicked>().HANDLED_BY(&me::on_cancel);
    }
    
    handle_event on_destroy() {
        scoped_lock lk(self->m_cs);
        self->m_do_cancel = true;
        return event_ex<wm::destroy>().HANDLED_BY(&me::on_destroy);
    }
};


perform_build_dlg::perform_build_dlg() 
        : m_started(false), m_do_cancel(false), m_build_wnd(null_wnd), 
          m_successful_builds(0), m_failed_builds(0), m_do_clean_first(false), m_do_compile_only(false),
          m_max_recurse_levels(0), m_cur_recurse_level(0), m_do_pin(false) {
    add_resizable_ctrl(m_stop_::id, move_xy);
    add_resizable_ctrl(m_cancel_::id, move_xy);
    add_resizable_ctrl(m_ok_::id, move_xy);

    child<tab_dialog>(m_tabdialog1_::id)->add_item( tc_item().text("Commands"), m_commands );
    child<tab_dialog>(m_tabdialog1_::id)->add_item( tc_item().text("Warnings / Errors"), m_output );

    child<tab_dialog>(m_tabdialog2_::id)->add_item( tc_item().text("Summary"), m_summary );
    child<tab_dialog>(m_tabdialog2_::id)->add_item( tc_item().text("Build Times"), 
        create_dlg<build_statistics_list_dlg>(this) );

    // ... just in case...
    m_summary->max_chars(256 * 1024);
    m_commands->max_chars(256 * 1024);
    m_output->max_chars(256 * 1024);
}

perform_build_dlg::~perform_build_dlg() {
}

int perform_build_dlg::dialog_id() { return dialog_id_; }



void perform_build_dlg::add_build_path(const logical_path &path, configuration config, std::string compiler) {
    assert ( !m_started);
    m_builds.push_back( build_info(path,config,compiler) );

}
namespace {

    void add_text(wnd<edit> e, const std::string & msg) {
        int size = (int)e->text().size();
        if ( size > 64 * 1024) {
            // truncate
            std::string txt = e->text().substr( 64 * 1024 / 2);
            e->text(txt);
            size = (int)txt.size();
        }
        e->sel(size, size);
        e->replace_sel(msg);
        e->scroll_caret();
    }
}


void perform_build_dlg::add_summary_msg(std::string msg) {
    if ( is_cancelled() ) return;

    str_replace( msg, "\n", "\r\n");
    str_replace( msg, "\r\r\n", "\r\n");
    add_text( m_summary, msg);
}

void perform_build_dlg::add_detail_msg(std::string msg) {
    if ( is_cancelled() ) return;

    str_replace( msg, "\n", "\r\n");
    str_replace( msg, "\r\r\n", "\r\n");
    add_text( m_commands, msg);
}

void perform_build_dlg::add_output_results_msg(fs::path file, fs::path output_results) {
    if ( is_cancelled() ) return;

    std::string results;
    { std::ifstream in(output_results.string().c_str());
      std::ostringstream out; out << in.rdbuf();
      results = out.str(); }
    str_replace( results, "\n", "\r\n");
    str_replace( results, "\r\r\n", "\r\n");
    if ( results.size() <= 1) 
        return; // size = 0 or 1 -> empty file

    std::string txt ;
    txt += "\r\n\r\n [FILE] " + file.string() + "\r\n";
    txt += results;
    add_text( m_output, txt);
}


void perform_build_dlg::add_success(const logical_path & project_path, fs::path out_path, compiler_ptr comp, configuration config) {
    if ( is_cancelled() ) return;

    sub_wnd<built_applications_dlg>()->add_success(project_path, out_path, comp, config);
    scoped_lock lk(m_cs);
    ++m_successful_builds;
}

void perform_build_dlg::add_failure(const logical_path & project_path, compiler_ptr comp, configuration config) {
    if ( is_cancelled() ) return;

    sub_wnd<built_applications_dlg>()->add_failure(project_path, comp, config);
    scoped_lock lk(m_cs);
    ++m_failed_builds;
}





/** 
    performs the build, on a dedicated thread
*/
void perform_build_dlg::run() {
    while ( true) {
        if ( is_cancelled() ) break;

        build_info build;
        {
        scoped_lock lk(m_cs);
        if (m_builds.empty())
            break; // we've built everything...
        build = m_builds[0];
        m_builds.erase( m_builds.begin());
        }

        try {
            compiler_ptr comp = user_comp().get_compiler( build.compiler);
            assert( !comp->is_intermediate() ); // can't be performed on intermediate compilers

            m_build_wnd->start_recursing(build);
            int old_build_count = m_build_wnd->m_successful_builds + m_build_wnd->m_failed_builds;
            m_build_wnd->recurse_build( build, comp);

            bool found_subproject = old_build_count != (m_build_wnd->m_successful_builds + m_build_wnd->m_failed_builds);
            if ( !found_subproject)
                // special case - when no projects found - build the directory
                m_build_wnd->build_project( build, comp);
        } catch(std::exception & exc) {
            BOOST_LOG(err) << "building " << build.config.friendly_name() << "/" << build.compiler << " for "
                << build.path.physical_path().string() 
                << ":" << exc.what();
            m_build_wnd->add_detail_msg( "Exception: " + std::string(exc.what()));
            ++m_build_wnd->m_failed_builds;
        }
    }
    if ( !is_cancelled() ) {
        m_build_wnd->add_summary_msg("\n*** Finished");
        m_build_wnd->add_detail_msg("\n*** Finished");
        m_build_wnd->m_ok->enable(true); // allow pressing ok
        m_build_wnd->m_stop->enable(false);
        m_build_wnd->m_cancel->enable(false);
    }
    // release the reference to ourselves - allow our object to be destroyed
    m_build_wnd = null_wnd;
}


// FIXME when "compile-only", and the directory is part of a bigger project, I should
// do the building into that project !!! (that is, when calculating the build-root, it should be
// relative to the project root, not to the directory built)


void perform_build_dlg::start_recursing(const build_info & build) {
    std::string build_set_prefix = build_statistics::new_prefix(build.path, build.config, build.compiler);
    m_statistics.new_ = statistics_ptr(new statistics_type(build.path, build_set_prefix));

    // ... in case there are already built files...
    std::string old_prefix = build_statistics::latest_prefix(build.path, build.config, build.compiler);
    if ( !old_prefix.empty() )
        m_statistics.old = shared_ptr<read_for_dir>(new read_for_dir(build.path, old_prefix));
    else
        m_statistics.old = shared_ptr<read_for_dir>(); // no previous build...


    // see if we can compare the current build with a (pinned) previous one...
    std::string pinned_prefix = build_statistics::pinned_prefix(build.path, build.config, build.compiler);
    if ( !pinned_prefix.empty() )
        m_statistics.pinned = shared_ptr<read_for_dir>(new read_for_dir(build.path, pinned_prefix));
    else
        m_statistics.pinned = shared_ptr<read_for_dir>(); // no previous build...


    if ( m_do_pin) {
        // pin this build - for statistics...
        build_statistics::unpin_previous_builds(build.path, build.config, build.compiler);
        persist::setting<bool>(build_set_prefix + ".is_pinned") = true;
    }

    m_cur_recurse_level = 0;
    m_max_recurse_levels = 0;
    std::istringstream in(get_setting_value("recurse_levels", build.path, user_comp().get_compiler( build.compiler), build.config));
    in >> m_max_recurse_levels ;
    if ( m_max_recurse_levels <= 0) m_max_recurse_levels = INT_MAX; // 0 - recurse all
}

namespace {
    struct increase_decrease {
        increase_decrease(int & i) : m_i(i) { ++m_i; }
        ~increase_decrease() { --m_i; }
        int & m_i;
    };
}

/** 
    Performs a recursive build of the given logical path. That is, it recursively searches all subdirectories
    of the physical path, and where a project is found, it builds it
*/
void perform_build_dlg::recurse_build(const build_info & build, compiler_ptr comp) {
    if ( is_cancelled() ) return;
    increase_decrease inc(m_cur_recurse_level);
    bool recurse_level_too_big = (m_cur_recurse_level > m_max_recurse_levels);
    if ( recurse_level_too_big) return;

    fs::path cur_path = build.path.physical_path().string();
    BOOST_LOG(app) << "recursing " << cur_path.string();

    if ( cur_path.leaf() == "cb-build") 
        return; // it's a build directory...

    if ( is_project_path(build.path, comp, build.config) ) 
        build_project(build, comp);
    else 
        add_non_project_path_for_statistics(build.path);

    /*
        FIXME in the future, search for build dirs first. That is, recurse all dirs, find projects,
        and then do the rest
    */
    for ( fs::directory_iterator begin(cur_path), end; begin != end; ++begin)
        if ( fs::is_directory(*begin) ) {
            build_info sub = build;
            sub.path = sub.path.sub_path( *begin);
            recurse_build(sub, comp);
        }
}


/** 
    considers this path a project, and builds it.
*/
void perform_build_dlg::build_project(const build_info & build, compiler_ptr comp) {
    if ( is_cancelled() ) return;

    BOOST_LOG(app) << "building " << project_name(build.path, comp, build.config);
    add_detail_msg(build.path.physical_path().string());
    std::string friendly_msg = project_name(build.path,comp,build.config) + " for " + comp->friendly_name() + " (" + build.config.friendly_name() + ")";
    add_detail_msg("\n**** Building " + friendly_msg + "\n");
    add_summary_msg("\n**** Building " + friendly_msg + "\n");
    // ... set title
    text( friendly_msg);

    fs::path project_root = build.path.physical_path();
    fs::path build_root = project_build_path(build.path, build.config, build.compiler);
    fs::create_directories(build_root);
    // mark this as the Build root (so that Explorer View won't allow exploring it)
    { fs::path mark_as_build_root = project_root / "cb-build";
      std::ofstream signature( (mark_as_build_root / "crossbuilder-build-dir.txt").string().c_str());
      signature << "used by Cross Builder"; }

    // compile
    compiled_file_array files;
    recurse_compile(build, comp, project_root, build_root, files);
    if ( is_cancelled() ) return;

    // build
    bool all_compiled = true;
    for ( crange<compiled_file_array> r(files); r; ++r) if (r->compiled.empty()) all_compiled = false;
    if ( all_compiled)
        link(files, build.path, comp, build.config, build_root);
    else {
        add_summary_msg("Cannot build this project...\n");
        add_detail_msg("Cannot build this project. Some files have failed to compile.\n");
        add_failure(build.path, comp, build.config);
    }
}


void perform_build_dlg::recurse_compile(const build_info & build, compiler_ptr comp, fs::path project_root, fs::path build_root, compiled_file_array & files) {
    if ( is_cancelled() ) return;

    if ( build.path.physical_path().leaf() == "cb-build") 
        return; // it's a build directory - no need to recurse it ...

    if ( build.path == project_root)
        add_project_path_for_statistics(build.path);
    else
        add_non_project_path_for_statistics(build.path);

    fs::path cur_path = build.path.physical_path();
    for ( fs::directory_iterator begin(cur_path), end; begin != end; ++begin) {
        build_info sub = build;
        sub.path = sub.path.sub_path( *begin);

        if ( fs::is_directory(*begin)) 
            recurse_compile( sub, comp, project_root, build_root, files);
        else if ( is_compilable(sub.path)) {
            // note: you might think that I could ask if "exclude from build" applies to a directory,
            // and if so, simply don't recurse it
            //
            // this could be wrong, since at any time, a file and/or subdirectory might override
            // that option
            bool needs_compile = get_setting_value("exclude_from_build", sub.path, comp, build.config) == "0";
            if ( needs_compile)
                files.push_back( compile_file(sub, comp, project_root, build_root) );
        }
    }
}

namespace {
    /** 
        returns the output file name - into which file the compilation should happen
    */
    std::string output_file_name(const fs::path file, fs::path build_root) {
        std::string file_no_ext = file.leaf();
        std::string ext = fs::extension(file);
        file_no_ext = file_no_ext.substr(0, file_no_ext.size() - ext.size());

        // we don't allow two different files that have the same leaf name, to overlap
        // the output file name (the .obj file , that is)
        //
        // Example: c:\test.cpp and c:\temp\test.cpp - each will output to a different file
        int idx = 0;
        fs::create_directory(build_root / "internal");
        while ( true) {
            std::string name_file = file_no_ext;
            if ( idx > 0) name_file += str_stream() << idx;
            name_file += ".name";
            // in case we find .name file, see the file it corresponds to
            std::string corresponding_file;
            { std::ifstream in((build_root / "internal" / name_file).string().c_str());
              std::getline(in, corresponding_file); }
            
            bool is_name_ok = corresponding_file.empty() || (corresponding_file == file.string());
            if ( is_name_ok) break;
            ++idx;
        }

        std::string result = file_no_ext;
        if ( idx > 0) result += str_stream() << idx;
        
        // ... create its .name file...
        std::ofstream out((build_root / "internal" / (result + ".name")).string().c_str());
        out << file.string();
        return result;
    }

    /** 
        returns the last time it's been written to

        Note: not using fs::last_write_time, since it's not a very safe function.
        Better use all the help from the underlying OS
    */
    time_t last_file_write_time(fs::path p) {
        if ( p.empty() || !fs::exists(p))
            return 0; // no file...
        struct _stat info = { 0 };
        _stat( p.string().c_str() , &info );
        return info.st_mtime;
    }


    // FIXME for como, make sure to set COMO_MS_INCLUDE and other stuff.




    /** 
        writes the commands that should be executed before compiling a file
    */
    void write_pre_compile_file(const logical_path & file_path, compiler_ptr comp, configuration config, fs::path project_root) {
        std::string raw_pre_compile = get_setting_value("pre_compile_commands", file_path, comp, config);

        std::string pre_compile_cmds;
        std::istringstream in(raw_pre_compile); 
        std::string raw_cmd, resolved_cmd;
        while ( in >> io::read_str(raw_cmd) ) {
            resolved_cmd = resolve_value(raw_cmd, file_path, comp, config);
            pre_compile_cmds += resolved_cmd + "\n";
            char ch = 0;
            in >> ch;
            if (in)
                assert(ch == ','); // the commands are separated by comma...
        }

        // FIXME this will not work when multiple compilations can happen in parallel!
        std::ofstream out( (project_root / "crossbuilder_pre_compile.bat").string().c_str());
        out << pre_compile_cmds;
    }

    // where we write the compilation results (warnings/errors/ etc.)
    std::string output_results_file_name(std::string out_file_name) {
        // ... note: when using "copy" function, Win32 needs a '\' , instead of '/' (Win2000)
        return "internal\\" + out_file_name + ".out";
    }

    run_sys_command_results run_command(std::string cmd_line, fs::path home_dir) {
        try {
            return run_sys_command_as_hidden(cmd_line, home_dir);
        } catch(std::exception & exc) {
            BOOST_LOG(err) << exc.what();
        }
        return run_sys_command_results();
    }

    // FIXME when implementing parallel buiding, each compiler should have its own crossbuilder_pre_compile file !!!
    run_sys_command_results run_compile(const std::string & cmd_line, fs::path project_root, fs::path build_root, std::string out_file_name) {
        BOOST_LOG(dbg) << "running compile command:\n" << cmd_line;

        // Note: we need to run in the project' root
        // This is because multiple compiler settings relate to this root. For example, the #include directives
        // are relative to the projet root
        std::string full_cmd_line = "\"" + project_root.string() + "/crossbuilder_pre_compile.bat\" && " + cmd_line 
            + " > " + out_file_name + ".crossbuilder_.warn" 
            + " 2> " +out_file_name + ".crossbuilder_.err";
        run_sys_command_results stats = run_command( full_cmd_line, project_root);

        // note: win32 needs me to prepend "cmd /C " to system commands

        // copy results (stdout and stderr) to output file
        std::string to_out_file = "cmd /C copy " 
            + out_file_name + ".crossbuilder_.warn + " 
            + out_file_name + ".crossbuilder_.err \"" 
            + (build_root / output_results_file_name(out_file_name)).string() + "\"";
        run_command( to_out_file, project_root);
        std::string del_cmd = "cmd /C del " + out_file_name + ".crossbuilder_.warn && del " + out_file_name + ".crossbuilder_.err";
        run_command( del_cmd, project_root);
        return stats;
    }

    run_sys_command_results run_link(const std::string & cmd_line, fs::path build_root) {
        BOOST_LOG(dbg) << "running link command:\n" << cmd_line;

        std::string full_cmd_line = "\"" + build_root.string() + "/crossbuilder_pre_compile.bat\" && " + cmd_line 
            + " > link_results.crossbuilder_.warn" 
            + " 2> link_results.crossbuilder_.err";
        run_sys_command_results stats = run_command( full_cmd_line, build_root);

        // note: win32 needs me to prepend "cmd /C " to system commands

        // copy results (stdout and stderr) to output file
        std::string to_out_file = "cmd /C copy link_results.crossbuilder_.warn + link_results.crossbuilder_.err \"" 
            + (build_root / output_results_file_name("link_results")).string() + "\"";
        run_command( to_out_file, build_root);
        std::string del_cmd = "cmd /C del link_results.crossbuilder_.warn && del link_results.crossbuilder_.err";
        run_command( del_cmd, build_root);
        return stats;
    }


}


/** 
    called before showing statistics for a file
    
    We will first remove the directories that don't contain any files, in order to remove clutter.
*/
void perform_build_dlg::filter_out_empty_statistics_dirs(const logical_path & file) {
    if (m_statistics.paths_to_file.empty()) return; // no paths...

    statistics_info::paths_array non_empty_paths;
    logical_path prev = file;
    irange<statistics_info::paths_array::reverse_iterator> r(m_statistics.paths_to_file.rbegin(), m_statistics.paths_to_file.rend());
    for ( ; r; ++r)
        if ( prev.parent() == *r) {
            non_empty_paths.push_back(*r);
            prev = *r;
        }
        else
            break; // no more paths leading to the current file...

    rng::reverse(non_empty_paths);
    m_statistics.paths_to_file = non_empty_paths;
}


void perform_build_dlg::add_file_statistics(const logical_path & file, const build_statistics::path_info & stats) {
    m_statistics.new_->add_file(file, stats);

    build_statistics::path_info pinned_stats;
    bool has_pinned_stats = false;
    if ( m_statistics.pinned)
        if ( m_statistics.pinned->has_path_stats(file)) {
            pinned_stats = m_statistics.pinned->path_stats(file).stats;
            has_pinned_stats = true;
        }

    // first, add the paths that lead to this file
    filter_out_empty_statistics_dirs(file);
    for ( crange<const statistics_info::paths_array> r(m_statistics.paths_to_file); r; ++r)
        sub_wnd<build_statistics_list_dlg>()->add_single_statistics(r->physical_path(), build_statistics::path_info());
    m_statistics.paths_to_file.clear();

    if ( m_statistics.pinned) {
        sub_wnd<build_statistics_list_dlg>()->add_compare_statistics(file.physical_path(), stats, pinned_stats,
            true, has_pinned_stats);
    }
    else
        sub_wnd<build_statistics_list_dlg>()->add_single_statistics(file.physical_path(), stats);
}

void perform_build_dlg::add_project_path_for_statistics(const logical_path & path) {
    m_statistics.new_->add_project_path(path);
    m_statistics.paths_to_file.push_back(path);
}
void perform_build_dlg::add_non_project_path_for_statistics(const logical_path & path) {
    m_statistics.new_->add_non_project_path(path);
    m_statistics.paths_to_file.push_back(path);
}



namespace {
    // resolves parameters that depend on scope of the current build 
    void resolve_scope_parameters(std::string & cmd_line, fs::path project_root, fs::path build_root) {
        str_replace(cmd_line, "$(build_path)", build_root.string());
        str_replace(cmd_line, "$(project_path)", project_root.string());
    }
}


// FIXME dependencies. If a dependency is a directory, I will walk it and build it.
// Then, all projects that were buit are added to the dependency list
//
// como does not handle spaces correctly. I need to copy the dependency files manually!!!
// Have a setting "Copy dependency libraries locally"

void perform_build_dlg::link(const compiled_file_array & files, const logical_path & project_path, compiler_ptr comp, configuration config, fs::path build_root) {
    if ( is_cancelled() ) return;

    { scoped_lock lk(m_cs);
      if ( m_do_compile_only) {
          add_summary_msg("\n");
          // FIXME add_success( project_path, out_file_path, comp, config);
          ++m_successful_builds;
          return;
      }
    }

    // ... write it in the build directory
    write_pre_compile_file(build_root, comp, config, build_root);

    std::string out_name = get_setting_value("out_name", project_path, comp, config);
    out_name += link_ext(project_path, comp, config);
    bool allows_spaces_in_name = get_setting_value("allows_spaces_in_name", project_path, comp, config) != "0";
    if ( !allows_spaces_in_name)
        str_replace(out_name, " ", "_"); // especially useful for como.

//    std::string linker_app_name = linker_name(project_path, comp, config);
    std::string cmd_line_args = apply_link_rules(project_path, comp, config);
    std::string cmd_line = linker_command(project_path, comp, config);
    std::string cmd_line_files;
    for ( crange<const compiled_file_array> r(files); r; ++r) cmd_line_files += " \"" + r->compiled.leaf() + "\"";
    //str_replace(cmd_line, "$(linkername)", linker_app_name);
    str_replace(cmd_line, "$(args)", cmd_line_args);
    str_replace(cmd_line, "$(allfiles)", cmd_line_files);
    str_replace(cmd_line, "$(outfilename)", out_name);
    resolve_scope_parameters(cmd_line, project_path.physical_path(), build_root);

    fs::path out_file_path = build_root / out_name;
    if ( m_do_clean_first)
        fs::remove(out_file_path); // rebuilding...
    bool needs_build = !fs::exists(out_file_path);
    if ( !needs_build)
        for ( crange<const compiled_file_array> r(files); r; ++r)
            if ( last_file_write_time(r->compiled) > last_file_write_time(out_file_path) )
                needs_build = true; // one of the object files' time is later than the executable's...

    add_summary_msg("Linking...");
    run_sys_command_results link_stats;
    if ( needs_build) {
        add_detail_msg("\n" + cmd_line + "\n");
        link_stats = run_link(cmd_line, build_root);
        add_output_results_msg( out_file_path, build_root / output_results_file_name("link_results"));
    }
    else
        add_summary_msg(" already up to date");

    // see if we were successful
    bool successful = fs::exists(out_file_path);
    if ( successful)
        for ( crange<const compiled_file_array> r(files); r; ++r)
            if ( last_file_write_time(r->compiled) > last_file_write_time(out_file_path) )
                successful = false;


    logical_path link_name = project_path.sub_path( project_path.physical_path() / "Link Time"); 
    stats_path_info out_file_stats( link_stats);
    if ( needs_build) 
        out_file_stats.build_res = successful ? stats_path_info::result::success : stats_path_info::result::failure;
    else {
        // already built - try to get it from last known statistics...
        if ( m_statistics.old && m_statistics.old->has_path_stats(link_name) )
            out_file_stats = m_statistics.old->path_stats(link_name).stats;
        out_file_stats.is_already_built = true;
    }
    out_file_stats.size = file_size_no_throw(out_file_path);
    add_file_statistics(link_name, out_file_stats); 

    if ( successful) {
        add_summary_msg("\n");
        add_success( project_path, out_file_path, comp, config);
    }
    else {
        add_summary_msg("    - FAILED\n");
        add_failure( project_path, comp, config);
    }
}


perform_build_dlg::compiled_source_file perform_build_dlg::compile_file(const build_info & build, compiler_ptr comp, fs::path project_root, fs::path build_root) {    
    compiled_source_file file;
    file.source = build.path.physical_path();
    if ( is_cancelled() ) return file;
    add_summary_msg( file.source.string());

    metadata_ptr meta = comp->metadata();
    std::string cmd_line_args= apply_compile_rules(build.path, comp, build.config);
    std::string cmd_line = command_line_template(build.path, comp, build.config);

    // compute where the file is to be outputted
    std::string out_file_name = output_file_name(file.source, build_root);
    std::string out_ext = output_file_ext(build.path, comp, build.config);
    write_pre_compile_file(build.path, comp, build.config, project_root);

    // make the in and out file names as short as possible;
    // This is useful especially for como, which cannot handle spaces in file names
    fs::path in_file = file.source;
    fs::path out_file = build_root / out_file_name;
    in_file = relative_to(in_file, project_root);
    out_file = relative_to(out_file, project_root);

    str_replace( cmd_line, "$(infile)", in_file.string() );
    str_replace( cmd_line, "$(args)", cmd_line_args);
    str_replace( cmd_line, "$(outfile)", out_file.string() );
    str_replace( cmd_line, "$(outext)", out_ext);
    resolve_scope_parameters(cmd_line, project_root, build_root);

    // check if the compiler is set...
    { std::istringstream in(cmd_line); 
      std::string compiler_name; in >> io::read_str(compiler_name);
      if ( compiler_name == file.source.string() ) {
        add_summary_msg("    - FAILED\n");
        add_detail_msg("Cannot compile... - compiler not set. Configure this compiler first!\n");
        return file;
      } }

    fs::path out_file_path = build_root / (out_file_name + out_ext);
    if ( m_do_clean_first)
        fs::remove(out_file_path); // rebuilding...

    // FIXME if it seems it does not need building, check if the command line has changed. If so, we'll rebuild
    //       same for linking!

    bool needs_build = !fs::exists(out_file_path) || (last_file_write_time(file.source) >= last_file_write_time(out_file_path));
    run_sys_command_results compile_stats ;
    if ( needs_build) {
        add_detail_msg( "\n" + cmd_line + "\n");
        compile_stats = run_compile(cmd_line, project_root, build_root, out_file_name);
        add_output_results_msg(file.source, build_root / output_results_file_name(out_file_name));
    }
    else {
        add_detail_msg( file.source.string() + " ... already built\n");
    }
    stats_path_info file_stats(compile_stats);
    bool successful = fs::exists(out_file_path) && (last_file_write_time(file.source) <= last_file_write_time(out_file_path));
    if ( needs_build) 
        file_stats.build_res = successful ? stats_path_info::result::success : stats_path_info::result::failure;
    else  {
        // already built - try to get it from last known statistics...
        if ( m_statistics.old && m_statistics.old->has_path_stats(build.path) )
            file_stats = m_statistics.old->path_stats(build.path).stats;
        file_stats.is_already_built = true;
    }
    file_stats.size = file_size_no_throw(out_file_path);
    add_file_statistics(file.source, file_stats);

    if ( successful)    add_summary_msg("\n");
    else                add_summary_msg("    - FAILED\n");

    if ( successful)
        file.compiled = out_file_path;
    return file;
}



bool perform_build_dlg::is_cancelled() const {
    if ( !is_valid() ) return true;
    scoped_lock lk(m_cs);
    if ( m_do_cancel ) return true;

    return false;
}


void perform_build_dlg::start() {
    if ( m_started) {
        assert(false);
        return;
    }

    // start the runner thread...
    using namespace boost;
    thread::thread( bind(&perform_build_dlg::run, this));
}

void perform_build_dlg::clean_first(bool val) {
    m_do_clean_first = val;
}



int perform_build_dlg::sucess_builds_count() const {
    scoped_lock lk(m_cs);
    return m_successful_builds;
}



int perform_build_dlg::failed_builds_count() const {
    scoped_lock lk(m_cs);
    return m_failed_builds;
}
    

void perform_build_dlg::compile_only(bool val) {
    m_do_compile_only = val;
}


void perform_build_dlg::do_pin(bool val) {
    m_do_pin = val;
}


