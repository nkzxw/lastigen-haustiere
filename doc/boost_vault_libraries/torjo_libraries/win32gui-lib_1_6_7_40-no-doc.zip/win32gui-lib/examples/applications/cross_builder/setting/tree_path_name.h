

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

struct tree_path_name;
bool operator==(const tree_path_name & f, const tree_path_name & s);


/** 
    Represents a path - one that can lead to a node in a tree, where
    each tree node is identified by a name
*/
struct tree_path_name
{
    tree_path_name( const std::string & path = std::string() );
    ~tree_path_name(void);

    void append(const std::string & path);
    void prepend(const std::string & path);

    tree_path_name root_child() const;
    tree_path_name parent() const;

    const std::string & string() const;

    std::string at(int idx) const;
    void at(int idx, const std::string & new_name);

    // const access to each of the nodes...
    typedef std::vector<std::string> node_array;
    boost::rangelib::crange<const node_array> nodes() const { return m_nodes; }
    int nodes_count() const { return (int)m_nodes.size(); }

    std::string last_node() const;

    bool is_ascendant_of(const tree_path_name & other) const;

private:
    void recompute_path();
private:
    friend bool operator==(const tree_path_name & f, const tree_path_name & s);

    node_array m_nodes;
    std::string m_path;
};

tree_path_name path_from_tree_item(win32::gui::wnd<win32::gui::tree_ctrl> t, HTREEITEM item);

bool operator==(const tree_path_name & f, const tree_path_name & s);
inline bool operator!=(const tree_path_name & f, const tree_path_name & s) { return !(f == s); }

