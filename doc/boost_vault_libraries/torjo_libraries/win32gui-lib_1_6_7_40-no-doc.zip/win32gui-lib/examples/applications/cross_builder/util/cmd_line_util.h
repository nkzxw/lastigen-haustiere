#pragma once

// Utility Library
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

#include <vector>

// represents the command line arguments
struct cmd_line {
    cmd_line();
    ~cmd_line();
    const std::vector<std::string> & args() const { return m_args; }
private:
    // the command line args
    std::vector<std::string> m_args;
};

