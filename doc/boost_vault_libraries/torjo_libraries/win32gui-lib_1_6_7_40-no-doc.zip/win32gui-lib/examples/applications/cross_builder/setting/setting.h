

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "setting/name.h"

struct setting;
typedef std::vector<setting> setting_array;


/** types of settings */
namespace sett {
    typedef enum type {
        // boolean (yes/no)
        // bool_, - note: bool is just another type of enumeration(Yes,No)

        // string
        string,
        // integer
        int_,
        // double
        double_,
        // enumeration
        // (note: if it's also an array, this means that the user can choose zero-to-N
        //        values from the given enumeration)
        enum_,
        // file name
        file,
        // directory
        dir

        // FIXME future - maybe allow "path" - can be file or directory?
    };
}



/** 
    @brief Represents one (compiler) setting

    Note that this setting just contains information about:
    - the setting name
    - setting description (user-frienly name)
    - setting type (+ is array or not)

    It does not contain any info about what the user
    selects as value(s) for a setting.

    @attention
    The normalized name always uniquely identifies a setting.

*/
struct setting
{
    setting() : type(sett::string), is_array(false), is_inheritable(true), is_hidden(false), is_global(false) {}

    bool is_same(const setting & other) const;

    // the name of the setting
    name_pair name;
    
    std::string description;

    // the type of setting
    sett::type type;
    // ... in case it's an enumeration...
    typedef std::vector<name_pair> enum_array;
    enum_array enums;

    // if true, the setting is an array
    bool is_array;

    // default value 
    name_pair default_val;

    // if true (default), this setting can be inherited
    bool is_inheritable;

    // if a setting is hidden, it should not be shown visually.
    // That is, either it's constant (should not be modified), or
    // the program has another way of allowing this setting to be modified
    // (for instance, the "Is Project" setting)
    bool is_hidden;

    // if true, they are set only for the local disk, and apply to every other directory/file, regardless
    // of where they're Root or not.
    bool is_global;
};



