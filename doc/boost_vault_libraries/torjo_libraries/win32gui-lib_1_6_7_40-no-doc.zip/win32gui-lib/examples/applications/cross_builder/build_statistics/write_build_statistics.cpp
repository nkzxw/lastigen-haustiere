

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\write_build_statistics.h"
#include <time.h>


namespace build_statistics {

using namespace boost::rangelib;


write_for_dir::write_for_dir(const logical_path & root, const std::string & build_prefix)
        : m_root(root), m_build_prefix(build_prefix), m_next_path_idx(0), m_built_files_count(0) {

    // we must mark the number of built files. Whenever doing a new built, and we find a slot
    // where built_files_count is zero, we can reuse it
    persist::setting<int>(str_stream() << m_build_prefix << ".built_files_count") = m_built_files_count;
        
}

write_for_dir::~write_for_dir(void){
    persist::configuration::def().save(); // don't save after each file - on debug mode,might be too costly
}

void write_for_dir::add_project_path(const logical_path & path) {
    bool is_project = true;
    add_path_impl(path, is_project);
}
void write_for_dir::add_non_project_path(const logical_path & path) {
    bool is_project = false;
    add_path_impl(path, is_project);
}

void write_for_dir::add_path_impl(const logical_path & path, bool is_project) {
    prepare_for_path(path);
    m_built_paths.push_back( path_statistics(path, m_next_path_idx++, is_project) );
    // note: no need to do any persisting now, since nothing new (concerning built statistics)
    // has been added
    persist::configuration::def().save(); // don't save after each file - on debug mode,might be too costly
}

void write_for_dir::prepare_for_path(const logical_path & path) {
    // see where this path fits into, in the hierarchy...
    while ( !m_built_paths.empty() )
        if ( m_built_paths.back().path == path.parent())
            break;
        else {
            bool idx_was_unused = ( m_built_paths.back().idx + 1 == m_next_path_idx) &&
                    ( m_built_paths.back().stats.spent_time_ms == 0);
            if ( idx_was_unused)
                --m_next_path_idx; // this index can be reused...
            m_built_paths.erase( m_built_paths.end() - 1);
        }
}


void write_for_dir::add_file(const logical_path & file, path_info stats) {
    // FIXME for an already built file, try to find out the last build time TOTHINK
    prepare_for_path(file);

    const bool is_project = false;
    path_statistics file_stats(file, m_next_path_idx++, is_project, stats);
    for ( crange<path_array> r(m_built_paths); r; ++r)
        r->stats.add( stats);

    // in case of failure, propagate it up to the first project path...
    if ( stats.build_res == path_info::result::failure)
        for ( irange<path_array::reverse_iterator> r(m_built_paths.rbegin(),m_built_paths.rend()); r; ++r) {
            r->stats.build_res = path_info::result::failure;
            if ( r->is_project)
                break;
        }

    do_persist_path(file_stats);
    do_persist();
    persist::setting<int>(str_stream() << m_build_prefix << ".built_files_count") = ++m_built_files_count;
    // when I'll read them back, need to know how much to read...
    persist::setting<int>(str_stream() << m_build_prefix << ".paths_count") = m_next_path_idx;
}

// persists existing settings
void write_for_dir::do_persist() {
    using namespace boost;
    rng::for_each( m_built_paths, bind(mem_fn(&write_for_dir::do_persist_path), this,_1) );
}


void write_for_dir::do_persist_path(const path_statistics & stats) {
    using persist::setting;
    std::string prefix = str_stream() << m_build_prefix << "." << stats.idx ;
    setting<std::string>(prefix + ".path" ) = stats.path.physical_path().string();
    setting<int>(prefix + ".result") = stats.stats.build_res;
    setting<int>(prefix + ".size") = stats.stats.size;
    setting<int>(prefix + ".processor_time_ms") = stats.stats.processor_time_ms;
    setting<int>(prefix + ".spent_time_ms") = stats.stats.spent_time_ms;
    setting<bool>(prefix + ".is_already_built") = stats.stats.is_already_built;
}



}


