

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "stdafx.h"
// settings_dlg.cpp
#include "settings_dlg.h"
#include <win32gui/event_handler.hpp>

#include "settings_dlg.h"

#include "tree/tree.h"
#include "tree/algorithm.h"
#include "setting/computer.h"
#include "main/app.h"
#include "tree/io.h"
#include <deque>

#include "ui/enter_settings_dlg.h"
#include "setting/configuration.h"

#include "win32gui_res/settings.hpp"
#include "win32gui_res/bitmaps.hpp"
using namespace win32::gui::res_id;

using namespace win32::gui;
using namespace boost::rangelib;

namespace {
    // images for compiler nodes
    namespace node {
        enum type {
            main_dir = 6,
            sub_dir = 7
        };
    }


    /** 
        information about a compiler directory
    */
    struct compiler_dir {
        compiler_dir() : icon_idx(-1) {}
        compiler_dir(const tree::no_info&) : icon_idx(-1) {}
        int icon_idx;
    };

    /**
    expands to the given path, and selects the lower-most child

    Each node is separated by '/'
    */
    void expand_and_select(wnd<tree_ctrl> t, std::string path) {
        std::string original_path = path;
        HTREEITEM parent = 0;
        while ( !path.empty() ) {
            std::string::size_type delim = path.find('/');
            std::string name = (delim != std::string::npos) ? path.substr(0,delim) : path;

            HTREEITEM next ;
            for ( next = t->first_child(parent); next; next = t->next_sibling(next) ) 
                if ( t->item(next).text() == name) break;
            
            if ( next) {
                parent = next;
                path = (delim != std::string::npos) ? path.substr(delim+1) : std::string();
            }
            else
                break; // path not found...
        }

        // select lower-most child
        if ( parent) t->sel(parent);

        if ( !path.empty() )
            BOOST_LOG(err) << "path not found " << path << t->raw_hwnd();
    }
}

struct settings_dlg_handler : event_handler<settings_dlg_handler, settings_dlg> {
    enum {
        REFRESH_COMPILERS = WM_APP + 20,
        REFRESH_COMPILER_PATH
    };

    //one-to-one correspondence from compiler to an index in the combo-box
    typedef std::map<std::string,int> compiler_to_idx_coll;
    typedef std::map<int,std::string> idx_to_compiler_coll;
    compiler_to_idx_coll m_compiler_to_idx;
    idx_to_compiler_coll m_idx_to_compiler;

    typedef std::vector<configuration> config_array;
    config_array m_configs;

    image_list<owned> m_dirs_images;
    settings_dlg_handler() : m_dirs_images(bitmap_::compiler_nodes, 16) {}

    void on_full_create() {
        m_dirs->images(tree_ctrl_::images::normal, m_dirs_images);
        m_mode->sel(0); // "Before"
        refresh_compilers();

        // FIXME implement them - directory-based
        m_configs.push_back( configuration::root());
        m_configs.push_back( debug_config());
        m_configs.push_back( release_config());
        refresh_configs();

        std::string last_known_dir = persist::setting<std::string>("app.last_setting_directory");
        if ( !last_known_dir.empty() )
            expand_and_select( m_dirs, last_known_dir);
    }

    handle_event on_refresh_compilers() {
        refresh_compilers();
        return event<REFRESH_COMPILERS>().HANDLED_BY(&me::on_refresh_compilers);
    }

    handle_event on_refresh_compiler_path() {
        select_compiler( self->m_compiler_path);
        return event<REFRESH_COMPILER_PATH>().HANDLED_BY(&me::on_refresh_compiler_path);
    }

    handle_event on_select_compiler() {
        int sel = m_compiler->sel();
        select_compiler(sel);
        return event_ex<m_compiler_::ev::sel_change>().HANDLED_BY(&me::on_select_compiler);
    }

    handle_event on_select_dir() {
        select_dir( selected_dir() );
        return event_ex<m_dirs_::ev::sel_change>().HANDLED_BY(&me::on_select_dir);
    }

    handle_event on_config_change() {
        if ( m_configuration->sel() < 0) return event_handled_early; // no selection?
        configuration cfg = m_configs[ m_configuration->sel() ];
        sub_wnd<enter_settings_dlg>()->config( cfg);
        self->m_config = cfg;

        persist::setting<std::string>("app.last_configuration_path") = cfg.path().string();
        return event_ex<m_configuration_::ev::sel_change>().HANDLED_BY(&me::on_config_change);
    }


private:
    void select_dir(const std::string & dir) {
        std::string compiler_path = m_idx_to_compiler[m_compiler->sel()];
        bool all_compilers = compiler_path == "root/C++";
        sub_wnd<enter_settings_dlg>()->show_settings( 
            user_comp().get_settings_at_dir(compiler_path, "root/" + dir),
            all_compilers ? enter_settings_dlg::show_applies_to_compilers_col : enter_settings_dlg::hide_applies_to_compilers_col );

        persist::setting<std::string>("app.last_setting_directory") = dir;
    }

    // returns the currently selected directory - if empty, there's no selected dir
    std::string selected_dir() {
        std::string str;
        HTREEITEM sel = m_dirs->sel();
        while (sel) {
            std::string dir_name = m_dirs->item(sel).text();
            if ( !str.empty() ) str = "/" + str;
            str = dir_name + str;
            sel = m_dirs->parent_item(sel);
        }
        return str;
    }

    struct fill_compiler_combo {
        settings_dlg_handler * self;
        fill_compiler_combo( settings_dlg_handler * self) : self(self) {}

        typedef std::vector< tree::item<compiler_ptr>* > array;
        void operator()( tree::item<compiler_ptr> & comp, const array & ascendants) {
            if ( ascendants.empty() ) return; // root

            std::string full_name;
            std::string combo_name;
            for ( crange<const array> r(ascendants); r; ++r) {
                if ( !full_name.empty() ) full_name += "/";
                full_name += (*r)->name();
                combo_name += "  ";
            }
            full_name += "/" + comp.name();
            combo_name += comp.info->friendly_name();

            int count = self->m_compiler->item_count();
            self->m_compiler_to_idx[full_name] = count;
            self->m_idx_to_compiler[count] = full_name;
            self->m_compiler->add_item(combo_name);
        }
    };

    void refresh_configs() {
        m_configuration->del_all_items();
        for ( crange<const config_array> r(m_configs); r; ++r) {
            std::string prefix( (tree_path_name(r->path()).nodes_count() - 2) * 4, ' '); // "root/All/ [...]"
            m_configuration->add_item(prefix + r->friendly_name());
        }

        std::string last_known_config = persist::setting<std::string>("app.last_configuration_path");
        int sel = 0;
        int idx = 0;
        for ( crange<const config_array> r(m_configs); r; ++r, ++idx) 
            if ( r->path() == last_known_config) sel = idx;

        m_configuration->sel(sel);
        on_config_change();
    }

    void refresh_compilers() {
        m_compiler_to_idx.clear();
        m_idx_to_compiler.clear();

        m_compiler->del_all_items();
        
        tree::item<compiler_ptr> compiler_tree = user_comp().get_compiler_tree();
        tree::for_each<tree::parent_first>( compiler_tree, fill_compiler_combo(this) );

        // re-select last known compiler
        self->m_compiler_path = persist::setting<std::string>("app.last_compiler_path");
        if ( !self->m_compiler_path.empty() ) 
            select_compiler( self->m_compiler_path);
        else
            select_compiler(0); // first time...
    }

    struct set_roots_icons_to_dir {
        template<class array> void operator()(tree::item<compiler_dir> & item, const array &a) {
            if ( a.size() == 1)
                item.info.icon_idx = node::main_dir;
            else
                item.info.icon_idx = node::sub_dir;
        }
    };

    void select_compiler(int compiler_idx) {
        assert( compiler_idx < (int)m_idx_to_compiler.size() );
        std::string compiler_str = m_idx_to_compiler[compiler_idx];
        tree::item<compiler_dir> t;
        t = user_comp().get_compiler_setting_dir_tree(compiler_str);
        update_dirs( t);

        m_compiler->sel(compiler_idx);
        self->m_compiler_path = compiler_str; 
        persist::setting<std::string>("app.last_compiler_path") = compiler_str;
    }

    void select_compiler(const std::string & compiler_path) {
        if ( crange<const compiler_to_idx_coll> r = rng::coll_find(m_compiler_to_idx, compiler_path) )
            select_compiler( r->second);
        else {
            BOOST_LOG(err) << "compiler path not found " << compiler_path;
            select_compiler(0);
        }
    }




    struct create_dirs {
        create_dirs(settings_dlg_handler *self) : self(self) {}
        settings_dlg_handler *self;

        typedef std::vector<tree::item<compiler_dir>* > array;
        void operator()(const tree::item<compiler_dir> & t, const array &ascendants) {
            if ( ascendants.empty() ) return; // root tree item

            if ( t.name() == "Configure Compiler")
                // ignore this - it's a special tab. It needs to be applied to Local Disk, so taht
                // all directories inherit it...
                return; 

            wnd<tree_ctrl> dirs = self->m_dirs;
            HTREEITEM parent = 0;
            // ... ignore the "root"
            for ( crange<const array> r(ascendants.begin() + 1, ascendants.end()); r; ++r) {
                std::string name = (*r)->name();
                HTREEITEM next = parent == 0 ? dirs->root() : dirs->first_child(parent);
                while ( next) {
                    if ( dirs->item(next).text() == name) break;
                    next = dirs->next_sibling(next);
                }
                parent = next;
                // could not find parent?
                assert(parent);
            }

            if ( t.info.icon_idx >= 0)
                dirs->add_item(parent, tv_item().text(t.name()).image(t.info.icon_idx) );
            else
                dirs->add_item(parent, tv_item().text(t.name()) );
        }
    };

    // updates the directories tree
    void update_dirs(tree::item<compiler_dir> & t) {
        m_dirs->set_redraw(false);

        // save old selection
        typedef std::deque<std::string> array;
        array old_sel;
        HTREEITEM sel = m_dirs->sel();
        while (sel) {
            std::string dir_name = m_dirs->item(sel).text();
            old_sel.push_front(dir_name);
            sel = m_dirs->parent_item(sel);
        }
        m_dirs->del_all_items();
    
        tree::for_each<tree::parent_first>(t, set_roots_icons_to_dir() );
        tree::for_each<tree::parent_first>(t, create_dirs( this ) );

        // preserve selection if possible
        HTREEITEM parent = m_dirs->root();
        for ( crange<const array> r(old_sel); r; ++r) {
            while ( parent) {
                std::string name = m_dirs->item(parent).text();
                if ( name == *r)
                    break;
                parent = m_dirs->next_sibling(parent);
            }
            if ( parent) {
                // preseve directory. See if can preserve child as well
                m_dirs->expand(parent);
                m_dirs->sel(parent);
                parent = m_dirs->first_child(parent);
            }
            else
                break; // cannot find old selection
        }
        
        m_dirs->set_redraw(true);
        m_dirs->invalidate();
    }

};


settings_dlg::settings_dlg() : m_config( configuration::root() ) {
    m_mode->add_item( tc_item().text("Before"));
    m_mode->add_item( tc_item().text("After"));
    m_mode->add_style( tab_dialog_::style::bottom | tab_dialog_::style::flat_buttons);

    // note: at this time, "Before" and "After" are not implemented.

}

settings_dlg::~settings_dlg() {
}

int settings_dlg::dialog_id() { return dialog_id_; }


// refreshes the compiler list
void settings_dlg::refresh_compilers() {
    send_msg(settings_dlg_handler::REFRESH_COMPILERS);
}


void settings_dlg::compiler_path(const std::string & path) {
    if ( m_compiler_path != path) {
        m_compiler_path = path;
        send_msg(settings_dlg_handler::REFRESH_COMPILER_PATH);
    }
}


void settings_dlg::enable_select_compiler(bool enable_select) {
    m_compiler->enable(enable_select);
}


