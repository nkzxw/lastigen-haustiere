

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "stdafx.h"
// build_statistics_list_dlg.cpp
#include "build_statistics_list_dlg.h"
#include <win32gui/event_handler.hpp>

#include "win32gui_res/build_statistics_list.hpp"

#include "util/file_util.h"
#include "win32gui_res/bitmaps.hpp"
using namespace win32::gui::res_id;

using namespace win32::gui;
using namespace build_statistics;

namespace {
    // images for nodes
    namespace node {
        enum type {
            compiler_root = 0,
            compiler = 1,
            disk = 2,
            dir = 3,
            redirected_dir = 4,
            // directory marked as root
            root_dir = 5,
            drive = 8,
            cpp_file = 9,
            c_file = 10,
            rc_file = 11,

            // directory is a project
            is_project = 12,

            // note: a hidden node means we should compute children nodes only 
            //       when this node is expanded.
            hidden = 13

        };
    }

    int path_to_node(fs::path p) {

        if ( fs::extension(p) == ".cpp" || fs::extension(p) == ".cxx")
            return node::cpp_file;
        else if ( fs::extension(p) == ".c")
            return node::c_file;
        else if ( fs::extension(p) == ".rc")
            return node::rc_file;
        else
            return node::dir;
    }

}

struct build_statistics_list_dlg_handler : event_handler<build_statistics_list_dlg_handler, build_statistics_list_dlg> {

    image_list<owned> m_images;
    build_statistics_list_dlg_handler() : m_images( bitmap_::explorer_nodes, 16) {}

    void on_full_create() {        
        m_results->add_col( lv_col().text("Directory/File").width(280) );
        m_results->add_col( lv_col().text("Spent Time").width(150) );
        m_results->add_col( lv_col().text("Proc Time").width(150) );
        m_results->add_col( lv_col().text("Size").width(180) );

        m_results->images( list_ctrl_::images::small_, m_images);
    }

};

namespace {
    template<class type>
    std::string friendly_number(type val, path_info::result::type res, bool is_valid) {
        std::ostringstream out;
        if (is_valid) {
            if ( res != path_info::result::failure) {
                if ( val > 0)     out << val;
                else              out << "NA"; // value is not available
            }
            else
                out << "Failed";
        }
        else
            out << " - ";
        return out.str();
    }

    template<class type> 
    std::string friendly_compare(
                type first, type second, 
                path_info::result::type first_res, path_info::result::type second_res,
                bool first_valid, bool second_valid) {
        return friendly_number(first, first_res, first_valid) + " / " + friendly_number(second, second_res, second_valid);
    }


    template<class type>
    std::string friendly_percentage(
                type first, type second, 
                path_info::result::type first_res, path_info::result::type second_res,
                bool first_valid, bool second_valid) {
        bool can_be_computed = true;
        if ( !first_valid || !second_valid) 
            can_be_computed = false;
        if ( first_res == path_info::result::failure || second_res == path_info::result::failure)
            can_be_computed = false;
        if ( !(first > 0) || !(second > 0))
            can_be_computed = false; // one of the values is not available

        if ( can_be_computed) {
            double percentage = ((double)first * 100) / second;
            return str_stream() << " (" << (int)percentage << "%)";
        }
        else
            return "";
    }
}


build_statistics_list_dlg::build_statistics_list_dlg() {
    add_resizable_ctrl(m_results_::id, size_xy);
}

build_statistics_list_dlg::~build_statistics_list_dlg() {
}

int build_statistics_list_dlg::dialog_id() { return dialog_id_; }


void build_statistics_list_dlg::add_single_statistics(fs::path path, build_statistics::path_info cur_stats) {

    std::string spent = friendly_number( ((double)cur_stats.spent_time_ms / 1000), cur_stats.build_res, true);
    std::string processor = friendly_number( ((double)cur_stats.processor_time_ms / 1000), cur_stats.build_res, true);
    std::string size = friendly_number( cur_stats.size, cur_stats.build_res, true);

    // in case any param is empty, better leave the column empty
    if ( cur_stats.spent_time_ms == 0) spent.erase();
    if ( cur_stats.processor_time_ms == 0) processor.erase();
    if ( cur_stats.size == 0) size.erase();

    add_line(path, spent, processor, size);
}

void build_statistics_list_dlg::add_compare_statistics(fs::path path, build_statistics::path_info one, build_statistics::path_info two, bool one_valid, bool two_valid) {
    std::string spent = 
        friendly_compare(   ((double)one.spent_time_ms / 1000), ((double)two.spent_time_ms / 1000), 
                            one.build_res, two.build_res, one_valid, two_valid) +
        friendly_percentage(one.spent_time_ms, two.spent_time_ms, one.build_res, two.build_res, one_valid, two_valid);
    std::string processor = 
        friendly_compare(   ((double)one.processor_time_ms / 1000), ((double)two.processor_time_ms / 1000), 
                            one.build_res, two.build_res, one_valid, two_valid) +
        friendly_percentage(one.processor_time_ms, two.processor_time_ms, one.build_res, two.build_res, one_valid, two_valid);
    std::string size = 
        friendly_compare(   one.size, two.size , 
                            one.build_res, two.build_res, one_valid, two_valid) +
        friendly_percentage(one.size, two.size, one.build_res, two.build_res, one_valid, two_valid);

    add_line(path, spent, processor, size);
}


void build_statistics_list_dlg::add_line(fs::path path, const std::string & spent, const std::string & processor, const std::string & size) {
    if ( m_root.empty())
        m_root = path_to_string(path); // first path, is root

    bool is_subpath_of_root = path_to_string(path).find(m_root) == 0;
    if ( !is_subpath_of_root) 
        m_root = path_to_string(path); // we have a new root...

    bool is_root = path_to_string(path) == m_root;
    std::string relative_to_root;
    int indent = 0;
    if ( is_root) 
        relative_to_root = path.string();
    else {
        // ignore the "root" part
        relative_to_root = path.string().substr( m_root.size() );
        if ( relative_to_root[0] == '/') relative_to_root = relative_to_root.substr(1);
        indent = tree_path_name(relative_to_root).nodes_count();
        // now, show only the leaf - the rest is already present in upper nodes.
        relative_to_root = tree_path_name(relative_to_root).last_node();
    }

    m_results->add_item( lv_item()
        .text(relative_to_root)
        .image( path_to_node(path))
        .indent(indent)
        );
    int last = m_results->item_count() - 1;
    m_results->item( last, 1, lv_item().text(spent) );
    m_results->item( last, 2, lv_item().text(processor) );
    m_results->item( last, 3, lv_item().text(size) );

    m_results->sel(last);
    m_results->ensure_visible(last);
}


void build_statistics_list_dlg::clear() {
    m_results->del_all_items();
    m_root.erase();
}


