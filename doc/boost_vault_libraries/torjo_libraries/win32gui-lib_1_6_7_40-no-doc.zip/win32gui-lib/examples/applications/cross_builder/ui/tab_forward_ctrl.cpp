

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\tab_forward_ctrl.h"
#include "resource.h"

using namespace win32::gui;

struct tab_forward_ctrl_handler : event_handler<tab_forward_ctrl_handler, tab_forward_ctrl> {
    handle_event on_set_focus(w_param<HWND> h) {
        wnd<> from = find_by_hwnd( (HWND)h);
        if ( self->m_f) {
            wnd<> before = from, after = from;
            self->m_f(before, after);

            bool shift_pressed = ::GetAsyncKeyState(VK_SHIFT) < 0;
            wnd<> to_focus = after;
            if ( shift_pressed) to_focus = before;

            if ( to_focus)
                to_focus->set_focus();
            else
                assert(false); // invalid window to focus to!
        }
        return event_ex<wm::keyb::set_focus>().HANDLED_BY(&me::on_set_focus);
    }
};


tab_forward_ctrl::tab_forward_ctrl() {
    move( rectangle(-10,-10,-5,-5) ); // make ourselves invisible...
}

tab_forward_ctrl::~tab_forward_ctrl(void)
{
}

bool tab_forward_ctrl::matches_hwnd(HWND h) {
    int ctrl_id = hwnd_func::dlg_ctrl_id(h);
    return (ctrl_id >= ID_forwardtab1) && (ctrl_id <= ID_forwardtab5);
}

/** 
    specifies what function to call, when it gained focus
*/
void tab_forward_ctrl::call_on_focus(focus_func f) {
    m_f = f;
}

