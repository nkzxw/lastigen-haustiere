

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "setting/setting.h"
#include "setting/setting_value.h"
#include "setting/configuration.h"
#include "setting/tree_path_name.h"

/** 
    @brief Uniquely identify a setting that is to be get and/or set.

*/
struct setting_key {
    // the setting mode 
    struct mode {
        typedef enum type {
            before,
            after
        };
    };

    setting_key(
        const std::string & name = "", configuration config = configuration::root(), 
        mode::type setting_mode = mode::before, std::string compiler = "");

    // the setting's normalized name
    std::string name;

    configuration config;

    mode::type setting_mode;

    // the compiler this setting is for (it's a compiler path)
    // (note: this can also be "root/C++" - applies to all compilers)
    tree_path_name compiler;
};

bool operator<(const setting_key & first, const setting_key & second);
bool operator==(const setting_key & first, const setting_key & second);
inline bool operator!=(const setting_key & first, const setting_key & second) { return !(first == second); }
std::ostream& operator<<(std::ostream& out, const setting_key & key);


class logical_path_setting_values ;
typedef shared_ptr<logical_path_setting_values> logical_path_setting_values_ptr;
class settings_holder;

/** 
    @brief Represents all the settings from a given logical path

    FIXME test for redirections. What happens when the user modifies something for 
    a redirected directory?
*/
class logical_path_setting_values {
    // only the settings holder can create us...
    friend class settings_holder;

    logical_path_setting_values(fs::path dir, logical_path_setting_values_ptr parent = logical_path_setting_values_ptr() );
public:
    ~logical_path_setting_values();

    fixed_setting_value get_value(const setting & set, const setting_key & key) const;
    void set_value(const setting & set, const setting_key & key, fixed_setting_value val);

    void save();

private:
    void load();
    void refresh() const ;


private:
    // Note: setttings from different physical paths might be saved to the same
    //       physical file. Thus, we can't allow two concurrent saves to happen, since
    //       if both are to be written to the same file, data corruption could appear
    static critical_section & s_save_cs();

    mutable critical_section m_cs;

    /** 
        @brief All values a setting has (for each compiler, configuration, etc.)
    */
    struct setting_info {
        // note: for different compilers, a setting could have different meanings
        // (for instance, be a bool for one compilers, while an enumeration for the rest)
        //
        // If that is the case, we can not have a value for "root/C++" compilers
        typedef std::map<setting_key, setting_value> coll;
        
        // values for this setting
        coll m_values;
        
        // the values inherited from our ascendants
        //
        // Note that the these two collections aren't necessary of the same size
        // (we might inherit different things from our ascendants)
        //
        // Also, when the user requests a settings, lets say for all compilers, but
        // the on the parent, there are different values for each compiler. Thus, the 
        // parent simply does not have a valid value for all settings.
        coll m_inherited;
    };
    // key - the setting' normalized name...
    typedef std::map<std::string, setting_info> setting_coll;

    static setting_value value_for_setting_key(const setting & set, const setting_key & key, const setting_info::coll & vals);
    static void save_impl(fs::path dir, setting_coll &settings);

    mutable setting_coll m_settings;


    // this is a unique ID, which, with every change (every time the user modifies something), 
    // is constantly increased.
    // 
    // Whenever that happens, all children must update their settings.
    // Every object of this type does this, whenever you do an operation on it (a get or set),
    // thus, being very efficient.
    mutable int m_change_id;

    // this is the parent's Change ID, last time we asked. If when we ask again, and it's different,
    // we need to update
    mutable int m_parent_last_known_change_id;

    // the change ID of the last save. This is how we know if we need to save to disk:
    // if this is different from m_change_id, a Save is needed...
    int m_save_id;

    // the parent, or null if none.
    logical_path_setting_values_ptr m_parent;

    // our physical path - where we load/save settings from/to
    fs::path m_dir;
};

