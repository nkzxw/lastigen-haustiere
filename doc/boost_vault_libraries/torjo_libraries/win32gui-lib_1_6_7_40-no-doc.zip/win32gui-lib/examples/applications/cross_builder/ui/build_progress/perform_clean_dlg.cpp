

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\perform_clean_dlg.h"
#include "win32gui_res/perform_clean.hpp"
#include "setting/computer.h"
#include "main/app.h"
#include "build/build.h"
#include "build/resolve_parameter.h"
#include "util/command_util.h"
#include "util/string_util.h"

using namespace win32::gui;

namespace {
    bool is_project_path(const logical_path & path, compiler_ptr comp, configuration config) {
        std::string val = get_setting_value("is project", path, comp, config);
        return val != "0";
    }
    std::string project_name(const logical_path & path, compiler_ptr comp, configuration config) {
        return resolve_value( "$(project_name)", path, comp, config);
    }

    void add_text(wnd<edit> e, const std::string & msg) {
        int size = (int)e->text().size();
        if ( size > 64 * 1024) {
            // truncate
            std::string txt = e->text().substr( 64 * 1024 / 2);
            e->text(txt);
            size = (int)txt.size();
        }
        e->sel(size, size);
        e->replace_sel(msg);
        e->scroll_caret();
    }
}


struct perform_clean_dlg_handler : event_handler<perform_clean_dlg_handler, perform_clean_dlg> {
    void on_full_create() {
        self->m_clean_wnd = self.to_wnd();
    }

    handle_event on_stop() {
        m_ok->enable(true);
        self->add_msg("\n*** Stopped");
        m_stop->enable(false);
        scoped_lock lk(self->m_cs);
        self->m_do_cancel = true;
        return event_ex<m_stop_::ev::clicked>().HANDLED_BY(&me::on_stop);
    }

    handle_event on_ok() {
        // FIXME there is a bug in win32gui here. Somehow, I reference some memory after being deleted
        // (I get a HEAP exception)
        self->destroy();
        return event_ex<m_ok_::ev::clicked>().HANDLED_BY(&me::on_ok);
    }


    handle_event on_cancel() {
        { scoped_lock lk(self->m_cs);
        self->m_do_cancel = true; }
        // FIXME there is a bug in win32gui here. Somehow, I reference some memory after being deleted
        // (I get a HEAP exception)
        self->destroy();
        return event_ex<m_cancel_::ev::clicked>().HANDLED_BY(&me::on_cancel);
    }
    
    handle_event on_destroy() {
        scoped_lock lk(self->m_cs);
        self->m_do_cancel = true;
        return event_ex<wm::destroy>().HANDLED_BY(&me::on_destroy);
    }
};



perform_clean_dlg::perform_clean_dlg() : m_started(false), m_do_cancel(false), m_clean_wnd(null_wnd), m_cleaned_projects(0) {
    m_msg->max_chars(256 * 1024);
}

perform_clean_dlg::~perform_clean_dlg(void)
{
}

int perform_clean_dlg::dialog_id() { return dialog_id_; }


void perform_clean_dlg::add_path_to_clean(const logical_path &path, configuration config, std::string compiler) {
    assert ( !m_started);
    m_cleans.push_back( clean_info(path,config,compiler) );

}


void perform_clean_dlg::add_msg(std::string msg) {
    str_replace( msg, "\n", "\r\n");
    str_replace( msg, "\r\r\n", "\r\n");
    add_text( m_msg, msg);
}


bool perform_clean_dlg::is_cancelled() const {
    if ( !is_valid() ) return true;
    scoped_lock lk(m_cs);
    if ( m_do_cancel ) return true;

    return false;
}


void perform_clean_dlg::start() {
    if ( m_started) {
        assert(false);
        return;
    }

    // start the runner thread...
    using namespace boost;
    thread::thread( bind(&perform_clean_dlg::run, this));
}

/** 
    performs the clean, on a dedicated thread
*/
void perform_clean_dlg::run() {
    while ( true) {
        if ( is_cancelled() ) break;

        clean_info clean;
        {
        scoped_lock lk(m_cs);
        if (m_cleans.empty())
            break; // we've built everything...
        clean = m_cleans[0];
        m_cleans.erase( m_cleans.begin());
        }

        try {
            compiler_ptr comp = user_comp().get_compiler( clean.compiler);
            // can't be performed on intermediate compilers
            if ( !comp->is_intermediate()) {
                int old_clean_count = m_clean_wnd->m_cleaned_projects;
                m_clean_wnd->recurse_clean( clean, comp);

                bool found_subproject = old_clean_count != (m_clean_wnd->m_cleaned_projects);
                if ( !found_subproject)
                    // special case - when no projects found - clean the directory
                    m_clean_wnd->clean_project( clean, comp);
            }
            else 
                m_clean_wnd->add_msg("Invalid compiler " + clean.compiler);
        } catch(std::exception & exc) {
            BOOST_LOG(err) << "cleaning " << clean.config.friendly_name() << "/" << clean.compiler << " for "
                << clean.path.physical_path().string() 
                << ":" << exc.what();
            m_clean_wnd->add_msg( "Exception" + std::string(exc.what()));
        }
    }
    if ( !is_cancelled() ) {
        m_clean_wnd->add_msg("\n*** Finished");
        m_clean_wnd->m_ok->enable(true); // allow pressing ok
        m_clean_wnd->m_stop->enable(false);
        m_clean_wnd->m_cancel->enable(false);
    }
    // release the reference to ourselves - allow our object to be destroyed
    m_clean_wnd = null_wnd;
}


/** 
    Performs a recursive clean of the given logical path. That is, it recursively searches all subdirectories
    of the physical path, and where a project is found, it cleans it
*/
void perform_clean_dlg::recurse_clean(const clean_info & clean, compiler_ptr comp) {
    if ( is_cancelled() ) return;

    fs::path cur_path = clean.path.physical_path().string();
    if ( is_project_path(clean.path, comp, clean.config) )
        clean_project(clean, comp);

    for ( fs::directory_iterator begin(cur_path), end; begin != end; ++begin)
        if ( fs::is_directory(*begin) ) {
            clean_info sub = clean;
            sub.path = sub.path.sub_path( *begin);
            recurse_clean(sub, comp);
        }
}

namespace {
    void recurse_clean_dir(fs::path p, bool & ok) {
        typedef std::vector<fs::path> array;
        array sub_dirs;
        // first, delete from subdirectories
        for ( fs::directory_iterator begin(p), end; begin != end; ++begin)
            if ( fs::is_directory(*begin)) sub_dirs.push_back(*begin);
        for ( crange<const array> r(sub_dirs); r; ++r) 
            recurse_clean_dir(*r, ok);
    
        try {
            run_sys_command_as_hidden("cmd /C del *.* /F /Q", p);
            for ( fs::directory_iterator begin(p), end; begin != end; ++begin)
                if ( fs::is_directory(*begin))
                    run_sys_command_as_hidden("cmd /C rmdir /S /Q " + begin->leaf(), p);

        } catch(std::exception & exc) {
            BOOST_LOG(err) << "error while cleaning " << exc.what();
            ok = false;
        }

    }
}


/** 
    considers this path a project, and cleans it.
*/
void perform_clean_dlg::clean_project(const clean_info & clean, compiler_ptr comp) {
    if ( is_cancelled() ) return;

    BOOST_LOG(app) << "cleaning " << project_name(clean.path, comp, clean.config);
    std::string friendly_msg = project_name(clean.path,comp,clean.config) + " for " + comp->friendly_name() + " (" + clean.config.friendly_name() + ")";
    add_msg("Cleaning " + friendly_msg + "..." );
    // ... set title
    text( friendly_msg);

    fs::path project_root = clean.path.physical_path();
    fs::path clean_root = project_build_path(clean.path, clean.config, clean.compiler);
    bool ok = true;
    if ( fs::exists(clean_root))
        recurse_clean_dir(clean_root, ok);
    add_msg(ok ? " ok\n" : " - FAILED\n");
    ++m_cleaned_projects;
}

