

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "util/command_util.h"
#include "build/logical_path.h"
#include "setting/configuration.h"

namespace build_statistics {

/** 
    @brief Represents statics for a logical path
*/
struct path_info {
    struct result {
        enum type {
            success = 0,
            failure = 1,
        };
    };

    // note: even if it's already built, the size still might matter!
    path_info( run_sys_command_results stats = run_sys_command_results(), int size = 0, result::type res = result::success, bool is_already_built = false)
        : processor_time_ms(stats.processor_time_ms), 
          spent_time_ms(stats.spent_time_ms),
          size(size), build_res(res), 
          is_already_built(is_already_built) {}

    void add(const path_info & sub);

    // time it took (in milliseconds)
    unsigned int processor_time_ms;
    unsigned int spent_time_ms;

    // if true, this file was already built. If so, we'll take the last
    // kwnown times - very useful for comparisons...
    bool is_already_built;

    // size of object file
    unsigned int size;
    // type of build
    result::type build_res;
};




/**  
    @brief uniquely identify a build, from a directory
*/
struct dir_build_key {
    dir_build_key(int slot_idx, const std::string & compiler, const std::string & config, time_t build_time)
        : slot_idx(slot_idx), compiler(compiler), config(config), build_time(build_time) {}

    // uniquely identify this build within its directory
    int slot_idx;
    std::string compiler;
    std::string config;
    time_t build_time;
};


/** 
    @brief information about the dirs that have been done for a directory 
*/
struct dir_builds {
    dir_builds(fs::path dir, int idx, time_t last_build_time) 
        : dir(dir), dir_idx(idx), last_build_time(last_build_time) {}

    // ... the index that uniquely identifies the directory
    int dir_idx;
    fs::path dir;
    time_t last_build_time;

    typedef std::vector<dir_build_key> builds_array;
    builds_array builds;
};

typedef std::vector<dir_builds> dir_builds_array;

void load_dir_build_tree(dir_builds_array & dirs);


std::string new_prefix(const logical_path & build_path, configuration config, const std::string & compiler);
std::string latest_prefix(const logical_path & project_path, configuration config, const std::string & compiler);
std::string pinned_prefix(const logical_path & project_path, configuration config, const std::string & compiler);

void unpin_previous_builds(const logical_path & project_path, configuration config, const std::string & compiler);

}

