
// Utility Library
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
#include "StdAfx.h"
#include ".\command_util.h"

namespace {
    DWORD close_filetime_diff(FILETIME end, FILETIME start) {
        ULARGE_INTEGER u_end, u_start;
        u_end.LowPart = end.dwLowDateTime;
        u_end.HighPart = end.dwHighDateTime;
        u_start.LowPart = start.dwLowDateTime;
        u_start.HighPart = start.dwHighDateTime;
        // note: I rely on the fact that the times are very close, so the difference 
        // fits into a word...
        return (DWORD)(u_end.QuadPart - u_start.QuadPart);
    }
}

/** 
    Runs a system command, but invisible to the user.

    @param timeout_ms - how long to wait for the command to finish. If not finished by then,
    terminates it
*/
run_sys_command_results run_sys_command_as_hidden(std::string cmd_line, fs::path home_dir, int timeout_ms) {
    if ( cmd_line.size() > 32*1024)
        throw std::runtime_error("command line too big: " + cmd_line);

    run_sys_command_results results;
    // system(cmd_line);
    STARTUPINFO startup_info = { 0 };
    PROCESS_INFORMATION process_info = { 0 };
    ::ZeroMemory( &startup_info, sizeof(startup_info));
    ::ZeroMemory( &process_info, sizeof(process_info));
    startup_info.cb = sizeof(startup_info);
    startup_info.dwFlags = STARTF_USESHOWWINDOW;
    startup_info.wShowWindow = SW_HIDE; 
    bool ok = ::CreateProcess(0, const_cast<char*>(cmd_line.c_str()), 
        0, 0, 
        false, 
        0, // creation flags
        0,
        home_dir.string().c_str(),
        &startup_info,
        &process_info) != 0;

    if ( ok) {
        // wait for this process to finish
        int wait_ms = timeout_ms ; 
        bool has_finished = false;
        while ( wait_ms > 0) {
            ::Sleep(100);
            wait_ms -= 100;
            DWORD exit_code = 0; ::GetExitCodeProcess(process_info.hProcess, &exit_code);
            if ( exit_code != STILL_ACTIVE) {
                // has finished, gather statistics
                has_finished = true;
                results.successful = true;
                FILETIME start, end , kernel, user;
                ::GetProcessTimes(process_info.hProcess, &start, &end, &kernel, &user);
                DWORD processor_nano_100 = kernel.dwLowDateTime + user.dwLowDateTime;
                DWORD spent_nano_100 = close_filetime_diff(end, start);
                results.processor_time_ms = processor_nano_100 / 10000;
                results.spent_time_ms = spent_nano_100 / 10000;
                break;
            }
        }
        if ( !has_finished) 
            ::TerminateProcess(process_info.hProcess, 1);
    }
    else
        throw std::runtime_error( boost::str_stream() << "error: " << ::GetLastError() << " while executing command " << cmd_line );
    return results;
}

