

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\fs.h"
#include "util/string_util.h"

using namespace boost::rangelib;

namespace tree {
/** 
    FileSystem functions that return trees
*/

namespace detail {
    bool case_insensitive_less(const std::string & first, const std::string & second) {
        return locase(first) < locase(second);
    }
}


// returns the directory tree that descend from the given path (a path within the File System)
//
// note: this function is inefficient - thus, you should use it only when
//       you know there are very few descendants
item<> descendant_directory_tree(fs::path p) {
    typedef item<> item_type;

    typedef std::vector<std::string> array;
    array children;
    for ( fs::directory_iterator begin(p), end; begin != end; ++begin)
        if ( fs::is_directory(*begin))
            children.push_back( begin->leaf() );
    rng::sort( children, detail::case_insensitive_less);

    item_type t( p.leaf() );
    for ( crange<array> r(children); r; ++r) 
        t.children.push_back( descendant_directory_tree(p / *r) );
    return t;
}

} // namespace tree


