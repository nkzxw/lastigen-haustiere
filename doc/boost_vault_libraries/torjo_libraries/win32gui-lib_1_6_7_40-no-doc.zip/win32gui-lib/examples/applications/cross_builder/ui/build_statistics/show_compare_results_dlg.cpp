

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "stdafx.h"
// show_compare_results_dlg.cpp
#include "show_compare_results_dlg.h"
#include <win32gui/event_handler.hpp>

#include "setting/configuration.h"
#include "ui/build_statistics/build_statistics_dlg.h"
#include "ui/build_statistics/build_statistics_list_dlg.h"

#include "build_statistics/read_build_statistics.h"
#include "util/file_util.h"

#include "win32gui_res/build_statistics_show.hpp"
#include "win32gui_res/build_statistics.hpp"


using namespace win32::gui;
using namespace boost::rangelib;
using namespace build_statistics;

namespace {
    typedef m_litehtml1_ m_title;

}


struct show_compare_results_dlg_handler : event_handler<show_compare_results_dlg_handler, show_compare_results_dlg> {

    handle_event on_new_compare() {
        parent<build_statistics_dlg>()->child<tab_dialog>(build_statistics_::m_tabdialog1_::id)->sel(0);
        return event_ex<m_new_compare_::ev::clicked>().HANDLED_BY(&me::on_new_compare);
    }

};


show_compare_results_dlg::show_compare_results_dlg() {
    add_resizable_ctrl(m_build_statistics_list_::id, size_xy);
    add_resizable_ctrl(m_new_compare_::id, move_xy);
}

show_compare_results_dlg::~show_compare_results_dlg() {
}

int show_compare_results_dlg::dialog_id() { return dialog_id_; }


namespace {
    std::string friendly_build_name(build_statistics_key key) {
        return str_stream() 
            << "<font color=blue><b>" << key.dir.string() << "</b></font>"
            << ", at " << friendly_time(key.at_time)
            << ", with <font color=green> " << compiler_friendly_name(key.compiler) 
            << " (" << configuration(key.config).friendly_name() << ")</font>";
    }

    // makes sure that the path indicating the Link Time is shown conceptually last
    void adjust_link_path(fs::path & p) {
        if ( p.leaf() == "Link Time") {
            std::string prefix;
            prefix += char(255);
            p = p.branch_path() / (prefix + "Link Time");
        }        
    }
    // allow sorting ...
    bool by_path_name(const read_for_dir::path_statistics & first, const read_for_dir::path_statistics & second) {
        fs::path first_p = first.path;
        fs::path second_p = second.path;
        adjust_link_path( first_p);
        adjust_link_path( second_p);
        return path_to_string(first_p) < path_to_string(second_p);
    }

    // for unique
    bool same_path_name(const read_for_dir::path_statistics & first, const read_for_dir::path_statistics & second) {
        return path_to_string(first.path) == path_to_string(second.path);
    }



}


/** 
    shows a single build statistics 
*/
void show_compare_results_dlg::show_single(build_statistics_key key) {
    // update title
    m_type->text("Showing...");
    sub_wnd<build_statistics_list_dlg>()->clear();
    child<m_title>()->text( friendly_build_name(key)  );

    read_for_dir key_stats(key.dir, key.build_prefix);

    typedef read_for_dir::statistics_array array;
    array full = key_stats.stats();
    rng::sort(full, by_path_name);
    if ( full.empty()) return; // nothing to show

    std::string root = path_to_string(full[0].path);
    for ( crange<const array> r(full); r; ++r) {
        path_info cur_stats = key_stats.path_stats( r->path ).stats;
        sub_wnd<build_statistics_list_dlg>()->add_single_statistics( r->path, cur_stats);
    }
}


/** 
    Compares two build statistics
*/
void show_compare_results_dlg::show_compare(build_statistics_key first, build_statistics_key second) {
    m_type->text("Comparing...");
    sub_wnd<build_statistics_list_dlg>()->clear();
    child<m_title>()->text( friendly_build_name(first) + "<br>" + friendly_build_name(second) );

    read_for_dir first_stats(first.dir, first.build_prefix);
    read_for_dir second_stats(second.dir, second.build_prefix);

    typedef read_for_dir::statistics_array array;
    array full = first_stats.stats();
    full.insert( full.end(), second_stats.stats().begin(), second_stats.stats().end() );
    rng::sort(full, by_path_name);
    rng::erase(full, rng::unique(full, same_path_name) );
    if ( full.empty()) return; // nothing to show

    std::string root = path_to_string(full[0].path);
    for ( crange<const array> r(full); r; ++r) {

        bool one_valid = true, two_valid = true;
        path_info one, two;
        if ( first_stats.has_path_stats(r->path))      one = first_stats.path_stats( r->path ).stats;
        else                                           one_valid = false;
        if ( second_stats.has_path_stats(r->path))     two = second_stats.path_stats( r->path ).stats;
        else                                           two_valid = false;

        sub_wnd<build_statistics_list_dlg>()->add_compare_statistics( r->path, one, two, one_valid, two_valid);
    }
}



