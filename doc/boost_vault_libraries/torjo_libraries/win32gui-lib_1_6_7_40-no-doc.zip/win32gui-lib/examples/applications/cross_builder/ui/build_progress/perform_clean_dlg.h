

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "build/logical_path.h"
#include "setting/configuration.h"
#include "setting/compiler.h"

struct perform_clean_dlg_handler ;

/** 
    @brief cleans a directory
*/
struct perform_clean_dlg : wnd_extend<dialog, perform_clean_dlg> {
    perform_clean_dlg(void);
    ~perform_clean_dlg(void);

    static int dialog_id();

    void add_path_to_clean(const logical_path &path, configuration config, std::string compiler);
    void start();

private:
    void add_msg(std::string msg);
    bool is_cancelled() const;

    friend struct perform_clean_dlg_handler ;
    // enough information to do one clean;
    // we might perform multiple cleanings at once...
    struct clean_info {
        clean_info(const logical_path & path = fs::path(), configuration config = configuration::root(), std::string compiler = "") 
            : path(path),config(config),compiler(compiler) {}
        logical_path path;
        configuration config;
        std::string compiler;
    };
    typedef std::vector<clean_info> clean_array;

    mutable critical_section m_cs;
    clean_array m_cleans;

    // pointer to ourself - needed by the runner thread
    win32::gui::wnd<perform_clean_dlg> m_clean_wnd;

    // if this is set to true, we should cancel building...
    bool m_do_cancel;

    // the number of projects that have been cleaned (successfully or failed)
    int m_cleaned_projects;

    void run();
    void recurse_clean(const clean_info & clean, compiler_ptr comp);
    void clean_project(const clean_info & clean, compiler_ptr comp);

    // if true, it's started to do its work...
    bool m_started;

};
