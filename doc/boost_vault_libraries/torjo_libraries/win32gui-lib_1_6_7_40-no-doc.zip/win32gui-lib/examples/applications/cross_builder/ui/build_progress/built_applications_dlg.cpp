

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\built_applications_dlg.h"

#include "win32gui_res/built_applications.hpp"

#include "build/resolve_parameter.h"
#include "shellapi.h"

using namespace win32::gui;

struct built_applications_dlg_handler : event_handler<built_applications_dlg_handler, built_applications_dlg> {

    handle_event on_run() {
        int sel = m_successes->sel();
        if (sel <= 0) sel = 0;
        std::string path = m_successes->item(sel, 1).text();
        // FIXME allow "Working Directory" - for when running executables.
        std::string home_dir = fs::path(path).branch_path().string();
        ::ShellExecute( window()->raw_hwnd(), "open", path.c_str(), 0, home_dir.c_str(), SW_SHOW);
        return event_ex<m_run_::ev::clicked>().HANDLED_BY(&me::on_run);
    }

    handle_event on_explore() {
        int sel = m_successes->sel();
        if (sel <= 0) sel = 0;
        std::string path = m_successes->item(sel, 1).text();
        std::string home_dir = fs::path(path).branch_path().string();
        ::ShellExecute( window()->raw_hwnd(), "explore", home_dir.c_str(), 0, 0, SW_SHOW);
        return event_ex<m_explore_::ev::clicked>().HANDLED_BY(&me::on_explore);
    }
};

built_applications_dlg::built_applications_dlg(void) {
    child<splitter>(m_splitter2_::id)->sizing(splitter::sizing_left_only);

    m_successes->add_col( lv_col().text("Successful Projects").width(250) );
    m_successes->add_col( lv_col().text("Full Path").width(400) );

    m_failures->add_col( lv_col().text("Failed Projects").width(250) );
}

built_applications_dlg::~built_applications_dlg(void)
{
}

int built_applications_dlg::dialog_id() { return dialog_id_; }

// FIXME (nice to have) in the future, maybe allow setting what program should be used
// to open a certain type of file
void built_applications_dlg::add_success(const logical_path & project_path, fs::path out_path, compiler_ptr comp, configuration config) {
    std::string friendly_name = resolve_value("$(project_name)", project_path, comp, config) + " for " + comp->friendly_name() + " (" + config.friendly_name() + ")";
    m_successes->add_item( lv_item().text(friendly_name) );
    int last = m_successes->item_count() - 1;
    m_successes->item(last, 1, lv_item().text( out_path.string()) );
    m_successes->sel(last);

    m_run->enable(true);
    m_explore->enable(true);
}

void built_applications_dlg::add_failure(const logical_path & project_path, compiler_ptr comp, configuration config) {
    std::string friendly_name = resolve_value("$(project_name)", project_path, comp, config) + " for " + comp->friendly_name() + " (" + config.friendly_name() + ")";
    m_failures->add_item( lv_item().text(friendly_name) );
    int last = m_failures->item_count() - 1;
    m_failures->sel(last);
}
