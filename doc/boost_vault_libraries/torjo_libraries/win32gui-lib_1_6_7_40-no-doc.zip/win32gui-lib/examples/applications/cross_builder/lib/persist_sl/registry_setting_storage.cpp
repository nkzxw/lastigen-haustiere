// Persist Settings Library
//
// Copyright 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

// registry_setting_storage.cpp: implementation of the registry_setting_storage class.
//
//////////////////////////////////////////////////////////////////////

#include "registry_setting_storage.h"
#include <windows.h>
#include <vector>
#include <algorithm>
#include <assert.h>

// note: it needs to be linked against advapi32.lib

namespace persist {

    namespace {
    typedef std::vector<HKEY> keys_array;

    void close_reg_key( const keys_array & keys);

    // tries to open this sub key. In case it does not exist, tries to create it.
    std::pair<HKEY,bool> open_reg_subkey( HKEY key, const std::string & subkey_name, REGSAM access) {
        HKEY result = 0;
        bool ok = RegOpenKeyEx( key, subkey_name.c_str(), 0, access, &result) == ERROR_SUCCESS;
        if (!ok) 
            // try to create it
            ok = RegCreateKeyEx( key, subkey_name.c_str(), 0, 0, REG_OPTION_NON_VOLATILE, 
                access | KEY_CREATE_SUB_KEY, 0, &result, 0) == ERROR_SUCCESS;
        return std::pair<HKEY,bool>(result,ok);
    }

    // tries to open this registry key - in case it couldn't, it returns an empty array of keys
    void open_reg_key( const std::string & name, keys_array & keys, REGSAM access) {
        if ( name.empty() )
            return;

        int idx = 0;
        while ( true) {
            int next = (int)name.find_first_of( "./\\", idx);
            std::string subkey = name.substr( idx, next - idx);
            std::pair<HKEY,bool> child;
            if ( !keys.empty() ) 
                child = open_reg_subkey( keys.back(), subkey, access);
            else {
                // need to open root
                child.second = true;
                if ( subkey == "CR" || subkey == "HKCR")
                    child.first = HKEY_CLASSES_ROOT;
                else if ( subkey == "CC" || subkey == "HKCC")
                    child.first = HKEY_CURRENT_CONFIG;
                else if ( subkey == "CU" || subkey == "HKCU")
                    child.first = HKEY_CURRENT_USER;
                else if ( subkey == "LM" || subkey == "HKLM")
                    child.first = HKEY_LOCAL_MACHINE;
                else if ( subkey == "U" || subkey == "HKU")
                    child.first = HKEY_USERS;
                else
                    child.second = false; // unknown root                
            }

            if ( child.second == true)
                keys.push_back( child.first);
            else {
                // there was a failure opening this key
                close_reg_key( keys);
                keys.clear();
                return;
            }

            if ( next != std::string::npos)
                idx = next + 1;
            else
                break; // reached end of string
        }
    }

    // closes all the keys (in reverse order)
    void close_reg_key( const keys_array & keys) {
        std::for_each( keys.rbegin(), keys.rend(), RegCloseKey);
    }


    // splits name into names for key & value
    // Example: "app.wnd.left" into "app.wnd" (key) and "left" (value)
    void split_name( const std::string & name, std::string & name_key, std::string & name_val) {
        // find last '.',representing the name value
        std::string::const_reverse_iterator found = std::find( name.rbegin(), name.rend(), '.');
        if ( found != name.rend() ) {
            std::string::const_iterator key_start = found.base() -1; 
            name_key = std::string( name.begin(), key_start);
            name_val = std::string( key_start + 1 /* ignore the dot */, name.end());

        }
        else {
            // we have just a value name, like "cache_size"
            name_key.erase();
            name_val = name;
        }
    }


    // gets the value from the registry
    bool get_reg_value( const std::string & name, HKEY key, std::string & value) {
        DWORD type;
        DWORD len = 0;
        // first, find out the size of the buffer
        RegQueryValueExA( key, name.c_str(), 0, &type, 0, &len);
        value.resize( len);
        bool ok = RegQueryValueExA( key, name.c_str(), 0, &type, reinterpret_cast<BYTE*>(&*value.begin()), &len) == ERROR_SUCCESS;
        if ( !ok)
            return false;
        switch ( type) {
        case REG_BINARY:
            return true;
        case REG_DWORD: {
            DWORD int_value = *reinterpret_cast<DWORD*>(&*value.begin());
            std::ostringstream out;
            out << int_value;
            value = out.str();
            return true; } 
        case REG_EXPAND_SZ:
            /* falls through */
        case REG_SZ:
            value.resize( len - 1); // ignore the ending '\0'
            return true;
        case REG_MULTI_SZ:
            // note: we're also treating this as binary
            return true;
        default:
            // unhandled type of registry value
            assert(false);
            return false;
        };
    }

    // sets the value into the registry
    bool set_reg_value( const std::string & name, HKEY key, const std::string & value) {
        return RegSetValueExA( key, name.c_str(), 0, REG_SZ, 
            reinterpret_cast<const BYTE*>(value.c_str()), (DWORD)value.length() + 1) == ERROR_SUCCESS;
    }

    } // anonymous namespace 

registry_setting_storage::registry_setting_storage( const std::string & root)
    : m_root( root)
{
#ifndef NDEBUG
    // debug mode - see that root is a valid string
    keys_array keys;
    open_reg_key( root, keys, KEY_QUERY_VALUE);
    // root is not a valid string!
    assert( !keys.empty() );
    close_reg_key( keys);
#endif
}

registry_setting_storage::~registry_setting_storage()
{

}

void registry_setting_storage::save(const err::handler & ) {
    // nothing to save. - everything is saved when it's set
}

void registry_setting_storage::get_setting( const std::string & name, std::string & value, std::string & error) const {
    error.erase();
    keys_array keys;
    open_reg_key( m_root, keys, KEY_QUERY_VALUE);
    std::string name_key, name_val;
    split_name( name, name_key, name_val);
    open_reg_key( name_key, keys, KEY_QUERY_VALUE);
    bool is_ok = !keys.empty();
    if ( is_ok)
        is_ok = get_reg_value( name_val, keys.back(), value);

    if ( !is_ok)
        error = "(get) could not open registry key " + m_root + "/" + name;
    close_reg_key( keys);
}

void registry_setting_storage::set_setting( const std::string & name, const std::string & value, std::string & error) {
    error.erase();
    keys_array keys;
    open_reg_key( m_root, keys, KEY_SET_VALUE);
    std::string name_key, name_val;
    split_name( name, name_key, name_val);
    open_reg_key( name_key, keys, KEY_SET_VALUE);
    bool is_ok = !keys.empty() ;
    if ( is_ok)
        is_ok = set_reg_value( name_val, keys.back(), value);

    if ( !is_ok)
        error = "(set) could not open registry key " + m_root + "/" + name;
    close_reg_key( keys);
}

namespace {

    void enum_settings_impl( HKEY key, REGSAM access, const std::string & subkey_name, std::map<std::string,std::string> & values, std::string & error) {
        std::string buff;
        buff.resize( 512);
        DWORD len = 0;
        FILETIME ignore;
        int idx = 0; 
        // go though children
        while ( true) {
            len = 512;
            LONG res = RegEnumKeyEx( key, idx, &*buff.begin(), &len, 0, 0, 0, &ignore);
            bool ok = ( res == ERROR_SUCCESS || res == ERROR_MORE_DATA || res == ERROR_NO_MORE_ITEMS);
            if ( !ok)
                error += "Could not get registry key for " + subkey_name + "\n";
            bool do_continue = ok && (res != ERROR_NO_MORE_ITEMS);
            if ( !do_continue) break;

            const std::string curr_key_name( buff.begin(), buff.begin() + len);
            HKEY child;
            ok = RegOpenKeyEx( key, curr_key_name.c_str(), 0, access, &child) == ERROR_SUCCESS;
            if ( ok) {
                const std::string new_name = !subkey_name.empty() ? (subkey_name + "." + curr_key_name) : curr_key_name;
                enum_settings_impl( child, access, new_name, values, error);
                RegCloseKey( child);
            }
            else
                error += "Could not get registry key for " + subkey_name + "\n";
            ++idx;
        }

        // now, enumerate values
        idx = 0;
        while ( true) {
            len = 512;
            LONG res = RegEnumValue( key, idx, &*buff.begin(), &len, 0, 0, 0, 0);
            bool ok = ( res == ERROR_SUCCESS || res == ERROR_MORE_DATA || res == ERROR_NO_MORE_ITEMS);
            if ( !ok)
                error += "Could not get registry value for " + subkey_name + "\n";
            bool do_continue = ok && (res != ERROR_NO_MORE_ITEMS);
            if ( !do_continue) break;

            std::string curr_name( buff.begin(), buff.begin() + len);
            std::string curr_val;
            if ( get_reg_value( curr_name, key, curr_val) ) {
                if ( curr_name.empty() ) 
                    curr_name = "(default)"; // the registry "(Default)" value.
                std::string name_val = !subkey_name.empty() ? (subkey_name + "." + curr_name) : curr_name;
                values[ name_val] = curr_val;
            }
            else
                error += "Could not get registry value for " + subkey_name + "." + curr_val + "\n";
            ++idx;
        }        
    }

}


void registry_setting_storage::enum_settings( std::map<std::string,std::string> & values, std::string & error) const {
    error.erase();

    keys_array keys;
    REGSAM access = KEY_QUERY_VALUE | KEY_ENUMERATE_SUB_KEYS;
    open_reg_key( m_root, keys, access);
    if ( !keys.empty() )
        enum_settings_impl( keys.back(), access, "", values, error);
    close_reg_key( keys);
}



} // namespace persist
