

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

// sample_start.cpp : Defines the entry point for the application.
//

#include "stdafx.h"

#include <win32gui/event_handler.hpp>
#include <boost/log/log_impl.hpp>
#include <boost/log/functions.hpp>
#include "main/app.h"

BOOST_DEFINE_LOG(app, "app")
BOOST_DEFINE_LOG(err, "app.err")
BOOST_DEFINE_LOG(dbg, "app.dbg")
BOOST_DEFINE_LOG(gui, "app.dbg.gui")

using namespace win32::gui;

void init_logs() {
    using namespace boost::logging;
    manipulate_logs("*")
        .add_modifier( prepend_time("$hh:$mm:$ss "), INT_MAX )
        .add_modifier( &append_enter)
        .add_modifier( &prepend_prefix);

    add_appender("app*", write_to_file( (fs::current_path() / "app.log").string() ) );
    add_appender("app.log", write_to_dbg_wnd);
    add_appender("app.err", write_to_dbg_wnd);
    flush_log_cache();
}


// saves the frame position - as it's resized
struct save_frame_pos : subclass::auto_event_handler<save_frame_pos, view_frame> {
    
    void on_full_create() {
        load();
    }

    handle_event on_size() {
        save();
        return event_ex<wm::size>().HANDLED_BY(&me::on_size);
    }
    handle_event on_move() {
        save();
        return event_ex<wm::move>().HANDLED_BY(&me::on_move);
    }

    void save() {
        using namespace persist;
        rectangle r = self->window_rect(rel_to_parent);
        setting<int>("app.top_wnd.left") = r.left;
        setting<int>("app.top_wnd.top") = r.top;
        setting<int>("app.top_wnd.width") = r.width();
        setting<int>("app.top_wnd.height") = r.height();
    }

    void load() {
        using namespace persist;
        int left = setting<int>("app.top_wnd.left") ;
        int top = setting<int>("app.top_wnd.top") ;
        int width = setting<int>("app.top_wnd.width") ;
        int height = setting<int>("app.top_wnd.height") ;
        if ( width < 100 || height < 100) 
            return; // size too small, ignore
        rectangle r(left, top, left + width, top + height);
        self->move(r);
    }
};

