

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "setting/name.h"
#include "setting/tree_path_name.h"

struct configuration;
bool operator==(const configuration & f, const configuration & s);


/** 
    @brief Represents a configuration. When you retrieve,set some settings
           you always set/get them relative to a certain configuration

    By default, each directory/file has two configs:
    - Debug
    - Release

*/
struct configuration {
    configuration(const std::string & path);
    ~configuration(void);

    tree_path_name path() const;
    std::string friendly_name() const;

    static configuration root();
private:
    friend bool operator==(const configuration & f, const configuration & s);

    tree_path_name m_path;
    std::string m_friendly_name;
};

bool operator==(const configuration & f, const std::string & name);
bool operator==(const std::string & name, const configuration & f);
bool operator==(const configuration & f, const configuration & s);

inline bool operator!=(const configuration & f, const std::string & s)      { return !(f == s); }
inline bool operator!=(const std::string & f, const configuration & s)      { return !(f == s); }
inline bool operator!=(const configuration & f, const configuration & s)    { return !(f == s); }


// FIXME in the future, implement it more generically
configuration debug_config();
configuration release_config();
