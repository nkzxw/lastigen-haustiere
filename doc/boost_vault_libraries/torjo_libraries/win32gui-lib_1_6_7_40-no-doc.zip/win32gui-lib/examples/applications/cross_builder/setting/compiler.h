

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "setting/compiler_metadata.h"
#include "setting/tree_path_name.h"

struct compiler ;
typedef shared_ptr<compiler> compiler_ptr;


struct compiler {
    compiler(metadata_ptr metadata, const std::string & path, fs::path physical_path);
    ~compiler(void);

    std::string friendly_name() const   { return m_friendly_name; }
    tree_path_name path() const            { return m_compiler_path; }

    metadata_ptr metadata() const { return m_metadata; }
    bool is_intermediate() const;

private:
    // this compiler's metadata
    metadata_ptr m_metadata;

    // FIXME in the future, we'll allow renaming the compiler.
    //       However, we won't rename the directory itself (because there might be
    //       a lot of settings already modified for this specific compiler - they would
    //       get lost). Thus, we'll only change the friendly name.

    // the compiler's friendly name
    std::string m_friendly_name;

    // the physical path to this compiler
    fs::path m_physical_path;

    // the compiler's path - that uniquely identifies this compiler
    tree_path_name m_compiler_path;
};

