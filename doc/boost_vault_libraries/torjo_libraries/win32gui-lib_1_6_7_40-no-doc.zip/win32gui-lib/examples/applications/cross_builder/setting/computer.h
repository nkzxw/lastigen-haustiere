

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "setting/compiler.h"
#include "setting/compiler_metadata.h"
#include "setting/settings_holder.h"


/** 
    @brief Represents a setting that exists for multiple compilers

    It knows what compilers it's for
*/
struct setting_for_compilers {
    setting_for_compilers(const setting & sett) : sett(sett) {}

    /** the setting */
    setting sett;

    /**
    represents the upper-most compilers this setting applies to
    
    They are to be shown as a separate column on the settings list control,
    so that the user knows what compilers this setting applies to

    They are "upper-most" compiler names. That is, if a setting applies to a compiler,
    it automatically applies to all its sub-compilers. We'll show only the "upper-most" compiler name.

    There are two reasons for this:
    - first, we won't clutter the user's view. If a setting applies to gcc, he automatically knows 
      it applies to gcc 3.3, gcc 3.4, etc (since they're sub-compilers of gcc).
    - second, this is very flexible as well. You modify a setting for a compiler, and it's applied automatically
      to its sub-compilers. Even more, if you manually create another sub-compiler, it'll apply to that
      sub-compiler as well.

    If a setting applies to all compilers, it'll be shown as "All"
    */
    // note: these are compiler paths
    typedef std::set<std::string> compilers_set;
    compilers_set compilers;
    
};
typedef std::vector<setting_for_compilers> setting_for_compiler_array;

bool operator<(const setting_for_compilers & first, const setting_for_compilers & second);
bool operator==(const setting_for_compilers & first, const setting_for_compilers & second);
inline bool operator!=(const setting_for_compilers & first, const setting_for_compilers & second) {
    return !(first == second);
}



/** 
    @brief Conceptually represents the user's computer

    In other words, you can think of this as the root:
    the object that you use to get references to all other objects, 
    such as settings, compilers, etc.
*/
struct computer {
    computer(void);
    ~computer(void);

    setting_for_compiler_array get_settings_at_dir(std::string compiler_name, std::string metadata_dir_name) const;

    tree::item<compiler_ptr> get_compiler_tree() const;

    tree::item<> get_compiler_setting_dir_tree(const std::string & compiler_path) const;

    compiler_ptr get_compiler(const std::string & compiler_path) const;
    compiler_ptr get_upper_most_compiler_for_metadata(const std::string & metadata_path) const;

    // allow returning the available compilers, for a certain setting_key
    logical_path_setting_values_ptr setting_values(const logical_path & path);
    void save_all_setting_values();

private:
    void load_compiler_metadata();
    void load_compilers();

private:

    // the meta-data for each compiler
    tree::item<metadata_ptr> m_metadata;

    // all compilers
    tree::item<compiler_ptr> m_compilers;

    settings_holder m_sett;
};

computer & user_comp();
