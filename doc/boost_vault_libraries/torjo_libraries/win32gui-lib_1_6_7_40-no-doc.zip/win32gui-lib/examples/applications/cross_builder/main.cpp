

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

// sample_start.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "ui/main_dlg.h"

#include "persist_sl/registry_setting_storage.h"
#include "persist_sl/file_setting_storage.h"
using namespace persist;

#include "main/app.h"
#include "util/version.h"

#include "resource.h"

#include "win32gui_res/icons.hpp"
#include "win32gui_res/menus.hpp"
using namespace win32::gui::res_id;

void persist::on_initialize_default_config(configuration & cfg) {
    fs::path::default_name_check( fs::native);
#ifdef NDEBUG
    cfg.add_storage( "", new registry_setting_storage("CU/Software/WIN32GUI/Cross Builder"));
#else
    // debugging...
    cfg.add_storage( "", new file_setting_storage( (fs::current_path() / "cb.ini").string() ));
    cfg.add_storage( "build.path", new file_setting_storage( (fs::current_path() / "builds.ini").string() ));
    cfg.add_storage( "build.statistics", 
        new file_setting_storage( (fs::current_path() / "build_statistics.ini").string(), open_writable, load_at_start, save_on_request ));
#endif
}

std::string version_str() {
    version::info ver;
    version::get_file_info( ver);
    return str_stream() << ver.major_ver << "." << ver.minor_ver << "." << ver.build_no;
}

std::string title() {
#ifdef NDEBUG
    return "Cross Builder v" + version_str();
#else
    return "[DEBUG] Cross Builder v" + version_str();
#endif
}


int APIENTRY WinMain(HINSTANCE , HINSTANCE ,LPTSTR, int) {
    std::string home_dir = persist::setting<std::string>("app.home");
    if ( home_dir == std::string() )
        persist::setting<std::string>("app.home") = fs::current_path().string();

    //fs::path::default_name_check( fs::native);
    init_logs();

    using namespace win32::gui;

    // here, we set the frame's icon - you can set other WNDCLASSEX data as well...
    sdi_frame::set_class_info( sdi_frame::get_class_info().icon(icon_::small_) );
    wnd<> top = create_wnd<sdi_frame>( title(), null_wnd, 
        create_info().rect(100,100,700,500).menu(menu_::main_menu) );

    // rebar
    wnd<rebar> rb = create_wnd<rebar>(top);
    wnd<toolbar> tool = create_wnd<toolbar>(IDR_tools, top);
    rb->add_band( rebar_band_info().band_min_sizes( 200, 26).child(tool) );

    wnd<dialog> dlg = create_dlg<main_dlg>(top);
    create_wnd<status_bar>(top);
    top->wait();
    // ... just in case we were closed from the "Exit" command...
//    top->destroy();
}
