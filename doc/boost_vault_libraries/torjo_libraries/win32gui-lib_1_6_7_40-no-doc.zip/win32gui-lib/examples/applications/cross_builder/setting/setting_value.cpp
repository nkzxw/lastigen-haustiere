

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\setting_value.h"

setting_value::setting_value(void) : m_is_mixed(false)
{
}

setting_value::setting_value(const name_pair & value) : m_is_mixed(false), m_value(value) {
}

setting_value::~setting_value(void)
{
}

bool operator==( const setting_value & first, const setting_value & second) {
    return first.m_value == second.m_value && first.m_is_mixed == second.m_is_mixed;
}


/** 
    Merges this value with another value.

    If they're the same, it returns the first value.
    Otherwise, it returns a mixed value.
*/
setting_value setting_value::merge_with(const setting_value & other) const {
    if ( *this == other) 
        return *this;
    else
        return setting_value( mixed() );
}

/** 
    helper - merges two fixed values
*/
fixed_setting_value fixed_setting_value::merge_with(const fixed_setting_value & other) const {
    fixed_setting_value result = *this;
    result.current = result.current.merge_with( other.current);
    result.inherited = result.inherited.merge_with( other.inherited);

    if ( is_overridden != other.is_overridden) {
        // we have a mix (some value is overridden, while the other is not)
        result.is_overridden = false;
        result.current = result.inherited = setting_value::mixed();
    }
    return result;
}

std::ostream& operator<<(std::ostream& out, const setting_value & val) {
    if ( val.m_is_mixed)
        return out << "mixed-value";
    else
        return out << val.m_value;
}

std::ostream& operator<<(std::ostream& out, const fixed_setting_value & val) {
    return out << val.current << " (inherited: " << val.inherited << ")";
}


bool operator==( const fixed_setting_value & first, const fixed_setting_value & second) {
    return first.current == second.current && 
        first.inherited == second.inherited && 
        first.is_overridden == second.is_overridden;
}
