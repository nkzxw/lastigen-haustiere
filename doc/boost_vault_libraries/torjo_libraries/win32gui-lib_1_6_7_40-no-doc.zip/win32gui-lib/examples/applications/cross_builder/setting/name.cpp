

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\name.h"
#include "util/string_util.h"
#include "util/rw_string_io.h"

using namespace boost::rangelib;

bool operator==(const name_pair & f, const name_pair & s) {
//    return f.normalized == s.normalized;
    if ( f.is_string_value() && s.is_string_value())
        return f.user_friendly == s.user_friendly;
    else
        return f.normalized == s.normalized;
}
bool operator==(const name_pair & f, const std::string & s) {
//    return f.normalized == normalized_name(s);
    if ( f.is_string_value())
        return f.user_friendly == s;
    else
        return f.normalized == normalized_name(s);
}
bool operator==(const std::string & s, const name_pair & f) {
//    return f.normalized == normalized_name(s);
    if ( f.is_string_value())
        return f.user_friendly == s;
    else
        return f.normalized == normalized_name(s);
}

bool name_pair::is_string_value() const {
    return normalized_name(user_friendly) == normalized;
}


std::ostream& operator<<(std::ostream& out, const name_pair & val) {
    if ( normalized_name(val.user_friendly) != val.normalized) {
        std::string name = val.normalized + "/" + val.user_friendly;
        return out << io::write_str(name);
    }
    else {
        // in case the normalized name simply matches the user-friendly name, 
        // we'll write only the user-friendly name
        //
        // This is also very useful for strings (entered by the user), 
        // which might contain the '/' character, messing up everything

        // mark it as string, so we'll correctly read it back...
        std::string str = '{' + val.user_friendly + '}';
        return out << io::write_str(str);
    }
}

std::istream& operator>>(std::istream& in, name_pair & val) {
    std::string name;
    in >> io::read_str(name);

    if ( !name.empty()) {
        // check if it's a string
        bool is_string = ( name[0] == '{' && name.end()[-1] == '}');
        if ( is_string) {
            name = name.substr(1, name.size() - 2);
            val = name_pair(name, name);
            return in;
        }
    }

    val = split_into_name_and_userfriendly_name(name);
    return in;
}



bool operator<(const name_pair & f, const name_pair & s) {
    return f.normalized < s.normalized;
}



namespace {
    bool is_not_ok(char ch) {
        if ( isalpha(ch) ) return false;
        if ( isdigit(ch) ) return false;
        if ( ch == ' ') return false;
        if ( ch == '-' || ch == '_') return false;
        return true;
    }

    // returns true if a name
    bool is_name_valid(const std::string & name) {
        // names can only contain alpha-chars , -,+,_ and digits
        return !(rng::find_if(name, is_not_ok));
    }
}

// returns true if a setting name is valid 
bool is_setting_name_valid(const std::string & name) {
    return is_name_valid(name);
}


// returns true if a compiler-metadata directory name is valid 
bool is_compiler_meta_dir_name_valid(const std::string & name) {
    return is_name_valid(name);
}



/** 
    Normalizes a path name 
    (multiple logical names can mean the same physical name).

    This function converts a logical name into a physical name.
*/
std::string normalized_path_name(std::string name) {
    str_replace(name, "\\", "/");
    return name;
}

/** 
    Normalizes a name, other than a path name. See notes/4
    (multiple logical names can mean the same physical name).

    This function converts a logical name into a physical name.
*/
std::string normalized_name(std::string name) {
    name = locase(name);
    str_trim(name);
    str_replace( name, " " , "");
    str_replace( name, "-" , "");
    str_replace( name, "_" , "");
    return name;
}


/** 
    Splits the name into a name and a user-friendly name (the name to be shown to the user)

    Note that the names are not normalized (see normalize_enum_name/normalize_setting_name above)
*/
name_pair split_into_name_and_userfriendly_name(const std::string & name) {
    name_pair result;
    std::string::size_type idx = name.find("/");
    if ( idx != std::string::npos) {
        result.normalized = name.substr(0,idx);
        result.user_friendly = name.substr(idx + 1);
    }
    else
        result.normalized = result.user_friendly = name;
    result.normalized = normalized_name(result.normalized);
    return result;
}


/** 
    Constructs a name pair from a single string, entered by the user
*/
name_pair name_from_user_entered_string(const std::string & name) {
    // we're case-insensitive, for comparisons...
    return name_pair( locase(name), name);

}

