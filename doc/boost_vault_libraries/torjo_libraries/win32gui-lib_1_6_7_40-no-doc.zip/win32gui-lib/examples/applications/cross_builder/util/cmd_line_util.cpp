#include "stdafx.h"

// Utility Library
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

#include ".\cmd_line_util.h"

#include <windows.h>

#include <boost/rangelib/range.hpp>
#include <boost/rangelib/algo.hpp>
#include <boost/rangelib/slice_byrange.hpp>
using namespace boost::rangelib;


namespace {
    struct slice_cmd_line_args {
        slice_cmd_line_args() : m_in_quote(false) {}
        bool operator()( char first, char second) {
            if ( first == ' ' && second == ' ') return true; // take all up to last space
            if ( first == '"') {
                m_in_quote = !m_in_quote;
                return m_in_quote;
            }
            if ( m_in_quote) return true; // within quoted string
            // if space, this argument ended
            return second != ' ';
        }
    private:
        bool m_in_quote;
    };

    struct parse_arg {
        typedef std::string first_argument_type;
        template< class iterator>
        void operator()( std::string & out, iterator begin, iterator end) {
            // remove spaces
            while ( begin < end)
                if ( isspace(*begin) ) ++begin;
                else break;
            while ( begin < end) {
                if ( isspace(end[-1]) ) -- end;
                else break;
            }
            if ( begin < end) {
                if ( *begin == '"') 
                    ++begin, --end; // quoted string
            }
            if ( !(begin < end)) {
                // empty argument (most likely, this is an ending space)
                end = begin;
            }

            out.assign( begin, end);
        }
    };
    
}


cmd_line::cmd_line() {
    std::string cmd = ::GetCommandLine();    
    rng::copy( sliced_byrange(cmd, parse_arg(), slice_cmd_line_args()), std::back_inserter(m_args) );
    if ( !m_args.empty())
        if ( m_args.back().empty() )
            m_args.erase( m_args.end() - 1); // remove last empty element
}

cmd_line::~cmd_line() {
}

