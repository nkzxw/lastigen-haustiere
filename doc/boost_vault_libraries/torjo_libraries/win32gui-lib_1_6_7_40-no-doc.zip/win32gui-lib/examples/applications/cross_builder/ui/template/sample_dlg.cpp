#include "stdafx.h"
// sample_dlg.cpp
#include "sample_dlg.h"
#include <win32gui/event_handler.hpp>

#include "win32gui_res/sample.hpp"

using namespace win32::gui;


struct sample_dlg_handler : event_handler<sample_dlg_handler, sample_dlg> {
};


sample_dlg::sample_dlg() {
}

sample_dlg::~sample_dlg() {
}

int sample_dlg::dialog_id() { return dialog_id_; }

