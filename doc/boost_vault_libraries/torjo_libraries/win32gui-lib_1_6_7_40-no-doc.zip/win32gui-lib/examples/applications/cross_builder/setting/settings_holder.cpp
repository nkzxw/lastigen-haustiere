

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\settings_holder.h"
#include "main/app.h"
using namespace boost::rangelib;

namespace {
    // maximum Settings Values objects that can be held in memory.
    // If this is reached, we do a sort of garbage-collection: we remove them all, and they'll
    // be reloaded as needed
    const int MAX_SV_OBJECTS = 512;
}

settings_holder::settings_holder(void)
{
}

settings_holder::~settings_holder(void)
{
}


// returns the available settings for a given path
config_array settings_holder::get_configurations(fs::path p) {
    // FIXME in the future, allow configuring...

    // FIXME explain that configuration are directory-dependent (you can, of course, make them 
    // apply to all disk - by setting them in the Local Disk).
    config_array a;
    a.push_back( debug_config() );
    a.push_back( release_config() );
    return a;
}


logical_path_setting_values_ptr settings_holder::setting_values(const logical_path & path) {
    typedef logical_path::path_array array;
    scoped_lock lock(m_cs);
    if ( m_settings.size() > MAX_SV_OBJECTS) {
        BOOST_LOG(app) << "removing all setting-values objects";
        m_settings.clear();
    }

    // load all physical paths in memory
    logical_path_setting_values_ptr parent;
    for ( crange<const array> r(path.get_physical_paths()); r; ++r) {
        if ( crange<setting_values_coll> r_sv = rng::coll_find(m_settings, *r))
            parent = r_sv->second; // this path is already in memory
        else {
            logical_path_setting_values_ptr child(new logical_path_setting_values(*r, parent));
            m_settings[ *r ] = child;
            parent = child;
        }
    }

    return parent;
}

void settings_holder::save_all() {
    for ( crange<setting_values_coll> r(m_settings); r; ++r) r->second->save();
}
