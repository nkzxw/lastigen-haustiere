// Persist Settings Library
//
// Copyright 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

// ts.h: interface for the ts class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TS_H__39F77F9D_1038_4B02_A322_A023489219E4__INCLUDED_)
#define AFX_TS_H__39F77F9D_1038_4B02_A322_A023489219E4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// thread-safe issues.
namespace persist { namespace detail {

#ifdef PERSIST_THREAD_SAFE

// FIXME on Win32, use simpler technique
#include <boost/thread/recursive_mutex.hpp>
typedef boost::recursive_mutex critical_section;
typedef boost::recursive_mutex::scoped_lock scoped_lock;

#else

struct critical_section {
};

class scoped_lock {
    scoped_lock( const scoped_lock&);
    void operator=( const scoped_lock&);
public:
    scoped_lock( const critical_section &) {}
    ~scoped_lock() {}
};

#endif

}}

#endif // !defined(AFX_TS_H__39F77F9D_1038_4B02_A322_A023489219E4__INCLUDED_)
