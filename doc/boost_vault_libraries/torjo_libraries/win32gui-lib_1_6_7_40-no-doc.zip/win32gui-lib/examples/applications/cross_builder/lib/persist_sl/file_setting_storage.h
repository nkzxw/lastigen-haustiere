// Persist Settings Library
//
// Copyright 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

// file_setting_storage.h: interface for the file_setting_storage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILE_SETTING_STORAGE_H__650EF45C_D587_49E6_9511_74FBCC70A1D7__INCLUDED_)
#define AFX_FILE_SETTING_STORAGE_H__650EF45C_D587_49E6_9511_74FBCC70A1D7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning (disable :4786) // msvc

#include "setting_storage.h"
#include <vector>
#include <map>
#include <string>

namespace persist {


typedef enum file_storage_open_type {
	// opens the file as writable
    open_writable,
    // treats the file as read-only - does not write to it
    open_read_only,
	// forces the file to be writable, even if originally it was read-only (only for WIN32):
	// if the file is read-only, it clears this flag, writes to the file, and then sets the read-only flag back
    open_force_writable,
};

typedef enum file_storage_load_type {
    // loads the settings once, at construction
    load_at_start,
    // reloads the file for each "get_setting" request
    reload_each_get,
};

typedef enum file_storage_save_type {
    // saves settings only when requested to (when you save() the configuration = a call to configuration::save)
    save_on_request,
    // saves each time a modification takes place
    save_each_modify,
};


/*
    Persists settings to a file    
*/
class file_setting_storage : public setting_storage
{
public:
	void save(const err::handler & h );
	file_setting_storage( const std::string & file_name, file_storage_open_type open_type = open_writable, file_storage_load_type load_type = load_at_start, file_storage_save_type save_type = save_each_modify);
	virtual ~file_setting_storage();

    void get_setting( const std::string & name, std::string & value, std::string & error) const;
    void set_setting( const std::string & name, const std::string & value, std::string & error);
    void enum_settings( std::map<std::string,std::string> & values, std::string & error) const;

private:
	void load() const;

    file_storage_save_type m_save_type;
    file_storage_load_type m_load_type;

    // the file name
    std::string m_file_name;

    // set to true when we've modified something but not saved yet
    bool m_needs_save;

    // how are we treating the file?
    file_storage_open_type m_open_type;

    typedef std::map< std::string, int> coll;
    mutable coll m_name_to_line;
    // information about ONE setting
    struct info {
        std::string name;
        std::string value;
        std::string comment;
    };
    typedef std::vector<info> infos_array;
    mutable infos_array m_infos;
};

} // namespace persist

#endif // !defined(AFX_FILE_SETTING_STORAGE_H__650EF45C_D587_49E6_9511_74FBCC70A1D7__INCLUDED_)
