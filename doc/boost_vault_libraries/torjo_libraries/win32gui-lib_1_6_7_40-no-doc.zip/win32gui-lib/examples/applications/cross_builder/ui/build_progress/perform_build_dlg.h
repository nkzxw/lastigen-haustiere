

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "build/logical_path.h"
#include "setting/configuration.h"
#include "setting/compiler.h"

struct perform_build_dlg_handler ;

namespace build_statistics {
    struct write_for_dir ;
    struct read_for_dir ;
    struct path_info;
}


/** 
    @brief Performs building of a directory, and shows it visually


*/
struct perform_build_dlg : wnd_extend<dialog, perform_build_dlg>, wnd_extend<resizable_wnd, perform_build_dlg> {
    perform_build_dlg() ;
    ~perform_build_dlg(void);

    static int dialog_id();

    void add_build_path(const logical_path &path, configuration config, std::string compiler);
    void start();

    void clean_first(bool val);
    void compile_only(bool val);
    void do_pin(bool val);

    int sucess_builds_count() const;
    int failed_builds_count() const;

private:
    void add_detail_msg(std::string msg);
    void add_summary_msg(std::string msg);
    void add_output_results_msg(fs::path file, fs::path output_results);

    void add_success(const logical_path & project_path, fs::path out_path, compiler_ptr comp, configuration config);
    void add_failure(const logical_path & project_path, compiler_ptr comp, configuration config);

    bool is_cancelled() const;

private:
    friend struct perform_build_dlg_handler ;
    // enough information to do one build;
    // we might perform multiple builds at once...
    struct build_info {
        build_info(const logical_path & path = fs::path(), configuration config = configuration::root(), std::string compiler = "") 
            : path(path),config(config),compiler(compiler) {}
        logical_path path;
        configuration config;
        std::string compiler;
    };
    typedef std::vector<build_info> build_array;

    mutable critical_section m_cs;
    build_array m_builds;

    // pointer to ourself - needed by the runner thread
    win32::gui::wnd<perform_build_dlg> m_build_wnd;

    // if true, it's started to do its work...
    bool m_started;

    int m_successful_builds;
    int m_failed_builds;

    // if this is set to true, we should cancel building...
    bool m_do_cancel;

    // if true, when building, we clean the file first (Rebuilding)
    bool m_do_clean_first;

    // if true, it only compiles...
    bool m_do_compile_only;

    // if true, every build that is done now, is pinned for statistics
    //
    // if a build is pinned, further pins with the same compiler/config will 
    // be compared for statistics with this build (otherwise, it's automatically
    // compared with the last build for the same compiler/config)
    bool m_do_pin;

    // how many levels do we recurse, when searching for projects?
    int m_max_recurse_levels;

    // the current recursed level
    int m_cur_recurse_level;

    // as we're doing building, we gather statistics...
    typedef build_statistics::write_for_dir statistics_type;
    typedef shared_ptr<statistics_type> statistics_ptr;

    struct statistics_info {
        // as we're doing building, we gather statistics...
        statistics_ptr new_;
        // old build statistics - we use these when a file is already built.
        // If so, we'll use the old' statistics. We really need those statistics times ;)
        shared_ptr<build_statistics::read_for_dir> old;

        // pinned build statistics - we use these to compare to current build...
        // if null, there were no such statistics...
        shared_ptr<build_statistics::read_for_dir> pinned;

        // paths walked up to the current file to be compiled....
        // We keep this, so that only the paths where there are files, are shown in the "Build Times" window
        // (there could be quite a few directories that don't have *any* files - they would just clutter the output)
        typedef std::vector<logical_path> paths_array;
        paths_array paths_to_file;
    };
    statistics_info m_statistics;

private:
    void run();
    void start_recursing(const build_info & build);
    void recurse_build(const build_info & build, compiler_ptr comp);
    void build_project(const build_info & build, compiler_ptr comp);
    void add_file_statistics(const logical_path & file, const build_statistics::path_info & stats);
    void add_project_path_for_statistics(const logical_path & path);
    void add_non_project_path_for_statistics(const logical_path & path);
    void filter_out_empty_statistics_dirs(const logical_path & file);

    struct compiled_source_file {
        fs::path source;
        // if compiled is empty, the file has failed to compile
        fs::path compiled;
    };
    typedef std::vector<compiled_source_file> compiled_file_array;
    void recurse_compile(const build_info & build, compiler_ptr comp, fs::path project_root, fs::path build_root, compiled_file_array & files);
    compiled_source_file compile_file(const build_info & build, compiler_ptr comp, fs::path project_root, fs::path build_root);

    void link(const compiled_file_array & files, const logical_path & build_path, compiler_ptr comp, configuration config, fs::path build_root);


};
