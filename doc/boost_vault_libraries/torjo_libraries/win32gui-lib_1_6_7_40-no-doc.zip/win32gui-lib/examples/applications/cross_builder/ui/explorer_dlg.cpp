

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "stdafx.h"
// explorer_dlg.cpp
#include "explorer_dlg.h"
#include <win32gui/event_handler.hpp>

#include <direct.h>
#include "main/app.h"

#include "util/string_util.h"
#include "util/tree_ctrl_util.h"

#include "tree/tree.h"
#include "tree/algorithm.h"
#include "tree/fs.h"

#include "ui/settings_dlg.h"
#include "ui/enter_settings_dlg.h"
#include "ui/panes/right_pane_dlg.h"
#include "ui/configure_compiler_dlg.h"

#include "win32gui_res/explorer.hpp"
#include "win32gui_res/right_pane.hpp"

#include "win32gui_res/bitmaps.hpp"

#include "build/build.h"



using namespace win32::gui;
using namespace win32::gui::res_id;
using namespace boost::rangelib;

namespace {
    // images for nodes
    namespace node {
        enum type {
            compiler_root = 0,
            compiler = 1,
            disk = 2,
            dir = 3,
            redirected_dir = 4,
            // directory marked as root
            root_dir = 5,
            drive = 8,
            cpp_file = 9,
            c_file = 10,
            rc_file = 11,

            // directory is a project
            is_project = 12,

            // note: a hidden node means we should compute children nodes only 
            //       when this node is expanded.
            hidden = 13

        };
    }

    std::string path_from_compiler_item(wnd<tree_ctrl> t, HTREEITEM item) {
        std::string path;
        while (item) {
            HTREEITEM parent = t->parent_item(item);
            if ( !path.empty() ) path = "/" + path;

            if ( parent)
                path = t->item(item).text() + path;
            else
                path = "root" + path;
            item = parent;
        }
        return path;
    }

    bool case_insensitive_less(const std::string & first, const std::string & second) {
        return locase(first) < locase(second);
    }

    bool should_be_shown_to_the_user(const fs::path path) {
        if ( path == (std::string)persist::setting<std::string>("app.home") )
            // we don't allow expanding home. It could show our internals...
            return false;

        fs::path build_path = fs::path(path) / "crossbuilder-build-dir.txt";
        if ( fs::exists(build_path) )
            return false; // it's a build directory, don't expand!

        return true;
    }

    // returns path corresponding to this Disk item
    // (that is, this item is a child of the "Disk" - it is a path on the user's disk)
    std::string logical_path_from_item(HTREEITEM item, wnd<tree_ctrl> t) {
        std::string path;
        while ( item) {
            tv_item info = t->item(item);
            HTREEITEM parent = t->parent_item(item);
            if ( parent) 
                path = info.text() + "/" + path;
            else 
                ; // reached the top
            item = parent;
        }

        if ( path.empty() )
            path = logical_path::root().physical_path().string();
        return path;
    }

}

struct explorer_dlg_handler : event_handler<explorer_dlg_handler, explorer_dlg> {
    enum {
        FILL_ADDRESSES = WM_APP + 20,
        WM_REFRESH_CURRENT_PATH , 
        WM_SET_CONFIGURE_COMPILER
    };

    image_list<owned> m_dir_images;
    HTREEITEM m_compilers_root, m_disk_root; 

    explorer_dlg_handler() : m_dir_images( bitmap_::explorer_nodes, 16) {}

    void on_full_create() {
        // FIXME now, I can improve the naming of this.
        child<tab_dialog>(m_tabdialog1_::id)->add_item( tc_item().text("Explorer"), m_dirs );
        child<tab_dialog>(m_tabdialog1_::id)->add_item( tc_item().text("Compilers"), m_compilers );

        m_dirs->images( tree_ctrl_::images::normal, m_dir_images);
        m_compilers->images( tree_ctrl_::images::normal, m_dir_images);

        build_root_dirs();
        m_addresses->add_col( lv_col().text("Favorites").width(300) );
        fill_addresses();
        post_msg(WM_SET_CONFIGURE_COMPILER);
    }

    handle_event on_expand(m_dirs_::ev::item_expanding::arg a) {
        if ( a.expand_type == tree_ctrl_::expand::expand_)
            do_expand( a.item);
        else if ( a.expand_type == tree_ctrl_::expand::collapse)
            do_collapse( a.item);
        return event_ex<m_dirs_::ev::item_expanding>().HANDLED_BY(&me::on_expand);
    }

    handle_event on_fill_addresses() {
        fill_addresses();
        return event<FILL_ADDRESSES>().HANDLED_BY(&me::on_fill_addresses);
    }

    handle_event on_dirs_change() {
        // (note: at program startup, this might not be created yet...)
        post_msg(WM_REFRESH_CURRENT_PATH);
        return event_ex<m_dirs_::ev::sel_change>().HANDLED_BY(&me::on_dirs_change);
    }

    handle_event on_select_address(m_addresses_::ev::item_changed::arg a) {
        std::string addr = m_addresses->item(a.item).text();
        expand_to_path(addr);
        return event_ex<m_addresses_::ev::item_changed>().HANDLED_BY(&me::on_select_address);
    }

    handle_event on_refresh_path() {
        HTREEITEM sel = m_dirs->sel();
        if ( !sel) return event_handled_early;
        // update the settings for this path...

        std::string path = logical_path_from_item(sel, m_dirs );
        // update status bar as well...
        std::string friendly_path = path;
        if ( m_dirs->item(sel).image() == node::disk) friendly_path = "Local Disc";
        find_wnd<status_bar>()->text( friendly_path);

        find_wnd<settings_dlg>()->sub_wnd<enter_settings_dlg>()->path( fs::path(path) );
        return event<WM_REFRESH_CURRENT_PATH>().HANDLED_BY(&me::on_refresh_path);
    }

    handle_event on_rclick() {
        HTREEITEM at_cursor = m_dirs->hit_test( cursor_pos(m_dirs) ).first;
        if ( !at_cursor) return event_handled_early;
        m_dirs->sel(at_cursor);

        menu<owned> m( menu_::rclick);
        m.sub_menu(1).run_popup( cursor_pos(), window() );
        return event_ex<m_dirs_::ev::right_clicked>().HANDLED_BY(&me::on_rclick);
    }

    handle_event on_tab_change() {
        int sel_tab = child<m_tabdialog1_>()->sel();
        int right_sel_tab = 0;
        if ( sel_tab == 0)          right_sel_tab = 0;
        else if ( sel_tab == 1)     right_sel_tab = 1;
        else assert(false); // only two panes on the left

        find_wnd<right_pane_dlg>()->child<tab_dialog>(right_pane_::m_tabdialog1_::id)->sel( right_sel_tab);
        return event_ex<m_tabdialog1_::ev::sel_change>().HANDLED_BY(&me::on_tab_change);
    }
    
    handle_event on_do_select_last_configured_compiler() {
        select_last_configured_compiler();
        return event<WM_SET_CONFIGURE_COMPILER>().HANDLED_BY(&me::on_do_select_last_configured_compiler);
    }

    handle_event on_compiler_change() {
        HTREEITEM sel = m_compilers->sel();
        bool is_root =  ( m_compilers->parent_item(sel) == 0);
        if (is_root) sel = m_compilers->first_child(sel); // ignore root.

        select_configure_compiler( path_from_compiler_item( m_compilers, sel ));
        return event_ex<m_compilers_::ev::sel_change>().HANDLED_BY(&me::on_compiler_change);
    }

private:

    // selects last known configured compiler 
    void select_last_configured_compiler() {
        std::string compiler_path = persist::setting<std::string>("app.last_configured_compiler");
        if ( compiler_path.empty() ) compiler_path = "root/C++"; 

        select_configure_compiler( compiler_path);
    }


    void select_configure_compiler(std::string path) {
        assert ( path.find("root/") == 0); // every compiler path starts like this
        HTREEITEM cur_item = m_compilers->root() ;
        path = path.substr(5);

        fs::path p(path); // we don't care if it's not a real path - the delimiters count...
        for ( fs::path::iterator begin(p.begin()), end(p.end()); begin != end; ++begin) {
            HTREEITEM i = m_compilers->first_child(cur_item);
            for ( ; i ; i = m_compilers->next_sibling(i))
                if ( m_compilers->item(i).text() == *begin) {
                    cur_item = i;
                    break;
                }
            if ( !i)
                break; // not the full path was found...
        }

        m_compilers->sel(cur_item);
        std::string selected_path = path_from_compiler_item( m_compilers, cur_item );
        persist::setting<std::string>("app.last_configured_compiler") = selected_path;
        find_wnd<configure_compiler_dlg>()->compiler_path( selected_path );
    }

    // returns the top ascendant node
    HTREEITEM top_dir_item(HTREEITEM item) {
        HTREEITEM prev = item;
        while ( item) {
            prev = item;
            item = m_dirs->parent_item(item);
        }
        return prev;
    }

    // returns path corresponding to this Disk item
    // (that is, this item is a child of the "Disk" - it is a path on the user's disk)
    std::string path_from_disk_item(HTREEITEM parent) {
        return path_from_tree_item(m_dirs, parent).root_child().string();
        /*
        std::string path;
        for ( bool reached_top = false; !reached_top;) {
            tv_item info = m_dirs->item(parent);
            reached_top = info.image() == node::disk;
            if ( !reached_top)
                path = info.text() + "/" + path;
            parent = m_dirs->parent_item(parent);
            if ( !parent) {
                // should be a descendant from "Disk"
                assert(reached_top);
                reached_top = true;
            }
        }
        return path;
        */
    }


    void do_expand( HTREEITEM item) {
        HTREEITEM first_child = m_dirs->first_child(item);
        bool has_hidden_node = first_child && m_dirs->item(first_child).image() == node::hidden;
        if ( !has_hidden_node) return;

        // now, we know it has a hidden node
        m_dirs->del_item(first_child);
        std::string path = path_from_disk_item(item) + "/";

        if ( !should_be_shown_to_the_user(path) )
            // we don't allow expanding home. It could show our internals...
            return;

        typedef std::vector<std::string> array;
        array dirs, cpp_files, c_files, rc_files;
        for ( fs::directory_iterator begin(path), end; begin != end; ++begin)
            try {
                if ( is_directory(*begin) )
                    dirs.push_back( begin->leaf() );
                else if ( fs::extension(*begin) == ".cpp" || fs::extension(*begin) == ".cxx")
                    cpp_files.push_back( begin->leaf() );
                else if ( fs::extension(*begin) == ".c")
                    c_files.push_back( begin->leaf());
                else if ( fs::extension(*begin) == ".rc")
                    rc_files.push_back( begin->leaf());
            }
            catch (std::exception & exc) {
                // some files might be in use by the system (pagefile.sys, for instance) ... we'll ignore them
                BOOST_LOG(err) << "could not access file or dir " << path << " : " << exc.what();
            }

        // sort them all by name
        rng::sort(dirs, case_insensitive_less);
        rng::sort(c_files, case_insensitive_less);
        rng::sort(cpp_files, case_insensitive_less);
        rng::sort(rc_files, case_insensitive_less);

        // directories - add hidden node as well
        for ( crange<array> r(dirs); r; ++r) {
            HTREEITEM dir = m_dirs->add_item(item, tv_item().text(*r).image(node::dir) );
            m_dirs->add_item(dir, tv_item().text("hidden").image(node::hidden) );
        }

        for ( crange<array> r(cpp_files); r; ++r) 
            m_dirs->add_item(item, tv_item().text(*r).image(node::cpp_file) );
        for ( crange<array> r(c_files); r; ++r) 
            m_dirs->add_item(item, tv_item().text(*r).image(node::c_file) );
        for ( crange<array> r(rc_files); r; ++r) 
            m_dirs->add_item(item, tv_item().text(*r).image(node::rc_file) );

        check_for_project_dirs(item);
    }

    void do_collapse( HTREEITEM item) {
        HTREEITEM cur = item, parent = item;
        while ( parent) {
            cur = parent;
            parent = m_dirs->parent_item(parent);
        }
        if ( cur != m_disk_root)
            // it's not a Disk item - we can collapse/expand it any time
            return; 
        if ( item == m_disk_root) return; // don't care about collapsing "Disk"
        std::string path = path_from_disk_item(item);
        // should be a directory
        assert ( fs::is_directory(path) );
        while ( HTREEITEM first_child = m_dirs->first_child(item))
            m_dirs->del_item( first_child);
        // add hidden node
        m_dirs->add_item(item, tv_item().text("hidden").image(node::hidden) );
    }

    void check_for_project_dirs(HTREEITEM item) {
        for ( HTREEITEM child_item = m_dirs->first_child(item); child_item; child_item = m_dirs->next_sibling(child_item)) {
            std::string path = path_from_disk_item(child_item);
            compiler_ptr comp = user_comp().get_compiler("root/C++"); //FIXME
            configuration config = configuration::root(); 
            bool is_project = get_setting_value( "is_project", fs::path(path), comp, config) != "0";
            if ( is_project)
                m_dirs->item(child_item, tv_item().image(node::is_project) );
        }


    }


    void build_root_dirs() {
        m_compilers_root = m_compilers->add_root_item( tv_item().text("All").image(node::compiler_root) );
        tree::item<> compilers = tree::descendant_directory_tree( 
            (std::string)persist::setting<std::string>("app.home") + "/root/Compilers" );
        add_tree_descendants(
            m_compilers_root, compilers, node::compiler, node::compiler);
        // expand all compilers
        tree_ctrl_for_each( m_compilers, ::do_expand);

        m_disk_root = m_dirs->add_root_item( tv_item().text("Local Disc").image(node::disk) );
        add_drives();
    }
    
    // adds descendant nodes
    void add_tree_descendants(HTREEITEM ctrl_item, tree::item<> & dir_item, int child_img, int grand_child_img) {
        for ( crange<tree::item<>::array> r(dir_item.children); r; ++r) {
            HTREEITEM child_item = m_compilers->add_item(ctrl_item, tv_item().text(r->name()).image(child_img) );
            add_tree_descendants(child_item, *r, grand_child_img, grand_child_img);
        }
    }

    // adds the nodes, as children of the "Disk" node
    void add_drives() {
        // fills drives
        ULONG drives = _getdrives();
        char current = 'A';
        while (drives) {
            if ( drives & 1) {
                // this drive exists
                std::string drive;
                drive += current;
                drive += ":";
                HTREEITEM drive_item = m_dirs->add_item( m_disk_root, tv_item().text(drive).image(node::drive) );
                m_dirs->add_item(drive_item, tv_item().text("hidden").image(node::hidden) );
            }
            ++current;
            drives >>= 1;
        }
    }

    void refresh_dirs() {
        // FIXME (future)

        // takes a look at the visible directories
        // if any have been erased/added, updates the view

        // also, it updates the directory images, if needed
        // (for instance, maybe a directory has become root or something)
    }

    void fill_addresses() {
        m_addresses->del_all_items();

        using persist::setting;
        int count = setting<int>("app.last_addresses.count");
        if ( count == 0) {
            setting<int>("app.last_addresses.count") = count = 1;
            setting<std::string>("app.last_addresses.0") = setting<std::string>("app.home");
        }
        
        // put most recent one first
        for ( int idx = count ; idx > 0; --idx)
            m_addresses->add_item( 
                lv_item().text( setting<std::string>( str_stream() << "app.last_addresses." << (idx-1) ) ) );

        // go to last known path
        expand_to_path( setting<std::string>(str_stream() << "app.last_addresses." << (count-1)) );
    }

    // expands nodes up to this path, and select it
    void expand_to_path(const std::string & path) {
        fs::path p(path);
        fs::path::iterator begin(p.begin()), end(p.end());
        if ( begin == end) return; // invalid path
        HTREEITEM at = m_disk_root;

        while ( begin != end) {
            // first, expand
            m_dirs->expand(at);

            // now find current child
            std::string name = *begin;
            if ( name == "/" || name == "\\") {
                // ignore delimeters
                ++begin;
                continue;
            }

            HTREEITEM next = m_dirs->first_child(at);
            while ( next) {
                if ( m_dirs->item(next).text() == name)
                    break;
                next = m_dirs->next_sibling(next);
            }

            if ( next) {
                at = next;
                ++begin;
            }
            else 
                break; // path does not exist anymore
        }
        m_dirs->sel(at); // mark this as the selection
    }
};


explorer_dlg::explorer_dlg() {
    set_cmd_checker( menu_::dir_is_project, &explorer_dlg::get_is_project, &explorer_dlg::set_is_project, this);
}

explorer_dlg::~explorer_dlg() {
}

int explorer_dlg::dialog_id() { return dialog_id_; }


// returns a user-frienly path, not showing the application internals
std::string explorer_dlg::user_friendly_path() const {
    std::string path;
    HTREEITEM parent = m_dirs->sel();
    // we should have a selection
    assert(parent);
    for ( ; parent;) {
        HTREEITEM cur = parent;
        parent = m_dirs->parent_item(parent);
        tv_item info = m_dirs->item(cur);
        if ( !parent && info.image() == node::disk)
            break; // we've reached the top

        path = info.text() + "/" + path;        
    }
    return path;
}

// returns the absolute path to where the user is
// (for instance, if on a redirection, it'll show the redirection's path;
//  or if on a compiler, it'll show the path to that compiler's settings)
logical_path explorer_dlg::absolute_path() const {
    HTREEITEM sel = m_dirs->sel();
    std::string path ;
    if ( sel)
        path = logical_path_from_item(sel, m_dirs );
    else
        path = (std::string)persist::setting<std::string>("app.home");

    return fs::path(path);
}


// marks the current address as a "Used" address (one for which a command 
// - such as "Build" -, has been executed)
void explorer_dlg::mark_address_as_used() {
    // it adds it to "Last Addresses" list
    using persist::setting;
    std::string path = user_friendly_path();
    if ( path.empty() ) 
        return; // "Local Disk"

    int count = setting<int>("app.last_addresses.count");
    // if this address exists already, bring it to the front
    int exists_at = -1;
    for ( int idx = 0; idx < count; ++idx)
        if ( (std::string)setting<std::string>(str_stream() << "app.last_addresses." << idx) == path) {
            exists_at = idx;
            break;
        }
    if ( exists_at > -1) {
        // already exists, bring to front
        for ( int idx = exists_at; idx < count; ++idx) {
            std::string new_idx = str_stream() << "app.last_addresses." << idx;
            std::string old_idx = str_stream() << "app.last_addresses." << (idx+1);
            setting<std::string>(new_idx) = (std::string)setting<std::string>(old_idx);
        }
        setting<std::string>(str_stream() << "app.last_addresses." << (count-1)) = path;
    }
    else {
        // new entry
        setting<std::string>(str_stream() << "app.last_addresses." << count) = path;
        setting<int>("app.last_addresses.count") = count + 1;
    }
    send_msg(explorer_dlg_handler::FILL_ADDRESSES);
}


bool explorer_dlg::get_is_project() const {
    compiler_ptr comp = user_comp().get_compiler("root/C++"); //FIXME
    configuration config = configuration::root(); 
    return get_setting_value( "is_project", absolute_path(), comp, config) != "0";
}

void explorer_dlg::set_is_project(bool is) {
    compiler_ptr comp = user_comp().get_compiler("root/C++"); //FIXME
    configuration config = configuration::root(); 
    logical_path_setting_values_ptr sv = user_comp().setting_values( absolute_path() );
    setting_key key("is project", config, setting_key::mode::before, "root/C++");
    fixed_setting_value val;
    val.current = name_pair(is ? "1" : "0");
    sv->set_value( comp->metadata()->get_setting("is project"), key, val);
    if ( persist::setting<bool>("app.dbg.save_after_each_modify") )
        sv->save(); // simpler to debug

    HTREEITEM sel = m_dirs->sel();
    m_dirs->item(sel, tv_item().image(is ? node::is_project : node::dir) );
}



