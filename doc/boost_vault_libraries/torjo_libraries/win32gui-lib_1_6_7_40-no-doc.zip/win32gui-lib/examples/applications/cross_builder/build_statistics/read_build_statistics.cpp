

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\read_build_statistics.h"
#include <time.h>
#include "util/file_util.h"
#include <stdexcept>

namespace build_statistics {

using namespace boost::rangelib;

read_for_dir::read_for_dir(const logical_path & root, const std::string & build_prefix) 
        : m_root(root), m_build_prefix(build_prefix) {
    read();
}

namespace {
    // allow sorting ...
    bool by_path_name(const read_for_dir::path_statistics & first, const read_for_dir::path_statistics & second) {
        return path_to_string(first.path) < path_to_string(second.path);
    }
}

void read_for_dir::read() {
    using persist::setting;
    int paths_count = setting<int>( str_stream() << m_build_prefix << ".paths_count" );
    for ( int idx = 0; idx < paths_count; ++idx) {
        std::string prefix = str_stream() << m_build_prefix << "." << idx ;
        std::string path = setting<std::string>(prefix + ".path");
        if ( path.empty() ) continue;

        path_info stats = path_info(run_sys_command_results(),0, path_info::result::success);
        stats.build_res = (path_info::result::type)(int)setting<int>(prefix + ".result");
        stats.size = setting<int>(prefix + ".size");
        stats.processor_time_ms = setting<int>(prefix + ".processor_time_ms");
        stats.spent_time_ms = setting<int>(prefix + ".spent_time_ms");
        stats.is_already_built = setting<bool>(prefix + ".is_already_built");

        if ( stats.processor_time_ms > 0)
            m_stats.push_back( path_statistics(path, stats));
        else
            ; /* note: if the processor time is zero, it means this path does not contain any files
                       Thus, we can safely ignore it
               */
    }

    // after all have been sorted, we can allow associative access as well...
    rng::sort( m_stats, &by_path_name);
    int path_idx = 0;
    for ( crange<const statistics_array> r(m_stats); r; ++r, ++path_idx)
        m_path_to_idx[ path_to_string(r->path) ] = path_idx;
}


/** 
    returns true if we have any statistics for this path
*/
bool read_for_dir::has_path_stats(const logical_path & path) const {
    std::string unique = path_to_string( path.physical_path() );
    return rng::coll_find( m_path_to_idx, unique);
}


/** 
    returns the statistics for this path.

    precondition: Assumes there are statistics for this path.
*/
read_for_dir::path_statistics read_for_dir::path_stats(const logical_path & path) const {
    std::string unique = path_to_string( path.physical_path() );
    if ( crange<const statistics_idx_coll> r = rng::coll_find( m_path_to_idx, unique) )
        return m_stats[r->second];
    else
        PWC_THROW std::logic_error("no statistics for this path");    
}






}


