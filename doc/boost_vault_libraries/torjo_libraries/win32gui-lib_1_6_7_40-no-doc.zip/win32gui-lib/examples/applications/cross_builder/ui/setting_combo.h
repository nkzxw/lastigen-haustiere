

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "setting/setting.h"


struct setting_combo_handler;

/** 
    @brief Represents a combo-box that allows modifying a setting value

    Note that such a combo always allows the user to set a $parameter$ as the result.
    (even if conceptually it's a "drop-list" combo)
*/
struct setting_combo : wnd_extend<win32::gui::combo_box, setting_combo>, win32::gui::reflectable_class<setting_combo> {
    static std::string reflection_name();
    setting_combo(void);
    ~setting_combo(void);

    // what to call when the user exits, by saving or cancel 
    boost::function<void()> on_exit;

    typedef std::vector<std::string> array;
    
    struct drop_now {
        typedef enum type {
            // show drop-down as well
            open,
            // don't open drop down now
            closed
        };
    };
    struct drop_type {
        typedef enum type {
            // it's a fixed combo (conceptually, also known as "drop-list")
            fixed,
            // it's an open combo (conceptually, also known as "drop-down")
            open
        };
    };

    void do_edit(const array & a, int idx_chosen, int idx_default, drop_type::type type, drop_now::type drop);

    struct constraint_ {
        typedef enum type {
            number,
            enum_,
            string
        };
    };
    void constraint(constraint_::type c);
    constraint_::type constraint() const { return m_constraint; }

    std::string selected_value() const { return m_selected; }
private:
    friend struct setting_combo_handler ;

    // the values shown in the combo
    array m_values;

    // the initial choice
    int m_initial_choice;

    // the default - note: if -1, there is no default
    int m_default_choice;

    // the selected value; not necessary within the presented (m_)values
    std::string m_selected;

    // type of combo
    drop_type::type m_type;

    drop_now::type m_drop;

    // are there any constraints?
    constraint_::type m_constraint;
};


