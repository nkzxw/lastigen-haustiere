

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

namespace tree {
struct no_info {
    no_info() {}
    template<class other> no_info(const other &) {}
};

/** 
    Represents a trivial tree structure, composed of nodes, each having a name.
*/
template< class extra_info = no_info> struct item {
    item(const std::string& n = "", extra_info inf = extra_info() ) : m_name(n), info(inf) {}

    template<class e2> item(const item<e2> & other)
        : m_name(other.m_name), info(other.info) {

      for ( crange< const typename item<e2>::array > r(other.children); r; ++r)
          children.push_back( *r);        
    }

    const std::string & name() const { return m_name; }

    // returns the child with this name, or null if it does not exist
    item<extra_info> * child_by_name(const std::string & name) {
        for ( crange<array> r(children); r; ++r)
            if ( r->name() == name) return &*r;
        return 0;
    }
    // returns the child with this name, or null if it does not exist
    const item<extra_info> * child_by_name(const std::string & name) const {
        for ( crange<const array> r(children); r; ++r)
            if ( r->name() == name) return &*r;
        return 0;
    }


    // extra information, if needed
    extra_info info;
    typedef std::vector< item<extra_info> > array;
    array children;

private:
    template<class e> friend struct item;
    // name of the tree item - this is unchangeable
    std::string m_name;

};



} // namespace tree
