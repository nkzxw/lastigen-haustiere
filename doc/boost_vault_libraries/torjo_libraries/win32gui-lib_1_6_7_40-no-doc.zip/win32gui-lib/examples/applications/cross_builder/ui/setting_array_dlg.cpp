

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\setting_array_dlg.h"
#include "util/rw_string_io.h"
#include "main/app.h"
#include "ui/browse_button.h"
#include "ui/settings_dlg.h"
#include "util/string_util.h"


// FIXME I have to make Resource Splitter generate these forward defs!!!
namespace {
    struct array_edit;
    struct array_list_ctrl;
}
#include "win32gui_res/setting_array.hpp"


using namespace win32::gui;
namespace {
    enum {
        WM_DO_ESC = WM_APP + 20,
        WM_DO_SAVE = WM_APP + 21,
        WM_DO_EDIT_ITEM = WM_APP + 22,
        WM_DO_SAVE_ITEM = WM_APP + 23, // saves current element
        WM_DO_CANCEL_ITEM = WM_APP + 24, // cancels current element
        WM_START_EDIT = WM_APP + 25,

        WM_DO_DEL_ITEM = WM_APP + 26, 
        WM_DO_INS_ITEM = WM_APP + 27, 
    };

    // the edit box for the current item
    struct array_edit : wnd_extend<edit, array_edit>, reflectable_class<array_edit> {
        static std::string reflection_name() { return "array_edit"; }
    };
    struct array_edit_handler : event_handler<array_edit_handler, array_edit> {

        handle_event on_key_down(wm::keyb::key_down::arg a, mark_event_not_handled) {
            BOOST_LOG(gui) << "[setting_array] key down on edit " << a.key_code;
            bool do_enter = false;
            bool do_esc = false;

            if ( a.key_code == VK_RETURN)
                do_enter = true;
            if ( a.key_code == VK_ESCAPE)
                do_esc = true;
            if ( a.key_code == VK_LEFT)
                if ( self->sel() == std::make_pair(0,0))
                    do_esc = true;
            if ( a.key_code == VK_TAB)
                do_enter = true;

            if ( do_enter) parent()->post_msg(WM_DO_SAVE_ITEM);
            if ( do_esc) parent()->post_msg(WM_DO_CANCEL_ITEM);

            return event_ex<wm::keyb::key_down>().HANDLED_BY(&me::on_key_down);
        }

        handle_event on_dlg_code(result r) {
            r = DLGC_WANTALLKEYS;
            return event_ex<wm::get_dlg_code>().HANDLED_BY(&me::on_dlg_code);
        }
    };

    // the list control within the settin array dialog
    struct array_list_ctrl : wnd_extend<list_ctrl, array_list_ctrl>, reflectable_class<array_list_ctrl> {
        static std::string reflection_name() { return "array_list_ctrl"; }
    };
}
    // inherit the events from list_ctrl class...
    template<int ctrl_id> struct events_for_class<ctrl_id,array_list_ctrl> 
        : events_for_class<ctrl_id, list_ctrl> {};
namespace {


    struct array_list_ctrl_handler : event_handler<array_list_ctrl_handler, array_list_ctrl> {

        handle_event on_key_down(wm::keyb::key_down::arg a, mark_event_not_handled) {
            BOOST_LOG(gui) << "[setting_array] key down on list ctrl " << a.key_code;
            bool do_enter = false;
            bool do_esc = false;
            bool do_edit = false;
            bool do_del = false;
            bool do_ins = false;

            if ( a.key_code == VK_F2 || a.key_code == VK_RETURN)
                do_enter = true;
            if ( a.key_code == VK_ESCAPE || a.key_code == VK_LEFT)
                do_esc = true;
            if ( a.key_code == VK_SPACE || a.key_code == VK_RIGHT)
                do_edit = true;

            if ( a.key_code == VK_SPACE && parent<setting_array_dlg>()->type() == sett::enum_)
                // in this case, "Space" checks/unchecks 
                do_edit = false;

            if ( a.key_code == VK_INSERT) do_ins = true;
            if ( a.key_code == VK_DELETE || a.key_code == VK_BACK) do_del = true;

            if ( do_enter) parent()->post_msg(WM_DO_SAVE);
            if ( do_esc) parent()->post_msg(WM_DO_ESC);
            if ( do_edit) parent()->post_msg(WM_DO_EDIT_ITEM);
            if ( do_ins) parent()->post_msg(WM_DO_INS_ITEM);
            if ( do_del) parent()->post_msg(WM_DO_DEL_ITEM);

            return event_ex<wm::keyb::key_down>().HANDLED_BY(&me::on_key_down);
        }

        handle_event on_char(wm::keyb::char_::arg a) {
            if ( parent<setting_array_dlg>()->type() == sett::enum_)
                return event_handled_early; // for enum arrays, there's no edit - just check/uncheck

            int sel = self->sel();
            if ( sel < 0) sel = 0;
            if ( self->item( sel).text() == "") {
                // this key, I consider it as the first char when editing
                self->item( self->sel(), 0, lv_item().text( std::string() + (char)a.char_code) );
                parent()->post_msg(WM_DO_EDIT_ITEM);
            }
            return event_ex<wm::keyb::char_>().HANDLED_BY(&me::on_char);
        }

        handle_event on_dlg_code(result r) {
            r = DLGC_WANTALLKEYS;
            return event_ex<wm::get_dlg_code>().HANDLED_BY(&me::on_dlg_code);
        }
    };

}

// FIXME I should allow, when user presses up/down arrows, to easily move within the items

// FIXME right now, I don't do any validation for numbers...
// FIXME right now, don't handle enumerators

// whenever clicking outside our area, do "Escape"
struct handle_outside_setting_array : subclass::auto_event_handler<handle_outside_setting_array,window_base> {
    handle_event on_click() {
        // find the setting array window
        wnd<> sett = find_wnd<settings_dlg>()->sub_wnd<setting_array_dlg>();
        if ( !sett->is_visible()) return event_handled_early;

        if ( !sett->window_rect(rel_to_screen).contains_point( cursor_pos() )) {
            // outside our area, should do cancel
            //
            // however, see if it's a click in a popup dialog
            
            // find the top dialog
            wnd<> w = self.to_wnd();
            wnd<dialog> topmost_dlg = null_wnd;
            for ( ; w; w = w->parent())  
                if ( wnd<dialog> dlg = try_cast<dialog>(w) ) topmost_dlg = dlg;
            bool is_popup = topmost_dlg && topmost_dlg->has_style(window_::style::popup);
            if ( !is_popup)
                sett->post_msg(WM_DO_ESC);
        }
        return event_ex<wm::mouse::left_down>().HANDLED_BY(&me::on_click);
    }
};





struct setting_array_dlg_handler : event_handler<setting_array_dlg_handler, setting_array_dlg> {
    bool m_editing;
    wnd<> m_prev_focus;
    setting_array_dlg_handler() : m_editing(false), m_prev_focus(null_wnd) {
        using namespace boost;
//        child<browse_button>(m_browse::id)->on_after_browse = bind( mem_fn(&me::on_after_browse), this, _1);
  //      child<browse_button>(m_browse::id)->on_cancel_browse = bind( mem_fn(&me::on_cancel_browse), this);
        m_browse->on_after_browse = bind( mem_fn(&me::on_after_browse), this, _1);
        m_browse->on_cancel_browse = bind( mem_fn(&me::on_cancel_browse), this);
    }

    handle_event on_start_edit() {
        make_room_for_browse_button_if_needed();
        adjust_browse_button_pos();
        m_prev_focus = window_base::keyboard_focus_wnd();
        m_editing = true;
        self->bring_to_top(); // we're the center of the action now ;)
        self->m_cancelled = false;
        m_list->set_focus();
        return event<WM_START_EDIT>().HANDLED_BY(&me::on_start_edit);
    }

    handle_event do_cancel() {
        if ( !m_editing) return event_handled_early; // already ended editing
        m_editing = false;
        self->m_cancelled = true;
        hide();
        self->on_exit();
        return event<WM_DO_ESC>().HANDLED_BY(&me::do_cancel);
    }

    handle_event do_save() {
        if ( !m_editing) return event_handled_early; // already ended editing
        m_editing = false;
        hide();
        self->on_exit();
        return event<WM_DO_SAVE>().HANDLED_BY(&me::do_save);
    }

    handle_event do_edit() {
        if ( !m_editing) return event_handled_early; // already ended editing

        // for enumerations, there's no editing - there's just check/uncheck
        assert ( self->type() != sett::enum_);

        // see the current selected element
        int sel = m_list->sel();
        if ( sel < 0) sel = 0;
        if ( m_list->item_count() <= 0)
            m_list->add_item( lv_item().text("") );

        std::string elem = m_list->item(sel).text();
       m_cur_item->text(elem);
        // position the edit box and perhaps the "Browse" button
        rectangle elem_rect = m_list->sub_item_rect( sel, 0);
        elem_rect = elem_rect.convert( m_list, window() );
        elem_rect.right = elem_rect.left + m_list->client_rect().width();
        if ( self->type() == sett::dir || self->type() == sett::file) {
            // browsing as well...
            rectangle browse_rect = elem_rect;
            browse_rect.left = browse_rect.right - m_browse->client_rect().width();
            elem_rect.right = browse_rect.left;
        }
        elem_rect.bottom += 4; // ... make sure we're fully visible
       m_cur_item->move(elem_rect);
       m_cur_item->show();
       m_cur_item->set_focus();
        if ( elem.size() > 1)
           m_cur_item->sel( 0, (int)elem.size() ); // select the whole word
        else
            // zero or one char - go to the end
           m_cur_item->sel( (int)elem.size(), (int)elem.size() );

        return event<WM_DO_EDIT_ITEM>().HANDLED_BY(&me::do_edit);
    }

    handle_event on_save_item() {
        std::string item_text =m_cur_item->text();
        m_list->item( m_list->sel(), lv_item().text(item_text) );
        // if it was the last elem, add one more...
        bool was_last = m_list->sel() == m_list->item_count() - 1;
        if ( was_last)
            m_list->add_item( lv_item().text("") );
       m_cur_item->show( window_::show::hide);
        m_list->set_keyboard_focus();
        return event<WM_DO_SAVE_ITEM>().HANDLED_BY(&me::on_save_item);
    }

    handle_event on_cancel_item() {
       m_cur_item->show( window_::show::hide);
        m_list->set_keyboard_focus();
        return event<WM_DO_CANCEL_ITEM>().HANDLED_BY(&me::on_cancel_item);
    }

    handle_event on_list_click() {
        do_edit();
        return event_ex<m_list_::ev::clicked>().HANDLED_BY(&me::on_list_click);
    }

    handle_event on_sel_change() {
        adjust_browse_button_pos();
        return event_ex<m_list_::ev::item_changed>().HANDLED_BY(&me::on_sel_change);
    }


    handle_event on_ins_item() {
        if ( self->type() == sett::enum_) return event_handled_early;

        int sel = m_list->sel();
        m_list->insert_item( sel, lv_item().text("") );
        m_list->sel(sel);
        do_edit();
        return event<WM_DO_INS_ITEM>().HANDLED_BY(&me::on_ins_item);
    }

    handle_event on_del_item() {
        if ( self->type() == sett::enum_) return event_handled_early;
        int sel = m_list->sel();
        if ( m_list->item_count() == 1) sel = 0; // just in case deleting the single item
        if ( sel >= 0)
            m_list->del_item(sel);
        if ( m_list->item_count() <= 0)
            m_list->add_item( lv_item().text("") );

        return event<WM_DO_DEL_ITEM>().HANDLED_BY(&me::on_del_item);
    }

    handle_event any_cmd() {
        // don't forward commands to parent (which is the default)
        return command<0>().HANDLED_BY(&me::any_cmd);
    }

    handle_event on_ok() {
        do_save();
        return event_ex<m_ok_::ev::clicked>().HANDLED_BY(&me::on_ok);
    }

    handle_event on_ins_button() {
        on_ins_item();
        return event_ex<m_add_::ev::clicked>().HANDLED_BY(&me::on_ins_button);
    }
    handle_event on_del_button() {
        on_del_item();
        return event_ex<m_del_::ev::clicked>().HANDLED_BY(&me::on_del_button);
    }

    void on_after_browse(const std::string & path) {
        on_cancel_item();
        m_list->item( m_list->sel(), 0, lv_item().text(path) );
    }
    void on_cancel_browse() {
        on_cancel_item();
    }


private:
    void hide() {
        del_room_for_browse_button_if_needed();
        self->show( window_::show::hide);        
        if ( m_prev_focus) m_prev_focus->set_focus();
    }

    void make_room_for_browse_button_if_needed() {
        m_browse->show(window_::show::hide);
        if ( self->type() != sett::dir && self->type() != sett::file) {
            return; // no need for "Browse"
        }

        rectangle list_rect = m_list->window_rect(rel_to_parent);
        list_rect.right -= m_browse->client_rect().width();
        m_list->move(list_rect);
    }

    void del_room_for_browse_button_if_needed() {
        m_browse->show(window_::show::hide);
        if ( self->type() != sett::dir && self->type() != sett::file) {
            return; // no need for "Browse"
        }

        rectangle list_rect = m_list->window_rect(rel_to_parent);
        list_rect.right += m_browse->client_rect().width();
        m_list->move(list_rect);
    }

    void adjust_browse_button_pos() {
        // adjust Browse button
        if ( self->type() != sett::dir && self->type() != sett::file) return ;
        int sel = m_list->sel();
        if ( sel < 0) return ;

        m_browse->show();
        rectangle elem_rect = m_list->sub_item_rect( sel, 0);
        elem_rect = elem_rect.convert( m_list, window() );
        rectangle list_rect = m_list->window_rect(rel_to_parent);
        rectangle browse_rect = m_browse->window_rect(rel_to_parent);
        browse_rect = browse_rect.to_point( point(list_rect.right, elem_rect.top) );
        m_browse->move(browse_rect);
    }
};


setting_array_dlg::setting_array_dlg(void) : m_cancelled(false) {
    m_list->add_col( lv_col().text("Values").width(250));
    m_list->extended_style( m_list->extended_style() | list_ctrl_::extended_style::full_row_select);

    add_resizable_ctrl( m_list_::id, size_xy);
    add_resizable_ctrl( m_add_::id, move_x);
    add_resizable_ctrl( m_del_::id, move_x);
    add_resizable_ctrl( m_ok_::id, move_xy);

//    mapping::remap_wnd<array_list_ctrl>( child(m_list_::id));
  //  mapping::remap_wnd<array_edit>( child(m_cur_item_::id));
    //mapping::remap_wnd<browse_button>( child(m_browse_::id));

    m_cur_item->bring_to_top();
    m_browse->bring_to_top();
}

setting_array_dlg::~setting_array_dlg(void) {
}

int setting_array_dlg::dialog_id() { return dialog_id_; }

void setting_array_dlg::do_edit(const std::string & initial_sel, sett::type type) {
    bring_to_top();

    m_initial_sel = initial_sel;
    m_type = type;
   m_cur_item->show( window_::show::hide);
    m_list->del_all_items();
    bool show_checks = type == sett::enum_;
    DWORD old_style = m_list->extended_style();
    m_list->extended_style( 
        show_checks ? (old_style | list_ctrl_::extended_style::check_boxes) : (old_style & ~list_ctrl_::extended_style::check_boxes));
    std::string elem;
    std::istringstream in(initial_sel);
    while ( in >> io::read_str(elem) ) {
        m_list->add_item( lv_item().text(elem) );
        // ignore the delimeter
        char ch;
        in >> ch;
    }

    if ( m_type != sett::enum_) {
        // the "Insert-last" item
        m_list->add_item( lv_item().text("") );
        m_list->sel( m_list->item_count() - 1);
    }
    send_msg(WM_START_EDIT);
}

/** 
    In case this is an enumeration array, specifies the initially selected enumerations.
*/
void setting_array_dlg::set_initial_enums(const setting::enum_array & enums, const std::string & initial_sel) {
    assert( m_type == sett::enum_);
    m_enums = enums;
}

std::string setting_array_dlg::selected_values() const {
    // FIXME does not handle enums yet!
    if ( m_cancelled) return m_initial_sel;

    int count = m_list->item_count();
    std::ostringstream out;
    bool any_written = false;
    for ( int idx = 0; idx < count; ++idx) {
        std::string item = trimmed( m_list->item(idx).text() );
        if ( !item.empty()) {
            if ( any_written) out << ','; // delimeter
            out << io::write_str(item);        
            any_written = true;
        }
    }
    return out.str();
}


