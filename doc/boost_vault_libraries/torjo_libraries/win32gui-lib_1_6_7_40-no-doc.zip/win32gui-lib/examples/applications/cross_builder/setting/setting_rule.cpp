

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\setting_rule.h"
#include <stdexcept>
#include "util/string_util.h"
#include "util/rw_string_io.h"

using namespace boost::rangelib;

setting_rule::setting_rule() : applies(setting_rule::applies_to::compile)
{
}

setting_rule::~setting_rule(void)
{
}





setting_rule::condition setting_rule::condition::from_string(std::string str) {
    setting_rule::condition c;
    str_trim(str);
    if ( str == "always") {
        c.condition_type = always;
        return c;
    }

    { std::istringstream in(str);
      std::string signature; in >> signature;
      if ( signature == "for_each") {
          in >> c.setting_name;
          c.condition_type = for_each;
          return c;
      }
    }

    { std::istringstream in(str);
      std::string signature; in >> signature;
      if ( signature == "for") {
          in >> c.setting_name;
          c.condition_type = for_;
          return c;
      }
    }

    typedef std::string::size_type size_type;
    size_type equal_idx = str.find("="), in_idx = str.find(" in ");
    if ( equal_idx == std::string::npos && in_idx == std::string::npos)
        PWC_THROW std::runtime_error("invalid condition string");
    bool is_equal_cond = equal_idx < in_idx || in_idx == std::string::npos;
    if ( is_equal_cond) {
        // x=y condition
        std::string remaining = str.substr(equal_idx + 1);
        std::istringstream in(remaining);
        std::string only_val;
        in >> io::read_str(only_val);

        c.condition_type = setting_rule::condition::equals;
        c.setting_name = str.substr(0, equal_idx);
        c.values.push_back( normalized_name(only_val) );
    }
    else {
        // x in (a,b,c,...) condition
        //
        // each a,b,c, etc. are one-word-only (the names should not contain any inner spaces)
        std::string remaining = str.substr(in_idx + 4);
        str_replace(remaining, ",", " ");
        str_trim(remaining);
        if ( remaining.empty() || remaining[0] != '(' || *remaining.rbegin() != ')')
            PWC_THROW std::runtime_error("invalid condition string");
        remaining = remaining.substr(1, remaining.size() - 2);
        std::istringstream in(remaining);
        std::string word;
        while ( in >> word)
            c.values.push_back(word);

        c.setting_name = str.substr(0, in_idx);
        c.condition_type = setting_rule::condition::any_of;

    }
    str_trim(c.setting_name);
    c.setting_name = normalized_name(c.setting_name);
    return c;
}


/** 
    Reads a rule and returns it
*/
setting_rule rule_from_line(const std::string & line) {
    setting_rule rule;

    typedef std::string::size_type size_type;
    size_type implies_idx = line.find("->");
    if ( implies_idx == std::string::npos)
        PWC_THROW std::runtime_error("invalid rule line - does not contain '->'");

    // the string containing the conditions
    std::string cond_str = line.substr(0, implies_idx);
    rule.m_add_to_cmd_line = line.substr(implies_idx + 2);
    str_trim( rule.m_add_to_cmd_line );
    str_trim( cond_str);

    while ( cond_str.find("&&") != std::string::npos) {
        // we have an ANDing of conditions
        size_type idx = cond_str.find("&&");
        std::string cur_cond = cond_str.substr(0, idx);
        rule.m_conditions.push_back( setting_rule::condition::from_string(cur_cond) );
        cond_str = cond_str.substr(idx + 2);
    }
    rule.m_conditions.push_back( setting_rule::condition::from_string(cond_str) );

    return rule;
}


/** 
    Returns the settings that are needed to test whether this rule holds true or not
*/
setting_rule::setting_name_array setting_rule::needed_settings() const {
    setting_name_array a;
    for ( crange<const condition_array> r(m_conditions); r; ++r) 
        if ( r->condition_type != condition::always ) 
            a.push_back(r->setting_name);
    return a;
}


/** 
    Applies the rule. Returns the resulting string, from applying the rule.

    In case the result is an empty string, the rule was not met.
*/
std::string setting_rule::apply(const name_and_value_coll & setts) const {
    if ( m_conditions.size() == 1 && m_conditions[0].condition_type == condition::for_each)
        return apply_for_each(setts);
    if ( m_conditions.size() == 1 && m_conditions[0].condition_type == condition::for_)
        return apply_for(setts);

    bool matches = true;
    for ( crange<const condition_array> r(m_conditions); r; ++r) {
        std::string value;
        if ( r->condition_type != condition::always) {
            if ( crange<const name_and_value_coll> r_val = rng::coll_find(setts, r->setting_name)) value = r_val->second;
            else PWC_THROW std::runtime_error("needed setting value not found while trying to evaluate rule");
        }

        switch ( r->condition_type) {
            case condition::equals:
                assert(r->values.size() == 1); // we have an x==y rule
                if ( value == r->values[0])
                    ; // ok - still matches
                else
                    matches = false;
                break;

            case condition::any_of: {
                bool matches_any = false;
                for ( crange<const condition::array> r_cur_val(r->values); r_cur_val; ++r_cur_val)
                    if ( value == *r_cur_val) matches_any = true;
                if ( matches_any)
                    ; // ok - matches
                else
                    matches = false;               
                } break;

            case condition::always:
                // nothing to do
                break;

            case condition::for_each:
            default:
                PWC_THROW std::runtime_error("invalid rule");
        }
    }

    if ( matches) 
        return m_add_to_cmd_line;
    else
        return "";
}



std::string setting_rule::apply_for_each(const name_and_value_coll & setts) const {
    // right now for_each handles only one setting
    assert( setts.size() == 1);

    std::string cmd_line;
    std::istringstream in(setts.begin()->second);
    std::string val;
    while ( in >> io::read_str(val) ) {
        std::string cur_item = m_add_to_cmd_line;
        str_replace( cur_item, "$(var)", val);
        cmd_line += " " + cur_item;
        char ch = 0;
        in >> ch;
        if ( in && (ch != ','))
            PWC_THROW std::runtime_error("invalid encoded string array");
    }

    return cmd_line;
}


std::string setting_rule::apply_for(const name_and_value_coll & setts) const {
    // right now for_each handles only one setting
    assert( setts.size() == 1);

    std::string cmd_line = m_add_to_cmd_line;
    std::string val = setts.begin()->second;
    str_replace( cmd_line, "$(var)", val);
    return cmd_line;
}
