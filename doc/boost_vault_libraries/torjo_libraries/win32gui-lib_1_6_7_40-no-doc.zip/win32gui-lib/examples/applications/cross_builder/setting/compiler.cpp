

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\compiler.h"

// FIXME compiler name - should be limited. For instance, it should contain only 
//       characters that are allowed for file names
// (example: used in creating the 'build path')


// dir - the path to this compiler
compiler::compiler(metadata_ptr metadata, const std::string & path, fs::path physical_path) 
        : m_metadata(metadata), m_compiler_path(path), m_physical_path(physical_path) {

    m_friendly_name = m_physical_path.leaf();

    std::ifstream in( (physical_path / "name.txt").string().c_str() );
    std::string line;
    std::getline(in, line);
    if ( !line.empty() ) m_friendly_name = line;

    // if it's not an intermediate compiler, it needs to have metadata
    assert(m_metadata || is_intermediate() );        
}

compiler::~compiler(void)
{
}

/** 
    Returns true if this just an intermediate compiler.

    A compiler is an intermediate compiler if it's not meant to be used directly.
    It's simply meant as a logical parent for other compilers.
    (example: MSVC, gcc)
*/
bool compiler::is_intermediate() const {
    return fs::exists( m_physical_path / "intermediate.txt");
}
