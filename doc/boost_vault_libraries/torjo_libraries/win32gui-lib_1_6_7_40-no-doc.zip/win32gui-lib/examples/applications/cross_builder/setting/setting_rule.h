

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "setting/setting.h"

struct setting_rule;
setting_rule rule_from_line(const std::string & line);


/** 
    @brief Represents a rule that can be applied to one or more settings.
           Applying a rule results a in string that is to be appended to 
           the command line (compiler or linker)

   A rule can be applied to one or more settings.
   If the condition tested by this rule holds true, then
   the string that follows the '->' is added to the command line.

   Rules are executed in sequential order, as the appear in the .txt files.

   Further restrictions:

   Multiple rules can be grouped together in an options group.
   In an options group, if multiple rules are true, the last one that holds
   true overrides all the previous ones.

   This allows for easy overriding of certain options. For instance, for MSVC,
   the Global optimization option overrides the /INCREMENTAL[..] switch. By placing them together
   in an option group, this happens automatically:

    @code
    options incremental_link
    incremental_link=0 -> /INCREMENTAL
    incremental_link=1 -> /INCREMENTAL:NO
    whole_optimize=1 -> /GL
    end-option incremental_link
    @endcode

    Note that a rule can be part of zero-or more options groups.
    There is no nesting of options groups - they are siblings to each other

*/
struct setting_rule {
private:
    friend setting_rule rule_from_line(const std::string & line);

    // use rule_from_line instead
    setting_rule();
public:
    ~setting_rule();

    typedef std::vector<std::string> setting_name_array;
    setting_name_array needed_settings() const;

    typedef std::map< std::string, std::string > name_and_value_coll;
    std::string apply(const name_and_value_coll & setts) const;

    /** 
        what does the rule apply to?
    */
    struct applies_to {
        typedef enum type {
            compile,
            link
        };
    };
    applies_to::type applies;


    // the options groups this setting belongs to
    typedef std::set<std::string> option_set;
    option_set option_groups;

private:
    std::string apply_for_each(const name_and_value_coll & setts) const;
    std::string apply_for(const name_and_value_coll & setts) const;

private:
    // what to add to command line, if conditions hold
    std::string m_add_to_cmd_line;

    // conditions that must ALL hold true for a rule to happen
    struct condition {

        static condition from_string(std::string str);

        typedef enum type { 
            // true if setting is equal to a value
            equals,
            // true if setting contains a value
            any_of,
            // this rule is always true (that is, we will always add something to the command line)
            always,
            // for arrays: for each of the items, append something to the command line
            // In this case, '$(var)' is a keyword that is replaced by each item
            for_each,
            // similar to a for_each, only that the setting is not an array
            for_
        };
        
        // what kind of condition is it?
        type condition_type;
        
        std::string setting_name;

        typedef std::vector<std::string> array;
        array values;
    };

    //
    // note: at this time, we allow only ANDing of conditions.
    typedef std::vector<condition> condition_array;
    condition_array m_conditions;
};


