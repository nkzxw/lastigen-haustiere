// Persist Settings Library
//
// Copyright 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

// persist_exception.h: interface for the persist_exception class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PERSIST_EXCEPTION_H__018CFC28_B447_49C8_A590_537333CA332B__INCLUDED_)
#define AFX_PERSIST_EXCEPTION_H__018CFC28_B447_49C8_A590_537333CA332B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning (disable :4786) // msvc

#include <stdexcept>
#include <sstream>

namespace persist {

namespace err {

    // handles an error that occurs when persisting
    //
    // note that this handler might be called multiple times in case of a bulk-operation
    // (bulk-operation is composed of multiple sub-operations)
    struct handler {
        virtual ~handler() {}
        // in case we're on a GET operation, value is NOT null, allowing you to set it to a default and continue the 
        // program, if you like
        //
        // on any other operation, value is NULL
        virtual void on_error( std::string * value, const std::string & error) const = 0;
    };

    // totally ignores the error 
    struct ignore : public handler {
        void on_error( std::string * value, const std::string & ) const {
            if ( value)
                value->erase();
        }
    };

    // throws an exception
    struct do_throw : public handler {
        void on_error( std::string *, const std::string & error ) const {
            throw std::runtime_error(error);
        }
    };

    // sets a default value, in case of error
/*    struct set_def : public handler {
        template<class type> set_def( const type & def) { m_def << def; }
        void on_error( std::string * value, const std::string & ) const {
            if ( value)
                *value = m_def.str();
        }
    private:
        std::ostringstream m_def;
    }; */
    // note: for the above, VC6 generates buggy code
    struct set_def : public handler {
        template<class type> set_def( const type & def) { 
            std::ostringstream out;
            out << def; 
            m_def = out.str();
        }
        void on_error( std::string * value, const std::string & ) const {
            if ( value)
                *value = m_def;
        }
    private:
        std::string m_def;
    };

    
    
    // appends the error into the string you pass at construction
    struct append_err : public handler {
        append_err( std::string & e) : error(e) {}
        void on_error( std::string *, const std::string & err ) const {
            if ( !error.empty() ) error += '\n';
            error += err;
        }
        mutable std::string &error;
    };

} // namespace err

} // namespace persist

#endif // !defined(AFX_PERSIST_EXCEPTION_H__018CFC28_B447_49C8_A590_537333CA332B__INCLUDED_)
