

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

struct tab_forward_ctrl_handler ;

/** 
    @brief Represents a tab forward control. It is never visible, and all it does,
           is forward focus.

    Use it when you have a complex dialog structure (several dialog-on-dialogs), 
    and you need to clearly specify
    tabbing (and "Control Parent" style is not enough)

    FIXME move to win32gui

    @remarks
    We extend the edit control, since it's "Tab focusable" by default. Had we extended the label,
    when you would use the Resource Editor, you'd have to manually set the "Tabstop" property to true.
*/
struct tab_forward_ctrl :   wnd_extend<win32::gui::edit, tab_forward_ctrl>, 
                            win32::gui::auto_mapping<tab_forward_ctrl> {
    tab_forward_ctrl(void);
    ~tab_forward_ctrl(void);

    static bool matches_hwnd(HWND h);

    // when your callback is called, set:
    // before - to the logical "before" control (shift-tab)
    // after  - to the logical "after" control (Tab)
    typedef boost::function<void (win32::gui::wnd<> & before, win32::gui::wnd<> & after) > focus_func;
    void call_on_focus(focus_func f);
    
private:
    friend struct tab_forward_ctrl_handler ;
    focus_func m_f;
};

