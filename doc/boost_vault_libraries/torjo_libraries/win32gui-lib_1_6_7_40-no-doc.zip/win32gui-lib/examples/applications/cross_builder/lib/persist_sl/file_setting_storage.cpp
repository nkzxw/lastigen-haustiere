// Persist Settings Library
//
// Copyright 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

// file_setting_storage.cpp: implementation of the file_setting_storage class.
//
//////////////////////////////////////////////////////////////////////

#include "file_setting_storage.h"
#include <fstream>
#include <algorithm>

#ifdef WIN32
#include <windows.h>
#endif

namespace persist {

namespace {
    // reads a string, with [start,end)
    // Syntax: "<value>"
    //
    // note: \\,\n,\r," are escaped 
    void read_string( const char * & start, const char * end, std::string & val, bool & ok) {
        ok = false;
        val.erase();
        val.reserve( end-start);
        // ignore leading spaces
        char ch = ' ';
        while ( (start < end) && (ch == ' ')) 
            ch = *start++;
        // string must start with '"' char
        if ( !(start < end) || (ch != '"') ) 
            return;
        
        while ( start < end) {
            ch = *start;
            if ( ch == '"') 
                // end-of-string found
                break;
            else if ( ch != '\\') 
                val += ch;
            else {
                // might be escape
                char next = (start+1 < end) ? start[1] : 0;
                char escape = 0;
                if ( next == '\\') escape = '\\';
                else if ( next == 'n') escape = '\n';
                else if ( next == 'r') escape = '\r';
                else if ( next == '"') escape = '"';

                if ( escape != 0) {
                    // it's escape
                    val += escape;
                    ++start;
                }
                else
                    // no escape
                    val += ch;
            }

            ++start;
        }
        
        if ( (start < end) && (*start == '"')) {
            // string was ok
            ++start;
            ok = true;
        }
    }


    // writes the string
    //
    // Syntax: "<value>"
    //
    // note: \\,\n,\r," are escaped 
    void write_string( std::ostream & out, const std::string & val) {
        out << '"';
        const char * start = &*val.begin();
        const char * end = &*val.end();
        while ( start != end) {
            if ( *start == '\\') out << "\\\\";
            else if ( *start == '\n') out << "\\n";
            else if ( *start == '\r') out << "\\r";
            else if ( *start == '"') out << "\\\"";
            else out << *start;
            ++start;
        }
        out << '"';
    }



    // syntax:
    // "<property_name>" "<property_value>" any comment you like
    // Example:
    // "app.wnd.left" "5" This is the application left window
    //
    // in case cannot correctly find the name-to-value pair, we consider all line a comment
    //
    // note: \\,\n,\r," are escaped (transparently to the user)
    void read_setting( const std::string & line, std::string & name, std::string & val, std::string & comment) {
        int idx = 0;
        const char * start = &*line.begin();
        const char * end = &*line.end();
        bool ok_name, ok_val;
        read_string( start, end, name, ok_name);
        read_string( start, end, val, ok_val);
        comment = std::string( start,end);
        if ( !ok_name || !ok_val) {
            // could not successfully read name or val
            name.erase();
            val.erase();
            comment = line;
        }
    }


    void write_setting( std::ostream & out, const std::string & name, const std::string & val, const std::string & comment) {
        if ( !name.empty() ) {
            // we have name + val
            write_string( out, name);
            out << ' ';
            write_string( out, val);
        }
        out << comment << "\n";
    }

    // converts a value to lower-case
    std::string locase( const std::string & str) {
        std::string lo;
        lo.resize( str.length());
        std::transform( str.begin(), str.end(), lo.begin(), tolower);
        return lo;
    }
}

file_setting_storage::file_setting_storage( const std::string & file_name, file_storage_open_type open_type, file_storage_load_type load_type, file_storage_save_type save_type)
    : m_file_name( file_name),
      m_open_type( open_type),
      m_load_type( load_type),
      m_save_type( save_type),
      m_needs_save( false) {
    load();
    // note: VC6 has a bug - if the file does not exist, and is saved *after* existing main,
    // it'll generate an Access Violation
    save( err::ignore() );
}

file_setting_storage::~file_setting_storage()
{

}


void file_setting_storage::load() const {
    m_name_to_line.clear();
    m_infos.clear();

    std::ifstream in( m_file_name.c_str() );
    std::string line;
    // each property is persisted on a line
    //
    // syntax:
    // "<property_name>" "<property_value>" any comment you like
    // Example:
    // "app.wnd.left" "5" This is the application left window
    //
    // notes: \n,\r," are escaped (transparently to the user)
    //        the comments are preserved, when re-saving the file.
    while ( std::getline( in, line) ) {
        info parsed;
        read_setting( line, parsed.name, parsed.value, parsed.comment);
        m_infos.push_back( parsed);
        if ( !parsed.name.empty() ) {
            // we have a name-to-value on this line (not just a comment)
            int idx = (int)m_infos.size() - 1;
			// we're case-insensitive
			parsed.name = locase(parsed.name);
            m_name_to_line[ parsed.name] = idx;
        }
    }
}

void file_setting_storage::save( const err::handler & h ) {
    if ( m_open_type == open_read_only) {
        h.on_error( 0, "The file " + m_file_name + " is treated as read only");
        return;
    }

    bool do_save = m_needs_save || m_name_to_line.empty(); // if no settings, most likely there's no file. Create it.
    if ( !do_save) return;

#ifdef WIN32
	DWORD attr = ::GetFileAttributesA( m_file_name.c_str() );
	if ( m_open_type == open_force_writable)
		::SetFileAttributesA( m_file_name.c_str(), attr & ~FILE_ATTRIBUTE_READONLY);
#endif

    { std::ofstream out( m_file_name.c_str());
    infos_array::const_iterator first = m_infos.begin(), last = m_infos.end();
    while ( first != last) {
        write_setting( out, first->name, first->value, first->comment);
        ++first;
    }
    if ( !out.fail() )
        m_needs_save = false;
    else
        h.on_error( 0, "could not save settings to file " + m_file_name);
	}

#ifdef WIN32
	if ( m_open_type == open_force_writable)
		if ( attr != (DWORD)-1)
			// set original attributes back
			::SetFileAttributesA( m_file_name.c_str(), attr);
#endif
}

void file_setting_storage::get_setting( const std::string & name, std::string & value, std::string & error) const {
    if ( m_load_type == reload_each_get)
        load();
    
    error.erase();
    coll::const_iterator found = m_name_to_line.find( name);
    if ( found != m_name_to_line.end() ) {
        int idx = found->second;
        value = m_infos[idx].value;
    }
    else
        error = "value not found: " + name ;
}

void file_setting_storage::set_setting( const std::string & name, const std::string & value, std::string & error) {
    error.erase();
    coll::const_iterator found = m_name_to_line.find( name);
    if ( found != m_name_to_line.end() ) {
        // setting already exists
        int idx = found->second;
        if ( m_infos[idx].value != value) {
            m_infos[idx].value = value;
            m_needs_save = true; // aggresive caching - only if you're setting to a new value, will we mark for save.
        }
    }
    else {
        // new setting
        m_needs_save = true;
        info new_sett;
        new_sett.name = name;
        new_sett.value = value;
        m_infos.push_back( new_sett);
        int idx = (int)m_infos.size() - 1;
        m_name_to_line[name] = idx;
    }

    if ( m_save_type == save_each_modify)
        save( err::append_err(error) );
}

void file_setting_storage::enum_settings( std::map<std::string,std::string> & values, std::string & error) const {
    values.clear();
    error.erase();
    // note: we have all of our settings cached;
    //       we copy them in the order we've read them.
    infos_array::const_iterator first = m_infos.begin(), last = m_infos.end();
    while ( first != last) {
        if ( !first->name.empty() )
            values[ first->name] = first->value;
        ++first;
    }
}


} // namespace persist
