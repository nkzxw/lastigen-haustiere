
// Utility Library
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
#include "stdafx.h"
#include "file_util.h"
#include <boost/rangelib/algo.hpp>
using namespace boost::rangelib;

#include <boost/filesystem/operations.hpp>
using namespace boost::filesystem;
#include <direct.h>
#include "util/string_util.h"

namespace {

#if defined(WIN32)
    bool case_insensitive_eq( char first, char second) {
        return toupper(first) == toupper(second);
    }

    bool compare_filename( const std::string & first, const std::string & second) {
        if ( first.size() != second.size() ) return false;
        // same size
        return rng::equal( first, second, case_insensitive_eq);
    }
#else
    // unix
    bool compare_filename( const std::string & first, const std::string & second) {
        return first == second;
    }
#endif
}

// converts the given path, making it relative to the src path
//
// precondition: dest & src are both complete
path relative_to( const path & dest, const path & src) {
    // both paths should be complete
    assert( dest.is_complete() && src.is_complete() );

    path::iterator dest_begin = dest.begin(), dest_end = dest.end();
    path::iterator src_begin = src.begin(), src_end = src.end();
    path result;


//#if defined(BOOST_WINDOWS)
#if defined(WIN32)
    if ( !compare_filename( dest.root_name(), src.root_name()) ) {
        // paths are on different drives (like, "c:/test/t.txt" and "d:/home")
        return dest;
    }

    if ( src_begin != src_end) ++src_begin;
    if ( dest_begin != dest_end) ++dest_begin;
#endif

    // ignore directories that are same
    while ( (src_begin != src_end) && (dest_begin != dest_end)) {
        if ( !compare_filename( *src_begin, *dest_begin))
            break;
        ++src_begin, ++dest_begin;
    }

    // now, we begin to relativize
    while ( src_begin != src_end) {
        result /= "..";
        ++src_begin;
    }

    while ( dest_begin != dest_end) {
        result /= *dest_begin;
        ++dest_begin;
    }
    return result;
}


/*
void test_relative_to( const std::string & dest, const std::string & src) {
    std::string result = relative_to( dest, src).string();
    std::cout << "Testing path '" << dest << "',\n"
        " relative to '" << src << "'\n"
        " result    : '" << result << "'\n" << std::endl;
}

int main(int argc, char* argv[])
{
    path::default_name_check( &native);
    test_relative_to( "c:/temp/test/inner/i2/file.txt", "c:/temp/test");
    test_relative_to( "c:/temp/test/inner/i2/file.txt", "c:/temp/test/other");
    test_relative_to( "c:/temp/test/inner/i2/file.txt", "c:/temp");
    test_relative_to( "c:/temp/test/inner/i2/file.txt", "c:/temp/test");
    test_relative_to( "c:/temp/test", "c:/temp/test");
    test_relative_to( "c:/temp/test/inner/i2/file.txt", "d:/temp/test");
    test_relative_to( "c:/temp/test", "d:/temp/test");

    test_relative_to( "c:/other/test/inner/i2/file.txt", "c:/temp/test");
    test_relative_to( "c:/other/test/inner/i2/file.txt", "c:/oth/test/other");
    test_relative_to( "c:/other/test/inner/i2/file.txt", "c:/temp");
    test_relative_to( "c:/other/test/inner/i2/file.txt", "c:/other/test");

    return 0;
}

*/



// from a path ***VALID on this system*** path string, returns its minimal complete path
// Example: c:/test/me/.. -> c:/test
//
// the path must be a directory!
boost::filesystem::path get_complete_minimum_path( const boost::filesystem::path & p) {
    path minimum = p;
    path old = current_path();
    if ( chdir( p.string().c_str() ) == 0)
        minimum = current_path();
    chdir( old.string().c_str() );
    return minimum;
}


// convert a path to a string that uniquely *identifies* this path in the user's file-system
std::string path_to_string(const boost::filesystem::path & p) {
#if defined(WIN32)
    // Win32 only - names are case-insensitive
    return locase( p.string());
#else
    return p.string();
#endif
}



