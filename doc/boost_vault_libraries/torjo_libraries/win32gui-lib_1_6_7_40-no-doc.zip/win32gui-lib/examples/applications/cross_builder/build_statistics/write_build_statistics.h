

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "build/logical_path.h"
#include "setting/configuration.h"
#include "build_statistics/build_statistics.h"

namespace build_statistics {

/** 
    @brief Writes statistics, while building a directory
*/
struct write_for_dir {
    write_for_dir(const logical_path & root, const std::string & build_prefix);
    ~write_for_dir(void);

    void add_non_project_path(const logical_path & path);
    void add_project_path(const logical_path & path);
    void add_file(const logical_path & file, path_info stats);

private:
    void prepare_for_path(const logical_path & path);
    void add_path_impl(const logical_path & path, bool is_project);

private:
    // what to prepend, when persisting statistics
    std::string m_build_prefix;

    // the number of files that have been built
    int m_built_files_count;

    // whenever a path is added, it's assigned a unique index, to know where to persist it.
    int m_next_path_idx;

    // the project's root
    logical_path m_root;

    struct path_statistics {
        path_statistics( 
                    const logical_path & path, int idx, bool is_project,
                    path_info stats = path_info(run_sys_command_results(),0, path_info::result::success)) 
            : path(path), idx(idx), is_project(is_project), stats(stats) {}

        logical_path path;
        int idx;
        bool is_project;
        path_info stats;
    };
    typedef std::vector< path_statistics> path_array;

    void do_persist();
    void do_persist_path(const path_statistics & stats);
    
    // the directories we're in the process of building, right now.
    path_array m_built_paths;
};


}




