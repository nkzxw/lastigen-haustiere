

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

// show_compare_results_dlg.h
#ifndef show_compare_results_dlg_H
#define show_compare_results_dlg_H

// uniquely identifies the statistics for a build
struct build_statistics_key {
    build_statistics_key(
                fs::path dir, const std::string & compiler, 
                const std::string & config, time_t at_time, const std::string & prefix)
        : dir(dir), compiler(compiler), config(config), at_time(at_time), build_prefix(prefix) {}

    fs::path dir;
    std::string compiler;
    std::string config;

    time_t at_time;

    // the prefix that uniquely identifies this persisted build
    std::string build_prefix;
};



struct show_compare_results_dlg : wnd_extend<dialog,show_compare_results_dlg>, 
                    wnd_extend<resizable_wnd,show_compare_results_dlg> {
    show_compare_results_dlg();
    ~show_compare_results_dlg();
    static int dialog_id();


    void show_single(build_statistics_key key);
    void show_compare(build_statistics_key first, build_statistics_key second);


};

#endif
