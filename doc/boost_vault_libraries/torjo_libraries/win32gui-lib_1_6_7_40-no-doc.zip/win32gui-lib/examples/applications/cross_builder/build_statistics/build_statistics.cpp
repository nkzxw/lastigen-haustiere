

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\build_statistics.h"

namespace build_statistics {

using namespace boost::rangelib;


// adds the settings from a sub-path
void path_info ::add(const path_info & sub) {
    processor_time_ms += sub.processor_time_ms;
    spent_time_ms += sub.spent_time_ms;
    size += sub.size;
}

namespace {
    // unique prefix that identifies a build
    std::string unique_prefix(int dir_idx, int build_idx) {
        return str_stream() << "build.statistics." << dir_idx << "." << build_idx ;
    }
}

/** 
    returns a unique prefix that is used to persist this (new) build
*/
std::string new_prefix(const logical_path & build_path, configuration config, const std::string & compiler) {
    using persist::setting;

    fs::path path = build_path.physical_path();
    std::string config_path = config.path().string();

    // each HDD directory is identified by an index (first of all, this is so I can enumerate
    // all built directories)
    const int MAX_CACHED_DIRS = setting<int>("app.build.statistics.max_cached_dirs", persist::err::set_def(50));
    int corresponding_idx = -1;
    // first, see if user has already built this dir...
    std::vector<time_t> last_built_times;
    for ( int i = 0; i < MAX_CACHED_DIRS; ++i) {
        fs::path existing_path = setting<std::string>(str_stream() << "build.path.dir_path." << i);
        last_built_times.push_back( setting<time_t>(str_stream() << "build.path.last_build_time." << i));
        if ( existing_path == path) {
            corresponding_idx = i;
            break;
        }
    }
    bool built_already = ( corresponding_idx != -1);
    if ( !built_already) {
        int least_time_idx = (int)rng::distance( rng::min_element<from_beg>(last_built_times) );
        corresponding_idx = least_time_idx;
    }

    // update - we're gonna build this directory...
    time_t now = time(0);
    setting<std::string>(str_stream() << "build.path.dir_path." << corresponding_idx) = path.string();
    setting<time_t>(str_stream() << "build.path.last_build_time." << corresponding_idx) = now;

    // now, I have the directory path. Find out an entry index for this compiler/config/time
    //
    // For a directory that is built, we have a fixed number of slots. After all slots are full,
    // we start reusing them starting from zero, and so on.
    const int MAX_SLOTS = setting<int>("app.build.statistics.max_slots_per_dir", persist::err::set_def(100));
    int current_slot = setting<int>(str_stream() << "build.path." << corresponding_idx << ".current_slot");
    int built_files_count = setting<int>(
        str_stream() << "build.statistics." << corresponding_idx << "." << current_slot << ".built_files_count");
    bool already_taken = built_files_count > 0;
    if ( already_taken) {
        current_slot = (current_slot + 1) % MAX_SLOTS;
        setting<int>(str_stream() << "build.path." << corresponding_idx << ".current_slot") = current_slot;
    }

    std::string prefix = str_stream() << "build.statistics." << corresponding_idx << "." << current_slot;
    setting<std::string>(prefix + ".compiler") = compiler;
    setting<std::string>(prefix + ".config") = config_path;
    setting<time_t>(prefix + ".time") = now;
    // note: this is just for debugging purposes (to understand what .time means)
    tm now_details = *localtime(&now);
    setting<std::string>(prefix +  ".time_str") = asctime(&now_details);
    return prefix;
}



namespace {
    // sort by time
    bool build_by_time(const dir_build_key & a, const dir_build_key & b) { return a.build_time < b.build_time; }
    // sort by time
    bool dir_by_time(const dir_builds & a, const dir_builds & b) { return a.last_build_time < b.last_build_time; }

}

void load_dir_build_tree(dir_builds_array & dirs) {
    using persist::setting;
    dirs.clear();

    // first, load all dirs
    for ( int i = 0; ; ++i) {
        fs::path dir = setting<std::string>(str_stream() << "build.path.dir_path." << i);
        if ( dir.empty() ) break; // no more cached statistics...
        
        time_t last_time = setting<time_t>(str_stream() << "build.path.last_build_time." << i);
        dirs.push_back( dir_builds(dir, i, last_time));
    }

    // most recently built, come first
    rng::sort(dirs, dir_by_time);
    rng::reverse(dirs);

    // for each build, see the compiler/configs it's been built for
    for ( crange<dir_builds_array> r(dirs); r; ) {
        const int MAX_CONSECUTIVE_UNUSED_SLOTS = 10; // if I find more unused slots, it means I've reached the end...
        int consecutive_unused_slots = 0;
        for ( int i = 0; consecutive_unused_slots < MAX_CONSECUTIVE_UNUSED_SLOTS ; ++i) {
            std::string prefix = unique_prefix(r->dir_idx, i) ;
            int files_count = setting<int>(prefix + ".built_files_count");
            if ( files_count <= 0) {
                ++consecutive_unused_slots; 
                continue;
            } 
            consecutive_unused_slots = 0; // found a used slot

            std::string compiler = setting<std::string>(prefix + ".compiler");
            std::string config = setting<std::string>(prefix + ".config");
            time_t build_time = setting<time_t>(prefix + ".time");
            r->builds.push_back( dir_build_key(i, compiler, config, build_time) );
        } // for

        // most recent built comes first
        rng::sort(r->builds, build_by_time);
        rng::reverse(r->builds);

        if ( !r->builds.empty() ) 
            ++r; // no builds for this dir, ignore
        else 
            r = rng::erase_current(dirs, r);
    }
}


namespace {
    bool has_name(const dir_builds & dir, const fs::path & name) {
        return dir.dir == name;
    }

    bool has_project_and_compiler(const dir_build_key & key, const configuration & config, const std::string & compiler) {
        return key.compiler == compiler && key.config == config;
    }
}

/** 
    returns the unique prefix of the latest build for this build configuration

    If there was no previous build, returns an empty string
*/
std::string latest_prefix(const logical_path & project_path, configuration config, const std::string & compiler) {
    dir_builds_array dirs;
    load_dir_build_tree(dirs);

    using namespace boost;
    if ( crange<dir_builds_array> r = rng::find_if( dirs, bind(has_name,_1,project_path.physical_path() ))) {
        // find out the builds for this project/config/compiler
        std::vector<dir_build_key> builds;
        rng::copy( 
            filtered(r->builds, bind(has_project_and_compiler,_1,config,compiler) ), 
            std::back_inserter(builds));
        rng::sort(builds, build_by_time);
        rng::reverse(builds);
        if ( !builds.empty())
            return unique_prefix(r->dir_idx , builds[0].slot_idx);
    }

    return std::string(); // no such path...
}


/** 
    returns the unique prefix of the pinned build for this build configuration. <br>
    If there is no pinned build, returns the prefix of the lastest build. <br>
    If there was no previous build, returns an empty string


@remarks
    If for a config/compiler, there is a pinned directory, further builds of this directory
    will be compared to this build.

*/
std::string pinned_prefix(const logical_path & project_path, configuration config, const std::string & compiler) {
    dir_builds_array dirs;
    load_dir_build_tree(dirs);

    using namespace boost;
    if ( crange<dir_builds_array> r = rng::find_if( dirs, bind(has_name,_1,project_path.physical_path() ))) {
        // find out the builds for this project/config/compiler
        typedef std::vector<dir_build_key> array;
        array builds;
        rng::copy( 
            filtered(r->builds, bind(has_project_and_compiler,_1,config,compiler) ), 
            std::back_inserter(builds));
        rng::sort(builds, build_by_time);
        rng::reverse(builds);
        if ( !builds.empty()) {
            // there are some builds for this config/compiler. See if there a pinned one...
            for ( crange<array> r_build(builds); r_build; ++r_build) {
                bool is_pinned = persist::setting<bool>(unique_prefix(r->dir_idx,r_build->slot_idx) + ".is_pinned");
                if ( is_pinned)
                    return unique_prefix(r->dir_idx,r_build->slot_idx); // found the pinned one...
            }
            // no pins - return the last build ...
            return unique_prefix(r->dir_idx , builds[0].slot_idx);
        }
    }

    return std::string(); // no such path...
}




/** 
    unpins this directory/config/compiler for statistics.

    If for a config/compiler, there is a pinned directory, further builds of this directory
    will be compared to this build.
*/
void unpin_previous_builds(const logical_path & project_path, configuration config, const std::string & compiler) {
    dir_builds_array dirs;
    load_dir_build_tree(dirs);

    using namespace boost;
    if ( crange<dir_builds_array> r = rng::find_if( dirs, bind(has_name,_1,project_path.physical_path() ))) {
        // find out the builds for this project/config/compiler
        std::vector<dir_build_key> builds;
        rng::copy( 
            filtered(r->builds, bind(has_project_and_compiler,_1,config,compiler) ), 
            std::back_inserter(builds));
        
        for ( crange<dir_builds::builds_array> r_build(builds); r_build; ++r_build)
            persist::setting<bool>(unique_prefix(r->dir_idx, r_build->slot_idx) + ".is_pinned") = false;
    }
}





} // namespace build_statistics
