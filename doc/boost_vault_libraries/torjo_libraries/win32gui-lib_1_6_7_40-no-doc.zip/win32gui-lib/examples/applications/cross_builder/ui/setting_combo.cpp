

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\setting_combo.h"
#include "main/app.h"
#include "util/string_util.h"

using namespace win32::gui;

namespace {
    // when showing the default, what will we append to it?
    const std::string DEFAULT_SIGNATURE = "           [default]";

    enum {
        WM_COMBO_ESC = WM_APP + 20,
        WM_COMBO_SAVE  ,
        WM_COMBO_NEXT  ,
        WM_COMBO_PREV  ,
        WM_START_EDIT  ,
        WM_COMBO_TAB ,
        WM_SUBCLASS_EDIT
    };
}

// the edit box inside the combo...
struct setting_edit : wnd_extend<edit,setting_edit> {
};
struct setting_edit_handler : event_handler<setting_edit_handler,setting_edit> {
    handle_event on_kill_focus() {
        parent()->post_msg(WM_COMBO_ESC);
        return event_ex<wm::keyb::kill_focus>().HANDLED_BY(&me::on_kill_focus);
    }

    handle_event on_key_down(wm::keyb::key_down::arg a, event_answer ans) {
        ans = event_not_handled;
        bool do_esc = false;
        bool do_save = false;
        bool do_tab = false;
        // for escape
        if ( a.key_code == VK_ESCAPE) {
            if ( !parent<combo_box>()->is_dropped())
                do_esc = true;
            else {
                // combo box is dropped - Esc means to simply hide the dropped list
                //
                // however, if Enumeration, this also means cancelling
                if ( parent<setting_combo>()->constraint() == setting_combo::constraint_::enum_)
                    do_esc = true;
            }
        }
        // for Tab or Shift-Tab
        if ( a.key_code == VK_TAB) {
            do_save = true;
            bool shift_down = (int)::GetAsyncKeyState(VK_SHIFT) < 0;
            if ( !shift_down) do_tab = true;
        }
        // pressing left arrow - to go back to the settings...
        if ( a.key_code == VK_LEFT) {
            bool at_beginning = self->sel() == std::make_pair(0,0);
            if ( at_beginning) do_esc = true;
            bool full_select = self->sel() == std::make_pair(0, (int)self->text().size());
            if ( full_select && parent<combo_box>()->is_dropped() )
                do_esc = true;
        }

        if ( a.key_code == VK_RETURN) {
            if ( parent<setting_combo>()->constraint() != setting_combo::constraint_::enum_)
                if ( !parent<combo_box>()->is_dropped())
                    // saving (pressed Enter in the edit box)
                    do_save = true;
        }


        if ( do_esc) 
            parent()->post_msg(WM_COMBO_ESC);
        if ( do_save)
            parent()->post_msg(WM_COMBO_SAVE);
        if ( do_tab) 
            parent()->post_msg(WM_COMBO_TAB);

        if ( do_esc || do_save || do_tab)
            ans = event_is_handling;
        return event_ex<wm::keyb::key_down>().HANDLED_BY(&me::on_key_down);
    }

    handle_event on_dlg_code(result r) {
        r = DLGC_WANTALLKEYS;
        return event_ex<wm::get_dlg_code>().HANDLED_BY(&me::on_dlg_code);
    }
};


struct setting_combo_handler : event_handler<setting_combo_handler, setting_combo> {
    bool m_editing;
    wnd<> m_prev_focus;
    setting_combo_handler() : m_editing(false), m_prev_focus(null_wnd) {}

    handle_event on_subclass_edit() {
        // subclass the child edit box - we can't subclass it in the constructor of setting_combo, 
        // it would be too early
        mapping::remap_wnd<setting_edit>( first_child_wnd() );
        return event<WM_SUBCLASS_EDIT>().HANDLED_BY(&me::on_subclass_edit);
    }


    handle_event on_start_editing() {
        m_editing = true;

        m_prev_focus = get_focus_wnd();
        self->set_focus();
        self->sel( self->m_initial_choice);
        self->text( self->m_initial_choice >= 0 ? self->m_values[self->m_initial_choice] : "" );
        self->show_drop_down( self->m_drop == setting_combo::drop_now::open);

        if ( self->m_drop == setting_combo::drop_now::closed) 
            self->edit_sel( 0, (int)self->text().size()); // select the text...

        return event<WM_START_EDIT>().HANDLED_BY(&me::on_start_editing);
    }

    handle_event on_combo_esc() {
        if ( !m_editing) return event_handled_early; // already ended editing
        m_editing = false;

        // we're cancelling
        if ( self->m_initial_choice >= 0)
            self->m_selected = self->m_values[ self->m_initial_choice ];
        else
            self->m_selected = "";
        BOOST_LOG(gui) << "setting-combo - escaping, selection: " << self->m_selected;
        hide();
        self->on_exit();
        return event<WM_COMBO_ESC>().HANDLED_BY(&me::on_combo_esc);
    }

    handle_event on_combo_save() {
        if ( !m_editing) return event_handled_early; // already ended editing
        m_editing = false;

        self->m_selected = self->text();
        bool is_default = self->m_default_choice >= 0 && 
            (self->m_selected == self->m_values[self->m_default_choice] + DEFAULT_SIGNATURE);
        if ( is_default)
            self->m_selected = self->m_values[self->m_default_choice];

        // FIXME when using params, if the value is $...$, then no constraints are applied.

        // in case we should constrain the result...
        switch ( self->m_constraint) {
        case setting_combo::constraint_::enum_: {
            // see the closest enumeration value
            int idx = 0;
            int idx_match = -1;
            std::string sel = locase(self->m_selected);
            // find the first match of the selection, within the enumerated values ...
            for ( ; !sel.empty(); idx = 0, sel = sel.substr(0, sel.size()-1) ) 
                for ( crange<setting_combo::array> r(self->m_values); r; ++r, ++idx)
                    if ( locase(*r).find(sel) == 0) {
                        idx_match = idx;
                        // double for-break
                        sel = "-";
                        break;
                    }
            if ( idx_match == -1)
                // there was no match at all...
                idx_match = self->m_default_choice;
            if ( idx_match == -1)
                idx_match = self->m_initial_choice;
            if ( idx_match == -1)
                idx_match = 0;
            self->m_selected = self->m_values[idx_match];

            } break;
        case setting_combo::constraint_::number: {
            // make it a number
            std::istringstream in( self->m_selected);
            int n = 0;
            in >> n;
            self->m_selected = str_stream() << n;
            } break;
        case setting_combo::constraint_::string: break;
        default: assert(false);
        }
        BOOST_LOG(gui) << "setting-combo - saving, selection: " << self->m_selected;
        hide();
        self->on_exit();
        return event<WM_COMBO_SAVE>().HANDLED_BY(&me::on_combo_save);
    }


    handle_event on_combo_up() {
        if ( self->m_constraint != setting_combo::constraint_::enum_)
            // only for enumerations, closing this, saves the selection
            return event_handled_early;

        // FIXME when having parameters, for $param$, don't close yet!

        // note: here, the text hasn't changed yet, we need to set it manually...
        std::string sel = self->item_text( self->sel() );
        self->text(sel);
        post_msg(WM_COMBO_SAVE);
        return command<ID_reflect,CBN_CLOSEUP>().HANDLED_BY(&me::on_combo_up);
    }

    static void set_next_id(int ctrl_id, int & result, const wnd<> &w) {
        if ( !w->is_visible() ) return;
        int cur_id = w->dlg_ctrl_id();
        if ( cur_id > ctrl_id)
            if ( cur_id < result)
                result = cur_id;
    }

    handle_event on_tab() {
        // do a "Tab" - that is, move to the next control in the window order
        int next_id = INT_MAX;
        using namespace boost;
        std::for_each( find_wnd_range(parent(),search_children), wnd_iterator<>(), 
            bind(set_next_id, self->dlg_ctrl_id(),ref(next_id),_1));
        wnd<> next = next_id != INT_MAX ? parent()->child(next_id) : parent()->first_wnd();
        next->set_focus();
        return event<WM_COMBO_TAB>().HANDLED_BY(&me::on_tab);
    }

private:
    void hide() {
        self->show_drop_down(false);
        self->show( window_::show::hide);
        
        if ( m_prev_focus) m_prev_focus->set_focus();
    }
};


std::string setting_combo::reflection_name() { return "setting_combo"; }


setting_combo::setting_combo(void) : m_initial_choice(0), m_type(drop_type::fixed), m_constraint(constraint_::string) {
    text_limit(2048);
    post_msg(WM_SUBCLASS_EDIT);
}

setting_combo::~setting_combo(void)
{
}


/** 
    sets the values to be shown in the combo-box
*/
void setting_combo::do_edit(const array & a, int idx_chosen, int idx_default, drop_type::type type, drop_now::type drop) {
    m_values = a;
    m_initial_choice = idx_chosen;
    m_default_choice = idx_default;
    m_type = type;
    m_drop = drop;

    del_all_items();
    int idx = 0;
    for ( crange<const array> r(m_values); r; ++r, ++idx) {
        std::string name = *r;
        // FIXME (nice to have) maybe in the future, I repaint the combo-box manually,
        // and show "[default]" right-justified
        if ( idx == m_default_choice) name += DEFAULT_SIGNATURE;
        add_item(name);
    }

    send_msg(WM_START_EDIT);
}

void setting_combo::constraint(constraint_::type c) {
    m_constraint = c;
}

