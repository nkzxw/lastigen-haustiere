// Persist Settings Library
//
// Copyright 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

// configuration.h: interface for the configuration class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONFIGURATION_H__7F1CC6BE_9F02_465B_8926_3BA732AC28C0__INCLUDED_)
#define AFX_CONFIGURATION_H__7F1CC6BE_9F02_465B_8926_3BA732AC28C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning (disable :4786) // msvc

#include "ts.h"
#include "persist_exception.h"
#include <map>
#include <string>

namespace persist {

// forward declaration
class setting_storage;

/*
    A configuration contains multiple settings that can be get/set.
    It shields you from where each of these settings are stored (persisted).
*/
class configuration  
{
    class def_cfg {};
    configuration( const def_cfg &);
public:
	configuration();
	~configuration();

    static configuration & def();
    void resolve_name( const std::string & name, std::string & place, std::string & sett_name) const;
    void get_setting( const std::string & place, const std::string & sett_name, std::string & value, const err::handler & h );
    void set_setting( const std::string & place, const std::string & sett_name, const std::string & value, const err::handler & h );
    void add_storage( const std::string & storage_name, setting_storage * store);
    void remove_storage( const std::string & storage_name);
    void remove_all_storages();

    void copy_to_file( const std::string & file_name, const err::handler & h = err::ignore());

    void save(const err::handler & h = err::ignore());
    void copy_into( configuration & other, const err::handler & h = err::ignore());
    void copy_into_no_overwrite( configuration & other, const err::handler & h = err::ignore());
private:
    typedef std::map<std::string,setting_storage*> coll;
    coll m_storages;
    mutable ::persist::detail::critical_section m_cs;
public:
};

// this function needs to be provided by the user of the library, to initalize the (default) configuration
void on_initialize_default_config( configuration & cfg);

} // namespace persist

#endif // !defined(AFX_CONFIGURATION_H__7F1CC6BE_9F02_465B_8926_3BA732AC28C0__INCLUDED_)
