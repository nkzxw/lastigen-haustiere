

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "stdafx.h"
// configure_compiler_dlg.cpp
#include "configure_compiler_dlg.h"
#include <win32gui/event_handler.hpp>

#include "ui/enter_settings_dlg.h"
#include "ui/build_progress/perform_build_dlg.h"
#include "setting/computer.h"

#include "win32gui_res/configure_compiler.hpp"
#include "win32gui_res/test_compiler.hpp"

using namespace win32::gui;
using namespace boost::rangelib;

namespace {
    int REFRESH_TESTING = unique_timer_id(); 
}

struct configure_compiler_dlg_handler : event_handler<configure_compiler_dlg_handler, configure_compiler_dlg> {
    typedef std::map< std::string, wnd<perform_build_dlg> > build_wnd_coll;
    build_wnd_coll m_coll;

    // in case we're testing...
    wnd<> m_testing_dlg;

    configure_compiler_dlg_handler() : m_testing_dlg(null_wnd) {}

    handle_event on_test() {
        if ( rng::coll_find( m_coll, self->m_compiler_path) )
            return event_handled_early; // already building...

        compiler_ptr comp = user_comp().get_compiler(self->m_compiler_path);
        configuration config = debug_config(); 
        wnd<perform_build_dlg> test_build = create_dlg<perform_build_dlg>(null_wnd);
        m_coll.insert( std::make_pair( self->m_compiler_path , test_build ));
        test_build->show( window_::show::hide);
        fs::path test_path = (std::string)persist::setting<std::string>("app.home") + "/root/Testing/Simple_Test";
        test_build->add_build_path( test_path, config, self->m_compiler_path);
        test_build->clean_first(true);
        test_build->start();

        m_test_results->text("Testing...");
        if ( !m_testing_dlg) {
            // create testing dialog, next to the button
            m_testing_dlg = create_dlg<dialog>( window()->top_parent(), create_info().id(test_compiler_::dialog_id_) );
            rectangle testing_rect = m_testing_dlg->window_rect(rel_to_screen);
            rectangle t_rect = m_test_compiler->window_rect(rel_to_screen);
            testing_rect = testing_rect.to_point( point(t_rect.left,t_rect.bottom) );
            m_testing_dlg->move( testing_rect);
        }
        return event_ex<m_test_compiler_::ev::clicked>().HANDLED_BY(&me::on_test);
    }

    handle_event on_timer(wm::timer::arg a,  mark_event_not_handled) {
        if ( a.timer_id == REFRESH_TESTING)
            refresh_testing();
        return event_ex<wm::timer>().HANDLED_BY(&me::on_timer);
    }

private:
    void refresh_testing() {
        if ( m_testing_dlg) {
            int count = (int)time(0) % 10;
            std::string str = "Testing";
            for (int idx = 0; idx < count; ++idx) str +="..";
            m_testing_dlg->child<test_compiler_::m_test_>()->text(str);
        }

        bool has_current_compiler_finished_testing = false;
        bool success = false;
        for ( crange<build_wnd_coll> r(m_coll); r; ) {
            bool has_finished_building = r->second->sucess_builds_count() > 0 || r->second->failed_builds_count() > 0;
            if ( has_finished_building)
                if ( r->first == self->m_compiler_path) {
                    has_current_compiler_finished_testing = true;
                    success = r->second->sucess_builds_count() > 0;
                }
            if ( has_finished_building) {
                // if has failed, show the "Build" dialog, to see the failure...
                bool has_failed = has_current_compiler_finished_testing && !success;
                if ( has_failed) {
                    r->second->show();
                    r->second->set_foreground();
                }
                else
                    r->second->destroy();
                r = rng::erase_current(m_coll, r);
            }
            else
                ++r;
        }

        if ( has_current_compiler_finished_testing) {
            m_test_results->text(success ? "Test successful" : "Test FAILED");
            if ( m_testing_dlg) {
                m_testing_dlg->destroy();
                m_testing_dlg = null_wnd;
            }                
        }
    }
};


configure_compiler_dlg::configure_compiler_dlg() {
    sub_wnd<enter_settings_dlg>()->path( logical_path::root());
    sub_wnd<enter_settings_dlg>()->config( configuration::root() );

    set_timer(REFRESH_TESTING, 1000);

    child<splitter>(m_splitter2_::id)->sizing(splitter::sizing_left_only);
}

configure_compiler_dlg::~configure_compiler_dlg() {
}

int configure_compiler_dlg::dialog_id() { return dialog_id_; }

/** 
    specifies the compiler path for the compiler to be configure
*/
void configure_compiler_dlg::compiler_path(const std::string & path) {
    bool all_compilers = path == "root/C++";
    sub_wnd<enter_settings_dlg>()->show_settings( 
        user_comp().get_settings_at_dir(path, "root/Configure Compiler"),
        all_compilers ? enter_settings_dlg::show_applies_to_compilers_col : enter_settings_dlg::hide_applies_to_compilers_col );

    compiler_ptr comp = user_comp().get_compiler(path);
    m_compiler_name->text( comp->friendly_name() );
    m_compiler_path = path;
}
