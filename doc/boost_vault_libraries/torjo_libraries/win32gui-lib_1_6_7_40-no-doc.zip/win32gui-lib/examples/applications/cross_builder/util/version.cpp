// file_util.cpp: implementation of the file_util class.
//
//////////////////////////////////////////////////////////////////////

// Utility Library
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

#include "stdafx.h"
#include "version.h"

#include <assert.h>
#include <sstream>
#include <string>

namespace version {

// returns version information for the given file
void get_file_info( const std::string & file_name, info & val) {
    //AfxMessageBox( file_name.c_str());
    DWORD ignore = 0;
    DWORD buffer_size = GetFileVersionInfoSize( const_cast<char*>(file_name.c_str()), &ignore);
    // make sure we have file version information
    assert( buffer_size > 0);

    typedef std::auto_ptr<char> ptr;
    ptr buffer = ptr( new char[ buffer_size]);
    GetFileVersionInfo( const_cast<char*>(file_name.c_str()), ignore, buffer_size, buffer.get() );

    VS_FIXEDFILEINFO *ver_info;
    UINT ver_info_size;
    VerQueryValue( buffer.get(), "\\", 	(void **)&ver_info, &ver_info_size);
    val.major_ver = HIWORD(ver_info->dwFileVersionMS);
    val.minor_ver = LOWORD(ver_info->dwFileVersionMS);
    val.build_no = ver_info->dwFileVersionLS;
}


namespace {

    std::string exe_name(const std::string & cmd_line) {
        if ( cmd_line[0] == '"') {
            std::istringstream in( std::string(cmd_line.c_str() + 1));
            std::string line;
            std::getline(in, line, '"');
            return line;
        }
        else {
            // one single word
            std::istringstream in(cmd_line);
            std::string word;
            in >> word;
            return word;
        }
    }
}

// returns version information for the the current executable.
void get_file_info( info & val) {
    std::string cmd_line = GetCommandLine();
    get_file_info( exe_name(cmd_line), val);
}

} // namespace version

