

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "setting/name.h"

struct setting_value;
bool operator==( const setting_value & first, const setting_value & second);
std::ostream& operator<<(std::ostream& out, const setting_value & val);


/** 
    @brief Represents a value that was assigned to a setting.

    Note that a value that is assigned to a setting, depends on:
    - a configuration
    - the Setting Mode: "Before" or "After" 
    - the compiler (it can be set for a specific compiler, or for all compilers)
*/
struct setting_value {
    struct mixed {};

    setting_value(const mixed&) : m_is_mixed(true), m_value("","") {}

    setting_value(void);
    setting_value(const name_pair & value);
    ~setting_value(void);

    name_pair value() const             { return m_value; }
    void value(const name_pair & v) { 
        m_value = v; 
        m_is_mixed = false;
    }

    setting_value merge_with(const setting_value & other) const;

private:
    friend bool operator==( const setting_value & first, const setting_value & second);
    friend std::ostream& operator<<(std::ostream& out, const setting_value & val);

    // if true, we have a mix. This means that for the requested setting_key,
    // there are multiple possible setting values.
    //
    // For example, the user asked for "defines" for All compilers, but,
    // each compiler has a different value for "defines".
    bool m_is_mixed;

    // the value
    name_pair m_value;
};

bool operator==( const setting_value & first, const setting_value & second);
inline bool operator!=( const setting_value & first, const setting_value & second) { return !(first == second); }
std::ostream& operator<<(std::ostream& out, const setting_value & val);



/** 
    @brief Represents a fixed setting value, for a specific directory or file.

    It contains all needed info to allow the user to go ahead and edit this setting,
    and to know if the user has chosen to edit it.
*/
struct fixed_setting_value {
    fixed_setting_value() : is_overridden(false) {}

    // FIXME if value & inherited are both mixed, show this visually!

    fixed_setting_value merge_with(const fixed_setting_value & other) const;

    // the value we've inherited
    setting_value inherited;

    // the current value - if it's equal to 'inherited', then it's inherited
    setting_value current;

    // if true, the current overrides the inherited (even if it's the same value)
    bool is_overridden;
};

std::ostream& operator<<(std::ostream& out, const fixed_setting_value & val);

bool operator==( const fixed_setting_value & f, const fixed_setting_value & s);
inline bool operator!=( const fixed_setting_value & f, const fixed_setting_value & s) { return !(f == s); }


