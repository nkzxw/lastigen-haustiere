// file_util.h

// Utility Library
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

#if !defined(AFX_FILE_UTIL_H__2289B7F0_39D0_4C81_BAE6_04751D353031__INCLUDED_)
#define AFX_FILE_UTIL_H__2289B7F0_39D0_4C81_BAE6_04751D353031__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

namespace version {

    struct info {
        info() : major_ver(0), minor_ver(0), build_no(0) {}
        int major_ver;
        int minor_ver;
        DWORD build_no;
    };
    void get_file_info( const std::string & file_name, info & val);
    void get_file_info( info & val);

};




#endif // !defined(AFX_FILE_UTIL_H__2289B7F0_39D0_4C81_BAE6_04751D353031__INCLUDED_)
