

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\logical_path_setting_values.h"
#include "main/app.h"
#include "util/string_util.h"
#include "util/rw_string_io.h"

using namespace boost::rangelib;


setting_key::setting_key(const std::string & name, configuration config, mode::type setting_mode, std::string compiler) 
    : name( normalized_name(name) ), config(config), setting_mode(setting_mode), compiler(compiler) {
}

bool operator<(const setting_key & first, const setting_key & second) {
    if ( first.name != second.name) return first.name < second.name;
    if ( first.config.path() != second.config.path()) return first.config.path().string() < second.config.path().string();
    if ( first.setting_mode < second.setting_mode) return first.setting_mode < second.setting_mode;

    return first.compiler.string() < second.compiler.string();
}

bool operator==(const setting_key & first, const setting_key & second) {
    return first.name == second.name && 
        first.config == second.config &&
        first.setting_mode == second.setting_mode &&
        first.compiler == second.compiler;
}


std::ostream& operator<<(std::ostream& out, const setting_key & key) {
    return out << "[" 
        << key.name << " for (" 
        << key.config.path().string() << ") / "
        << (key.setting_mode == setting_key::mode::after ? "after" : "before") << "/"
        << key.compiler.string() << "]";
}


critical_section & logical_path_setting_values::s_save_cs() {
    // intentionally let it leak - it should be destroyed last
    static critical_section *cs = new critical_section;
    return *cs;
}

logical_path_setting_values::logical_path_setting_values(fs::path dir, logical_path_setting_values_ptr parent) 
    : m_change_id(0), 
      m_dir(dir),
      m_parent(parent),
      m_parent_last_known_change_id(-1) // so that first time we do something, we automatically refresh
{
    refresh();
    if ( !m_dir.empty())
        load();
    m_save_id = m_change_id;
}

logical_path_setting_values::~logical_path_setting_values(void) {
    if ( !m_dir.empty() )
        save();
}


/** 
    Refreshes the settings - more to the point, it makes sure
    those settings that are inherited, are up to date.

    For instance, if we inherit "defines" from parent, 
    and this setting' value just got changed from "DEBUG,WINDOWS" to
    "NDEBUG,POSIX", we will need to visually show this to the user.

    Note that a refresh never means any saving to disk.
    Saving to disk happens only when one of *our* settings get changes.
    When the parent, or any other ascendant's settings are changed, they will save them.
*/
void logical_path_setting_values::refresh() const {
    scoped_lock lk(m_cs);
    if ( m_parent) {
        m_parent->refresh();
        if ( m_parent_last_known_change_id == m_parent->m_change_id)
            return; // nothing has changed since last refresh
    }
    else
        return; // I don't have a parent - nothing to refresh

    m_parent_last_known_change_id = m_parent->m_change_id;
    ++m_change_id;
    BOOST_LOG(app) << "refreshing " << m_dir.string() << ", change id " << m_change_id;

    // do update ourself - note that the parent's values override what the parent inherits

    logical_path_setting_values buff( fs::path("") );
    // first, take all inherited values from the parent
    for ( crange<const setting_coll> r(m_parent->m_settings); r; ++r) 
        buff.m_settings[ r->first ].m_values = r->second.m_inherited; 

    // now, add each current value from the parent - it'll override what's inherited, if any
    for ( crange<const setting_coll> r(m_parent->m_settings); r; ++r) 
        for ( crange<const setting_info::coll> r_sett(r->second.m_values); r_sett; ++r_sett) {
            setting dummy;
            dummy.name = name_pair(r_sett->first.name, r_sett->first.name);
            // ... make sure we override...
            fixed_setting_value fixed_val;
            fixed_val.inherited = setting_value( setting_value::mixed() );
            fixed_val.current = r_sett->second;
            buff.set_value( dummy, r_sett->first, fixed_val);
        }

    // whatever buff has as values, we have as inherited
    for ( crange<const setting_coll> r(buff.m_settings); r; ++r)
        m_settings[ r->first ].m_inherited = r->second.m_values;
}


/** 
    Saves settings to disk, if needed
*/
void logical_path_setting_values::save() {
    setting_coll copy ;
    fs::path dir;
    {
    scoped_lock lk(m_cs);
    if ( m_save_id == m_change_id) return; // no need for saving...

    copy = m_settings;
    dir = m_dir;
    m_save_id = m_change_id;    
    }
    save_impl( dir, copy);
}

/**
    note: saving is done outside the object's lock. This function is static, to prevent
    me from mistakingly use access an object while not holding a lock

    Also, you can modify the settings, since it's a copy
*/
void logical_path_setting_values::save_impl(fs::path dir, setting_coll &settings_copy) {
    scoped_lock lk_save(s_save_cs());
    
    // note: settings belonging to multiple paths could be written to 
    //       the same underlying file. We need to find where our own settings are written...
    std::string signature;
    fs::path dest_file;
    if ( fs::is_directory(dir) ) {
        signature = ".";
        dest_file = dir / "settings.crossbuilder";
    }
    else {
        signature = dir.leaf();
        dest_file = dir.branch_path() / "settings.crossbuilder";
    }
    signature = locase(signature);

    bool any_info_to_write = false;
    std::ostringstream out;
    {
    std::ifstream in( dest_file.string().c_str());
    std::string line;
    bool do_override = false;
    while ( std::getline(in, line) ) {
        std::string keyword;
        std::istringstream line_in(line);
        line_in >> keyword;
        if ( keyword == "path") {
            // see whom are the settings for...
            std::string path_name;
            line_in >> io::read_str(path_name);
            do_override = locase(path_name) == signature;
        }

        if ( do_override)
            ; // we're overriding these settings, below
        else {
            out << line << std::endl;        
            any_info_to_write = true;
        }
    }

    // now, write our own settings
    out << std::endl;
    out << "path " << io::write_str(signature) << std::endl;

    // we're writing it nicely:
    // for each existing {config,compilers} pair, write all settings for it
    while ( !settings_copy.empty() ) {
        setting_key cur_key; // whom are we writing settings for? (setting is ignored)
        bool key_is_initialized = false;
        for ( crange<setting_coll> r_set(settings_copy); r_set; ) {
            for ( crange<setting_info::coll> r_val(r_set->second.m_values); r_val; ) {
                if ( !key_is_initialized) {
                    key_is_initialized = true;
                    cur_key = r_val->first;
                    out << "applies-to " << io::write_str( cur_key.config.path().string() ) << " "
                        << (cur_key.setting_mode == setting_key::mode::after ? "after" : "before") << " "
                        << io::write_str(cur_key.compiler.string()) << std::endl ;
                }

                cur_key.name = r_val->first.name;
                if ( cur_key == r_val->first) {
                    out << "    value " << r_val->first.name << " = " << r_val->second.value() << std::endl;
                    r_val = rng::erase_current(r_set->second.m_values, r_val);
                    any_info_to_write = true;
                }
                else
                    ++r_val;
            } // inner for

            if ( !r_set->second.m_values.empty() )
                ++r_set;
            else
                r_set = rng::erase_current(settings_copy, r_set); // was empty...
        } // outer for
    } // while

    } // close the input file

    // do the actual writing to disk
    fs::remove(dest_file.string() +  ".old");
    try { fs::rename(dest_file, dest_file.string() + ".old"); } catch(...) {}
    if ( any_info_to_write ) {
        std::ofstream out_file( dest_file.string().c_str());
        out_file << out.str();
    }
    else 
        ; // no settings at all - for this path
}



/** 
    loads settings from disk
*/
void logical_path_setting_values::load() {
    scoped_lock lk(m_cs);

    // while we're loading, others can't save (we might end up reading corrupt data)
    scoped_lock lk_save(s_save_cs());

    // note: settings belonging to multiple paths could be written to 
    //       the same underlying file. We need to find where our own settings are written...
    std::string signature;
    fs::path src_file;
    if ( fs::is_directory(m_dir) ) {
        signature = ".";
        src_file = m_dir / "settings.crossbuilder";
    }
    else {
        signature = m_dir.leaf();
        src_file = m_dir.branch_path() / "settings.crossbuilder";
    }
    signature = locase(signature);

    std::ifstream in( src_file.string().c_str());
    std::string line;
    bool reading_our_settings = false;
    setting_key cur_key;
    while ( std::getline(in, line) ) {
        line = trimmed(line);
        if ( line.empty() ) continue;

        std::string keyword;
        std::istringstream line_in(line);
        line_in >> keyword;
        keyword = normalized_name(keyword);
        if ( keyword == "path") {
            std::string path_name;
            line_in >> io::read_str(path_name);
            reading_our_settings = ( locase(path_name) == signature);
            continue;
        }

        if ( reading_our_settings) {
            if ( keyword == "appliesto") {
                // note: config_name is the normalized name of the configuration
                //       Internally, we don't care about the user-friendly name
                std::string config_path, mode, compiler_path;
                line_in >> io::read_str(config_path) >> mode >> io::read_str(compiler_path);
                cur_key.config = config_path;
                cur_key.setting_mode = mode == "after" ? setting_key::mode::after : setting_key::mode::before;
                cur_key.compiler = compiler_path;
            }
            else if ( keyword == "value") {
                std::string name;
                name_pair value;
                char ignore;
                // name = value
                line_in >> name >> ignore >> value;
                assert(ignore == '=');
                cur_key.name = name;
                m_settings[ cur_key.name ].m_values[ cur_key ] = setting_value( value );
                BOOST_LOG(dbg) << "reading settings" << cur_key << " = " << value;
            }
            else 
                BOOST_LOG(err) << "reading setting values: invalid line " << line;
        }
    }

}



namespace {
    // the result of comparing two setting keys, A (first) and B (second)
    enum compare_setting_key_type {
        a_includes_b,
        a_equals_b,
        b_includes_a,
        // a and b have nothing in common
        a_different_than_b,
        a_intersects_with_b
    };

    compare_setting_key_type compare_setting_key(const setting_key & a, const setting_key & b) {
        if ( a.name != b.name) 
            return a_different_than_b; // not the same setting
        if ( a.setting_mode != b.setting_mode) 
            return a_different_than_b; // not the same mode (After != Before)
        
        bool a_includes_b_config = a.config.path().is_ascendant_of( b.config.path());
        bool b_includes_a_config = b.config.path().is_ascendant_of( a.config.path());

        bool a_includes_b_compilers = a.compiler.is_ascendant_of( b.compiler);
        bool b_includes_a_compilers = b.compiler.is_ascendant_of( a.compiler);

        if ( a_includes_b_config && b_includes_a_config && a_includes_b_compilers && b_includes_a_compilers)
            return a_equals_b;

        if ( a_includes_b_config && a_includes_b_compilers)
            return a_includes_b;

        if ( b_includes_a_config && b_includes_a_compilers)
            return b_includes_a;

        if ( a_includes_b_config && b_includes_a_compilers)
            return a_intersects_with_b; 

        if ( b_includes_a_config && a_includes_b_compilers)
            return a_intersects_with_b;

        return a_different_than_b;
    }

    /** 
    returns true if a has a higher priority than b.
    
    Call this only when a intersects with b, to wee which has a higher priority (importance)
    */
    bool has_higher_priority(const setting_key & a, const setting_key & b) {
        // the only way to end up calling this function is if the two keys intersect
        assert( compare_setting_key(a, b) == a_intersects_with_b);

        /** 
            Priorities:
            - Compiler over Configuration
                (example "All Configs/after/VC71" is higher than "Debug/after/All compilers"
        */
        bool a_includes_b_compilers = a.compiler.is_ascendant_of( b.compiler);
        bool b_includes_a_compilers = b.compiler.is_ascendant_of( a.compiler);
        // either A includes B compilers or B includes A compilers (they can't be equal, nor completely different)
        assert ( a_includes_b_compilers == !b_includes_a_compilers);

        return b_includes_a_compilers;
    }

    /** 
    returns true if this is a fixed setting: for a fixed compiler and a fixed configuration
    */
    bool is_fixed(const setting_key & key) {
        bool has_fixed_config = key.config != configuration::root();
        bool has_all_compilers =  (key.compiler.string() == "root/C++");
        return has_fixed_config && !has_all_compilers;
    }

    bool setting_keys_intersect(const setting_key & a, const setting_key & b) {
        return compare_setting_key(a, b) != a_different_than_b;
    }
}

/** 
    From multiple possible setting values for one setting key, returns
    the lowest-common denominator.

    That is, the setting value that matches all setting keys. If there is no such thing,
    it returns a mixed setting value
*/
setting_value logical_path_setting_values::value_for_setting_key(
            const setting & set, const setting_key & key, const setting_info::coll & vals) {
    if ( vals.empty() ) 
        return setting_value( set.default_val);
    /** Priorities: see has_higher_priority above */

    // when config or compiler are not fixed, we need to see if:
    // - key matches all perfectly 
    // - if all the setting values are the same (all values in 'vals' collection are the same).
    // If any of these is not true, it's a mixed setting value

    // find best match for this key
    typedef setting_info::coll coll;
    typedef std::pair<setting_key,setting_value> value_type;
    value_type result = *vals.begin();
    bool any_better_match = true; 
    while ( any_better_match) {
        any_better_match = false;
        for ( crange<const coll> r(vals); r; ++r) {
            // when finding best match for this key, anything that is below it in the hierarchy,
            // is simply ignored.
            //
            // Example: when calculating value for "All configs/before/MSVC", I'll ignore "Debug/before/VC71"
            if ( compare_setting_key(key, r->first) == a_includes_b)
                continue;

            compare_setting_key_type compare_result = compare_setting_key(r->first, result.first); 
            bool better_match = compare_result == b_includes_a;
            if ( !better_match)
                if ( compare_result == a_intersects_with_b)
                    // if the *r has higher priority, we'll take it
                    better_match = has_higher_priority(r->first, result.first);

            if ( better_match) result = *r;
            if ( better_match) any_better_match = true;
        }
    }

    // when config and compiler are fixed, we must return something (not mixed!)
    //
    // this is because when compiling, for each setting, we need a clear (fixed) value, 
    // no matter how many values go in the mix.
    if ( is_fixed(key) )
        return result.second;

    // filter out all of result's ascendants. This is because result overrides them.
    coll filtered_vals = vals;
    for ( crange<coll> r(filtered_vals); r; ) {
        bool is_ascendant = compare_setting_key(result.first, r->first) == b_includes_a;
        if ( is_ascendant)
            r = rng::erase_current(filtered_vals, r);
        else 
            ++r;
    }


    // not fixed. In this case, if all values are the same, we return it
    //            Otherwise, it's a mixed value
    setting_value sample = filtered_vals.begin()->second;
    for ( crange<const coll> r(filtered_vals); r; ++r)
        if ( r->second != sample) 
            return setting_value( setting_value::mixed() );
    return sample;
}


/** 
    Returns a setting' value

    You also pass the setting itself. This is useful in case we don't have a value for this setting,
    and we need to return the default.
*/
fixed_setting_value logical_path_setting_values::get_value(const setting & set, const setting_key & key) const {
    assert ( set.name.normalized == key.name); // the setting should match the key...
    BOOST_LOG(app) << "get setting for " << m_dir.string();
    BOOST_LOG(app) << "get setting for " << key;
    scoped_lock lk(m_cs);
    refresh();

    if ( !rng::coll_find(m_settings, set.name.normalized) ) {
        // this setting is not set - not here, and not in the ascendants
        fixed_setting_value def_val;
        def_val.current.value( set.default_val);
        def_val.inherited.value( set.default_val);

        if ( !set.is_inheritable) def_val.inherited = setting_value::mixed() ; // not inheritable...
        BOOST_LOG(app) << "setting not found, using default " << def_val;
        return def_val;
    }

    setting_info info = rng::coll_find(m_settings, set.name.normalized)->second;

    // for this specific key, what do I have, and what have I inherited?
    typedef setting_info::coll coll;
    coll mine, inherited;
    for ( crange<const coll> r(info.m_values); r; ++r)
        if ( setting_keys_intersect(r->first, key) ) mine.insert(*r);
    for ( crange<const coll> r(info.m_inherited); r; ++r)
        if ( setting_keys_intersect(r->first, key) ) inherited.insert(*r);

    fixed_setting_value result;
    result.is_overridden = true;
    result.current = value_for_setting_key(set, key, mine);
    result.inherited = value_for_setting_key(set, key, inherited);
    if ( mine.empty()) {
        // we don't have this value, our parent does
        result.current = result.inherited;
        result.is_overridden = false;
    }

    if ( !set.is_inheritable) {
        // example "is project" is not inheritable
        result.inherited = setting_value::mixed();
        result.is_overridden = true;
        if ( mine.empty())
            result.current = set.default_val;
    }

    BOOST_LOG(app) << "setting for " << key << " is " << result;
    return result;
}

/** sets a setting' value
*/
void logical_path_setting_values::set_value(const setting & set, const setting_key & key, fixed_setting_value val) {
    assert ( set.name.normalized == key.name); // the setting should match the key...
    BOOST_LOG(app) << "set setting for " << m_dir.string();
    BOOST_LOG(app) << "set setting " << key << " to " << val;
    scoped_lock lk(m_cs);
    refresh();
    // look at whether it's inherited or not, and how it used to be!
    fixed_setting_value old = get_value(set, key);
    if ( old == val) {
        BOOST_LOG(app) << "setting is same as before";
        return; // the same value...
    }

    // FIXME (bug) if I set, in Debug mode, User interface to GUI (while the Release is set to console),
    //             when I go to "All", it shows "GUI". It should not do this.

    // FIXME (future) When I'll allow for selection "Multiple configs" and "Multiple compilers"
    // when setting a value for such a thing, this simply means:
    // setting this value for each config/compiler.
    // Thus, it will override any previous such setting, if any.

    bool is_inherit_from_parent = set.is_inheritable && (val.current == val.inherited) && !val.is_overridden;
    if ( crange<setting_coll> cur_set = rng::coll_find(m_settings, set.name.normalized) ) {
        // we might already have values for this setting.

        // we will first delete any values that are overridden by this 'key'
        typedef setting_info::coll coll;
        for ( crange<coll> r(cur_set->second.m_values); r;) {
            compare_setting_key_type compare = compare_setting_key(key, r->first);
            if ( compare == a_includes_b || compare == a_equals_b) {
                BOOST_LOG(app) << "overrides " << r->first << "/ " << r->second;
                r = rng::erase_current(cur_set->second.m_values, r);
            }
            else
                ++r;
        } 

        // in other words, if a_includes_b , a overrides b.
        if ( is_inherit_from_parent)
            ; // we're using the parent's defaults - no need to do anything
        else
            cur_set->second.m_values.insert( std::make_pair(key, val.current) );
    } 
    else {
        BOOST_LOG(app) << "new setting";
        // we don't yet hold any value for this setting...
        if ( is_inherit_from_parent)
            // we're using the defaults - no need to do anything
            ;
        else {
            setting_info new_info;
            new_info.m_values.insert( std::make_pair(key, val.current) );
            m_settings[ set.name.normalized ] = new_info;
        }
    }

    ++m_change_id;
}





