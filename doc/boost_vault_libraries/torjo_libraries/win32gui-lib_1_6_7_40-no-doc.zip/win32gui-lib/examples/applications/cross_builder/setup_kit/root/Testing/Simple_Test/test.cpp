
// this is a simple test file, in order to see if you've
// properly set up your compiler

#include <string>
#include <iostream>

int main() {
   std::string str = "Hello World";
   std::cout << str;
}

