

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

#include "tree/tree.h"

/////////////////////////////////////////////////////////////////////////////////////////////////
// Walking through trees

namespace tree {
/** 
    how to walk though a tree
*/
typedef enum walk_type {
    children_first,
    parent_first
};

namespace detail {
    template< class item_ref, class item_type, class children_array, class pred, class array>
    void tree_for_each_children_first(item_ref t, pred p, array & ascendants) {
        ascendants.push_back( &t);
        for ( crange< children_array > r(t.children); r; ++r)
            tree_for_each_children_first<item_ref, item_type, children_array>( *r, p, ascendants);
        ascendants.pop_back();
        p(t, (const array&)ascendants);
    }


    template< class item_ref, class item_type, class children_array, class pred, class array>
    void tree_for_each_parent_first(item_ref t, pred p, array & ascendants) {
        p(t, (const array&)ascendants);
        ascendants.push_back( &t);
        for ( crange< children_array > r(t.children); r; ++r)
            tree_for_each_parent_first<item_ref, item_type, children_array>( *r, p, ascendants);
        ascendants.pop_back();
    }
}


/** 
    Walks through a tree, running a predicate for each node.

    The predicate has this form:

    void pred([const] item<..> & node, const std::vector<item> & ascendants);
*/
template< walk_type walk, class e, class pred>
void for_each(item<e> & t, pred p) {
    typedef item<e> item_type;
    std::vector<item_type*> ascendants;

    typedef typename item_type::array array;
    if ( walk == children_first) 
        detail::tree_for_each_children_first< item_type&, item_type, array > (t, p, ascendants);
    else if ( walk == parent_first)
        detail::tree_for_each_parent_first< item_type&, item_type, array >(t, p, ascendants);
    else
        assert(false);
}


template< walk_type walk, class e, class pred>
void for_each(item<e> const & t, pred p) {
    typedef item<e> nonconst_item_type;
    typedef item<e> const item_type;
    std::vector<item_type*> ascendants;

    typedef const typename nonconst_item_type::array array;
    if ( walk == children_first) 
        detail::tree_for_each_children_first< item_type&, item_type, array> (t, p, ascendants);
    else if ( walk == parent_first)
        detail::tree_for_each_parent_first< item_type&, item_type, array>(t, p, ascendants);
    else
        assert(false);
}



template< class e, class pred>
void for_each(item<e> & t, pred p) {
    for_each<children_first, e>(t, p);
}

template< class e, class pred>
void for_each(item<e> const & t, pred p) {
    for_each<children_first, e>(t, p);
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// sorting trees

namespace sort_ {
    struct by_name {
        template<class e> bool operator()(const item<e> & first, const item<e> & second) {
            return first.name() < second.name();
        }
    };
}

namespace detail {
    template<class pred> struct do_sort {
        do_sort(pred p) : p(p) {}
        template<class e, class array> void operator()(item<e> & val, const array&) {
            std::sort(val.children.begin(), val.children.end(), p);
        }
        pred p;
    };
}

template<class e> void sort(item<e> & t) {
    for_each(t, detail::do_sort<sort_::by_name>( sort_::by_name() ) );
}

template<class e, class sort_pred> void sort(item<e> & t, sort_pred p  ) {
    for_each(t, detail::do_sort<sort_pred>(p) );
}

/////////////////////////////////////////////////////////////////////////////////////////////////
// Merging trees

namespace merge_ {
    struct keep_first {
        template<class e> item<e> operator()(const item<e> & first, const item<e> & second) {
            return first;
        }
    };
}

namespace detail {
    template<class e> struct append_to_item {
        typedef item<e> item_type;
        append_to_item(item_type & val) : m_item(val) {}
        item_type &m_item;

        typedef std::vector<const item_type*> array;
        void operator()(const item_type & val, const array & ascendants) {
            if ( ascendants.empty() ) return; // ignore root
            item_type * cur_item = &m_item;
            item_type * child;
            for ( crange<const array> r(ascendants.begin()+1, ascendants.end()); r; ++r) {
                item_type * child = cur_item->child_by_name((*r)->name());
                assert(child);
                cur_item = &*child;
            }

            child = cur_item->child_by_name(val.name());
            if ( child)
                // node already exists
                cur_item = &*child;
            else 
                // node needs to be inserted
                cur_item->children.push_back( val);
        }
    };
}

/** 
merges the two trees, and returns the merged tree

@remarks 
it sorts each tree first, and the resulting tree is sorted as well.
*/
template<class e> item<e> sorted_merge(const item<e> & first, const item<e> & second) {
    // FIXME (future) extra param: merge_pred p = merge_::keep_first()
    item<e> result = first;
    sort(result); 
    for_each<parent_first>(second, detail::append_to_item<e>(result) );
    sort(result); 
    return result;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////
// Filtering trees

namespace detail {
    
    template<class e, class pred> struct do_filter {
        do_filter(item<e> & result, pred p) : result(result), p(p) {}
        item<e> & result; 
        pred p;

        typedef std::vector< const item<e>* > array;
        void operator()(const item<e> & val, const array & ascendants) {
            if ( ascendants.empty() ) return; // it's the root

            item<e> * cur_dir = &result;
            // ... ignore the root
            for ( crange<const array> r(ascendants.begin()+1,ascendants.end()); r; ++r) 
                if ( p(**r) ) {
                    std::string name = (*r)->name();
                    // it's a parent, should already exist
                    assert( cur_dir->child_by_name(name) );
                    cur_dir = cur_dir->child_by_name(name);
                }
                else
                    return; // is filtered out

            if ( !p(val) )
                return; // filtered out
            std::string name = val.name();
            // should not exist yet...
            assert( !cur_dir->child_by_name(name) );
            item<e> new_val( name, val.info );
            cur_dir->children.push_back( new_val);
        } 
    };
}

/** 
    filters a tree. Returns a tree, whose items all satisfy the given predicate.

    Note that if an item does not satisfy a predicate, that item and all its descendants
    will be filtered out.

    The root item is always returned, and it does not have to satisfy the predicate.
*/
template<class e, class pred> item<e> filter(const item<e> & val, pred p) {
    item<e> result( val.name(), val.info );
    for_each<parent_first>(val, detail::do_filter<e,pred>(result, p) );
    return result;
}



} // namespace tree
