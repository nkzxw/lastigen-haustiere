

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#pragma once

bool is_setting_name_valid(const std::string & name);
bool is_compiler_meta_dir_name_valid(const std::string & name);

std::string normalized_path_name(std::string name);

std::string normalized_name(std::string name);


struct name_pair;
bool operator==(const name_pair & f, const name_pair & s);
bool operator==(const name_pair & f, const std::string & s);
bool operator==(const std::string & s, const name_pair & f);



/** 
    @brief A name pair, consisting of a name and a user-friendly name

    Always, setting/enumeration names consist of two names:
    - internal name
    - user-friendly name

 @remarks
    If normalized_name(user_friendly) == normalized, <br>
    then this is string value. 

    FIXME In the future, I should have a separate class, for holding values (entered by the user).
    Each such value, should know its type (enum,string,etc.) This is very important for comparisons.

*/
struct name_pair {
    name_pair( const std::string & first = "") : normalized(first),user_friendly(first), original_name(first) {
        normalized = normalized_name(normalized);
    }

    name_pair( const std::string & first, const std::string & second) : normalized(first),user_friendly(second), original_name(first) {
        normalized = normalized_name(normalized);
    }
    // the (internal) name 
    std::string normalized;
    // the user-friendly name
    std::string user_friendly;

private:
    friend bool operator==(const name_pair & f, const name_pair & s);
    friend bool operator==(const name_pair & f, const std::string & s);
    friend bool operator==(const std::string & s, const name_pair & f);

    bool is_string_value() const;

private:
    // (for debug only) - the original internal name, unnormalized
    std::string original_name;
};
bool operator==(const name_pair & f, const name_pair & s);
bool operator==(const name_pair & f, const std::string & s);
bool operator==(const std::string & s, const name_pair & f);

inline bool operator!=(const name_pair & f, const name_pair & s)    { return !(f == s); }
inline bool operator!=(const name_pair & f, const std::string & s)  { return !(f == s); }
inline bool operator!=(const std::string & s, const name_pair & f)  { return !(f == s); }

// ... for sorting
bool operator<(const name_pair & f, const name_pair & s);


std::ostream& operator<<(std::ostream& out, const name_pair & val);
std::istream& operator>>(std::istream& in, name_pair & val);


name_pair split_into_name_and_userfriendly_name(const std::string & name);

name_pair name_from_user_entered_string(const std::string & name);
