// Persist Settings Library
//
// Copyright 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

// configuration.cpp: implementation of the configuration class.
//
//////////////////////////////////////////////////////////////////////

#include "configuration.h"
#include "setting_storage.h"
#include "file_setting_storage.h"
#include "setting.h"
#include <algorithm>
#include <assert.h>

using persist::detail::scoped_lock;

namespace persist {

namespace {
    // make sure default configuration is initialized before main
    struct configuration_init {
        configuration_init() { configuration::def(); }
    } s_init;

    // converts a value to lower-case
    std::string locase( const std::string & str) {
        std::string lo;
        lo.resize( str.length());
        std::transform( str.begin(), str.end(), lo.begin(), tolower);
        return lo;
    }

    struct do_delete {
        template< class T> void operator()( T & val) {
            delete val.second;
        }
    };
}

configuration & configuration::def() {
    def_cfg obj;
    static configuration d( obj);
    return d;
}


// constructor for default configuration
configuration::configuration( const configuration::def_cfg &) {
    static idx = 0;
    ++idx;
    if ( idx > 1)
        // we have entered this constructor recursively !!!
        // make sure you've implemented on_initialize_default_config correctly!
        assert(false);

    on_initialize_default_config( *this);
}



configuration::configuration() {
}


configuration::~configuration() {
    save();
    std::for_each( m_storages.begin(), m_storages.end(), do_delete() );
}

// resolves the name: finds the storage place where this propery belongs to, and its name there
//
// note: all names are case-insensitive
void configuration::resolve_name( const std::string & name, std::string & place, std::string & sett_name) const {
    // name should not be empty, and should not begin with "." ('.' is a separator)
    assert( !name.empty() && name[0] != '.');
    place.erase();
    sett_name.erase();
    std::string lo_name = locase(name);

    scoped_lock lock(m_cs);
    // before doing any operation, make sure you have at least one storage to persist settings to
    assert( !m_storages.empty() );
    coll::const_reverse_iterator first = m_storages.rbegin(), last = m_storages.rend();
    while ( first != last) {
        const std::string & storage_name = first->first;
        if ( lo_name.size() > storage_name.size() ) {
            // name can be a setting in storage name
            int pos = (int)lo_name.find( storage_name);
            if ( pos == 0) {
                int end = (int)storage_name.size();
                if ( (lo_name[end] == '.') || storage_name.empty() ) {
                    // name is a setting in storage name;
                    // note: all names are settings into the empty storage name
                    place = storage_name;
                    sett_name = end > 0 ? lo_name.substr( end + 1) : lo_name;
                    return;
                }
            }
        }
        ++first;
    }

    // the name does not exist in any storage
    sett_name = name;
}



void configuration::get_setting( const std::string & place, const std::string & sett_name, std::string & value, const err::handler & h ) {
    scoped_lock lock(m_cs);
    // before doing any operation, make sure you have at least one storage to persist settings to
    assert( !m_storages.empty() );
    coll::iterator found = m_storages.find( place);
    if ( found != m_storages.end() ) {
        std::string error;
        found->second->get_setting( sett_name, value, error);
        if ( !error.empty() )
            h.on_error( &value, error);
    }
    else
        h.on_error( &value, "(get) storage not found");
}

void configuration::set_setting( const std::string & place, const std::string & sett_name, const std::string & value, const err::handler & h ) {
    scoped_lock lock(m_cs);
    // before doing any operation, make sure you have at least one storage to persist settings to
    assert( !m_storages.empty() );
    coll::iterator found = m_storages.find( place);
    if ( found != m_storages.end() ) {
        std::string error;
        found->second->set_setting( sett_name, value, error);
        if ( !error.empty() )
            h.on_error( 0, error);
    }
    else
        h.on_error( 0, "(set) storage not found");
}


void configuration::add_storage(const std::string &storage_name, setting_storage *store) {
    scoped_lock lock(m_cs);
    // this storage should not exist yet
    assert( m_storages.find(storage_name) == m_storages.end() );
    m_storages[ storage_name] = store;
}

// copies this configuration to a file
//
void configuration::copy_to_file(const std::string &file_name,  const err::handler & h ) {
    configuration file;
    file.add_storage( "", new file_setting_storage(file_name, open_writable, load_at_start, save_on_request/* don't rewrite on each modify */) );
    copy_into( file, h);
}

// copies this configuration into another one 
//
// in case the other configuration already contains some settings,
// they will be overwritten (in case some settings have names that are not
// found in the current configuration, their values will remain unchanged)
void configuration::copy_into(configuration &other, const err::handler & h ) {
    scoped_lock lock(m_cs);
    coll::iterator first = m_storages.begin(), last = m_storages.end();
    while ( first != last) {
        typedef std::map<std::string,std::string> vals_coll;
        vals_coll vals;
        std::string current_err;
        first->second->enum_settings( vals, current_err);
        if ( !current_err.empty() ) h.on_error( 0, current_err);

        vals_coll::iterator first_val = vals.begin(), last_val = vals.end();
        while ( first_val != last_val) {
            // find out the name of the setting, within the other configuration
            // (each setting we're enumerating, is relative to the *first storage)
            std::string full_name = first_val->first;
            if ( !first->first.empty())
                full_name = first->first + "." + full_name;

            std::string place, sett_name;
            other.resolve_name( full_name, place, sett_name);
            other.set_setting( place, sett_name, first_val->second, h);
            ++first_val;
        }
        ++first;
    }
    other.save( h);
}


// copies this configuration into another one 
//
// in case some settings already exist in the other configuration, they WILL NOT be overwritten
// (only new settings are added into the other configuration)
void configuration::copy_into_no_overwrite(configuration &other, const err::handler & h ) {
    scoped_lock lock(m_cs);
    coll::iterator first = m_storages.begin(), last = m_storages.end();
    while ( first != last) {
        typedef std::map<std::string,std::string> vals_coll;
        vals_coll vals;
        std::string current_err;
        first->second->enum_settings( vals, current_err);
        if ( !current_err.empty() ) h.on_error( 0, current_err);

        vals_coll::iterator first_val = vals.begin(), last_val = vals.end();
        while ( first_val != last_val) {
            // find out the name of the setting, within the other configuration
            // (each setting we're enumerating, is relative to the *first storage)
            std::string full_name = first_val->first;
            if ( !first->first.empty())
                full_name = first->first + "." + full_name;

            std::string place, sett_name;
            other.resolve_name( full_name, place, sett_name);
			
			// FIXME in a future version, maybe have an extra member function: has_setting
			std::string get_err, ignore;
			other.get_setting( place, sett_name, ignore, err::append_err(get_err) );
			if ( !get_err.empty() )
				// an error occured - we assume the setting did not exist
				other.set_setting( place, sett_name, first_val->second, h);
            ++first_val;
        }
        ++first;
    }
    other.save( h);
}



// saves this configuration to the underlying storages
// (useful when any of the storages has a caching mechanism)
void configuration::save(const err::handler & h) {
    scoped_lock lock(m_cs);
    coll::iterator first = m_storages.begin(), last = m_storages.end();
    while ( first != last) {
        first->second->save(h);
        ++first;
    }
}

// removes one storage from this configuration
void configuration::remove_storage( const std::string & storage_name) {
    scoped_lock lock(m_cs);
    coll::iterator found = m_storages.find(storage_name);
    if ( found != m_storages.end() ) {
        found->second->save();
        delete found->second;
        m_storages.erase( found);
    }
}

// removes all storages from this configuration
void configuration::remove_all_storages() {
    scoped_lock lock(m_cs);
    save();
    std::for_each( m_storages.begin(), m_storages.end(), do_delete() );
    m_storages.clear();
}

} // namespace persist




