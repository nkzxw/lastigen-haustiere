
// Utility Library
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
#pragma once

/** 
    the results, after running a command
*/
struct run_sys_command_results {
    run_sys_command_results () : spent_time_ms(0), processor_time_ms(0), successful(false) {}

    // the time that was spent : from the starting of the command, until its end
    unsigned int spent_time_ms;
    // what was reported as processor spent time
    unsigned int processor_time_ms;
    bool successful;
};


run_sys_command_results run_sys_command_as_hidden(std::string cmd_line, fs::path home_dir, int timeout_ms = 10 * 60 * 1000);
