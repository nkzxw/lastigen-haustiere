

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "stdafx.h"
// select_builds_dlg.cpp
#include "select_builds_dlg.h"
#include <win32gui/event_handler.hpp>

#include "setting/computer.h"
#include "ui/build_statistics/show_compare_results_dlg.h"
#include "ui/build_statistics/build_statistics_dlg.h"

#include "build_statistics/build_statistics.h"


#include "win32gui_res/build_statistics_select.hpp"
#include "win32gui_res/build_statistics.hpp"
#include "win32gui_res/bitmaps.hpp"
using namespace win32::gui::res_id;


using namespace win32::gui;
using namespace boost::rangelib;
using namespace build_statistics;

namespace {
    // images for nodes
    namespace node {
        enum type {
            compiler = 1,
            dir = 3
        };
    }

    void build_dirs_builds_array_to_wnd(const dir_builds_array & dirs, wnd<tree_ctrl> t) {
        t->del_all_items();

        for ( crange<const dir_builds_array> r_dir(dirs); r_dir; ++r_dir) {
            HTREEITEM dir_item = t->add_root_item( tv_item().text(r_dir->dir.string()).image(node::dir) );
            for ( crange<const dir_builds::builds_array> r_build(r_dir->builds); r_build; ++r_build) {
                std::string build_text = friendly_time(r_build->build_time) 
                    + ", with " 
                    + compiler_friendly_name(r_build->compiler)
                    + " (" + configuration(r_build->config).friendly_name() + ")";
                t->add_item( dir_item, tv_item().text(build_text).image(node::compiler) );
            }
        }

        // ain't life fun? If the tree contains only one root item, with some subitems, 
        // unless I do this, they simply won't be shown
        t->expand(t->root());
        t->collapse(t->root());
    }

    HTREEITEM tree_child_at_idx(wnd<tree_ctrl> t, HTREEITEM parent, int child_idx) {
        int cur_idx = 0;
        for ( HTREEITEM child = t->first_child(parent); child; child = t->next_sibling(child), ++cur_idx )
            if ( cur_idx == child_idx)
                return child;

        PWC_THROW std::logic_error("tree index too big!");
    }
}

struct select_builds_dlg_handler : event_handler<select_builds_dlg_handler, select_builds_dlg> {
    // the directories where there have been builds, 
    // and their statistics
    dir_builds_array m_build_dirs;

    image_list<owned> m_images;
    select_builds_dlg_handler() : m_images( bitmap_::explorer_nodes, 16) {}

    void on_full_create() {
        m_from->images( tree_ctrl_::images::normal, m_images);
        m_to->images( tree_ctrl_::images::normal, m_images);

        load_dir_build_tree(m_build_dirs);

        build_dirs_builds_array_to_wnd( m_build_dirs, m_from );
        build_dirs_builds_array_to_wnd( m_build_dirs, m_to );

        using persist::setting;
        bool is_from_cached = setting<bool>("gui.build_statistics.is_from_cached");
        if ( is_from_cached) {
            int dir_idx = setting<int>("gui.build_statistics.dir_from");
            int build_idx = setting<int>("gui.build_statistics.build_from");
            try_select_build( m_from, dir_idx, build_idx);
        }
        bool is_to_cached = setting<bool>("gui.build_statistics.is_to_cached");
        if ( is_to_cached) {
            int dir_idx = setting<int>("gui.build_statistics.dir_to");
            int build_idx = setting<int>("gui.build_statistics.build_to");
            try_select_build( m_to, dir_idx, build_idx);
        }
    }

    handle_event on_view_left_only() {
        if ( m_from->sel() == 0) {
            ::MessageBeep(-1);
            return event_handled_early; // nothing selected
        }
        wnd<show_compare_results_dlg> w = parent()->sub_wnd<show_compare_results_dlg>();
        w->show_single( get_compare_key( m_from ));
        parent<build_statistics_dlg>()->child<tab_dialog>(build_statistics_::m_tabdialog1_::id)->sel(1);

        return event_ex<m_view_left_only_::ev::clicked>().HANDLED_BY(&me::on_view_left_only);
    }


    handle_event on_compare_lr() {
        if ( m_from->sel() == 0) {
            ::MessageBeep(-1);
            return event_handled_early; // nothing selected
        }

        wnd<show_compare_results_dlg> w = parent()->sub_wnd<show_compare_results_dlg>();
        if ( m_to->sel() != 0 )
            w->show_compare( get_compare_key( m_from ), get_compare_key( m_to ) );
        else
            // in case the user has selected only something in the left pane...
            w->show_single( get_compare_key( m_from ));
        parent<build_statistics_dlg>()->child<tab_dialog>(build_statistics_::m_tabdialog1_::id)->sel(1);

        return event_ex<m_compare_lr_::ev::clicked>().HANDLED_BY(&me::on_compare_lr);
    }

    handle_event on_from_change() {
        std::pair<int,int> from_id = dir_and_build_key_indexes( m_from );

        using persist::setting;
        setting<bool>("gui.build_statistics.is_from_cached") = true;
        setting<int>("gui.build_statistics.dir_from") = from_id.first;
        setting<int>("gui.build_statistics.build_from") = from_id.second;
        return event_ex<m_from_::ev::sel_change>().HANDLED_BY(&me::on_from_change);
    }

    handle_event on_to_change() {
        std::pair<int,int> to_id = dir_and_build_key_indexes( m_to );

        using persist::setting;
        setting<bool>("gui.build_statistics.is_to_cached") = true;
        setting<int>("gui.build_statistics.dir_to") = to_id.first;
        setting<int>("gui.build_statistics.build_to") = to_id.second;
        return event_ex<m_to_::ev::sel_change>().HANDLED_BY(&me::on_to_change);
    }


private:
    // if this build exists, selects it
    void try_select_build(wnd<tree_ctrl> t, int dir_idx, int slot_idx) {
        int dir_idx_in_tree = -1, build_idx_in_tree = -1;

        for ( crange<const dir_builds_array> r_dir(m_build_dirs); r_dir; ++r_dir)
            if ( r_dir->dir_idx == dir_idx) 
                for ( crange<const dir_builds::builds_array> r_build(r_dir->builds); r_build; ++r_build)
                    if ( r_build->slot_idx == slot_idx) {
                        // we have it...
                        dir_idx_in_tree = (int)(r_dir.begin() - m_build_dirs.begin());
                        build_idx_in_tree = (int)(r_build.begin() - r_dir->builds.begin());
                        break;
                    }

        if ( dir_idx_in_tree == -1) return; // we can't find this build entry...

        HTREEITEM dir_sel = tree_child_at_idx(t, 0, dir_idx_in_tree);
        HTREEITEM build_sel = tree_child_at_idx(t, dir_sel, build_idx_in_tree);
        t->sel(build_sel);
    }


    // returns the dir & build indexes of the currently selected item
    //
    // dir index    - the index of the current directory, in the VISUALLY SHOWN TREE
    // build index  - the index of the current build, as child of the dir index
    std::pair<int,int> dir_and_build_visual_indexes( wnd<tree_ctrl> t) {
        HTREEITEM build_type = t->sel();
        assert(build_type); // we should have a selection!
        HTREEITEM dir = t->parent_item(build_type);
        if ( dir == 0) {
            // the directory is the one selected - Get the latest build
            dir = build_type;
            build_type = t->first_child(dir);
        }
        else 
            assert( t->parent_item(dir) == 0); // we should have only two levels: Dir & Build type

        // search for the index of the directory
        int dir_idx_in_tree = 0;
        for ( HTREEITEM top = t->root(); top; top = t->next_sibling(top), ++dir_idx_in_tree)
            if ( top == dir) break;
        // search for the index of the build type
        int type_idx_in_tree = 0;
        for ( HTREEITEM type_item = t->first_child(dir); type_item; type_item = t->next_sibling(type_item), ++type_idx_in_tree)
            if ( type_item == build_type) break;

        // getting build info
        assert( dir_idx_in_tree < (int)m_build_dirs.size());  // should be a valid directory
        const dir_builds & dir_info = m_build_dirs[dir_idx_in_tree];
        assert( type_idx_in_tree < (int)dir_info.builds.size());

        return std::make_pair( dir_idx_in_tree, type_idx_in_tree);
    }

    // returns the dir & build indexes, that uniquely identify the statistics of a build
    std::pair<int,int> dir_and_build_key_indexes( wnd<tree_ctrl> t) {
        std::pair<int,int> idx = dir_and_build_visual_indexes(t);

        int dir_idx_in_tree = idx.first;
        int type_idx_in_tree = idx.second;
        assert( dir_idx_in_tree < (int)m_build_dirs.size());  // should be a valid directory
        const dir_builds & dir_info = m_build_dirs[dir_idx_in_tree];
        assert( type_idx_in_tree < (int)dir_info.builds.size());
        dir_build_key build_info = dir_info.builds[type_idx_in_tree];

        return std::make_pair(dir_info.dir_idx, build_info.slot_idx);
    }


    // returns the build key, from one pane.
    build_statistics_key get_compare_key( wnd<tree_ctrl> t) {
        std::pair<int,int> idx = dir_and_build_visual_indexes(t);

        int dir_idx_in_tree = idx.first;
        int type_idx_in_tree = idx.second;
        assert( dir_idx_in_tree < (int)m_build_dirs.size());  // should be a valid directory
        const dir_builds & dir_info = m_build_dirs[dir_idx_in_tree];
        assert( type_idx_in_tree < (int)dir_info.builds.size());
        dir_build_key build_info = dir_info.builds[type_idx_in_tree];

        std::string prefix = str_stream() << "build.statistics." << dir_info.dir_idx << "." << build_info.slot_idx;
        build_statistics_key key(dir_info.dir, build_info.compiler, build_info.config, build_info.build_time, prefix);
        return key;
    }
};


select_builds_dlg::select_builds_dlg() {
    add_resizable_ctrl( m_view_left_only_::id, move_xy);
    add_resizable_ctrl( m_compare_lr_::id, move_xy);
}

select_builds_dlg::~select_builds_dlg() {
}

int select_builds_dlg::dialog_id() { return dialog_id_; }

