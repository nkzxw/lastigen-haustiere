
// Utility Library
//
// Copyright (C) 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
#pragma once



template<class func> void tree_ctrl_for_each(win32::gui::wnd<win32::gui::tree_ctrl> t, HTREEITEM start, func f) {
    for ( HTREEITEM child = t->first_child(start); child; child = t->next_sibling(child)) {
        f( t, child);
        tree_ctrl_for_each(t, child, f);
    }
}

template<class func> void tree_ctrl_for_each(win32::gui::wnd<win32::gui::tree_ctrl> t, func f) {
    tree_ctrl_for_each(t, 0, f);
}

inline void do_expand(win32::gui::wnd<win32::gui::tree_ctrl> t, HTREEITEM item) {
    t->expand(item);
}
inline void do_check(win32::gui::wnd<win32::gui::tree_ctrl> t, HTREEITEM item) {
    t->chk_state(item, win32::gui::tree_ctrl_::chk_state::checked);
}

