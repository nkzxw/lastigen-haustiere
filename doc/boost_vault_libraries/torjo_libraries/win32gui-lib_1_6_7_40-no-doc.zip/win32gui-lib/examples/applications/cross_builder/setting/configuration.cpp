

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\configuration.h"

// FIXME configuration name - should be limited. For instance, it should contain only 
//       characters that are allowed for file names
// (example: used in creating the 'build path')

configuration::configuration(const std::string & path) {
    m_path = normalized_name(path);
    m_friendly_name = tree_path_name(path).last_node();
    // FIXME I might allow renaming the configurations ???? TOTHINK If I do allow it,
    //       it should be held separately from the path - which always uniquely identifies a config.
}

configuration::~configuration(void)
{
}

bool operator==(const configuration & f, const std::string & name) {
    return f.path() == normalized_name(name);
}
bool operator==(const std::string & name, const configuration & f) {
    return f.path() == normalized_name(name);
}

bool operator==(const configuration & f, const configuration & s) {
    return f.m_path == s.m_path;
}

configuration configuration::root() {
    return "root/All";
}

tree_path_name configuration::path() const {
    return m_path;
}
std::string configuration::friendly_name() const {
    // FIXME friendly name must be unique. This is because when doing a build, the last part
    //       will be the friendly configuration name
    return m_friendly_name;
}


configuration debug_config() {
    return "root/All/Debug";
}

configuration release_config() {
    return "root/All/Release";
}



