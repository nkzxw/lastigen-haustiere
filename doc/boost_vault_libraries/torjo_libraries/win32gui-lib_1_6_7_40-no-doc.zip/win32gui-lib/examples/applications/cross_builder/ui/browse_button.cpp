

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\browse_button.h"
#include "shlobj.h"
#include "Commdlg.h"

namespace {
    std::string browse_for_folder(const std::string & title, HWND owner, UINT flags = BIF_DONTGOBELOWDOMAIN | BIF_EDITBOX | BIF_NEWDIALOGSTYLE) {
        OleInitialize(0);
        BROWSEINFO info =  { 0 };
        info.hwndOwner = owner;
        info.pidlRoot = 0;
        info.lpszTitle = title.c_str();
        info.ulFlags = flags;
        info.lpfn = 0;
        info.lParam = 0;
        info.iImage = 0;
        LPITEMIDLIST pidl = SHBrowseForFolder( &info);
        std::string folder;
	    if ( pidl) {
		    TCHAR szBuffer[MAX_PATH*2];
		    szBuffer[0] = '\0';
		    if (SHGetPathFromIDList(pidl, szBuffer))
                folder = szBuffer;

		    IMalloc *pMalloc = 0; 
		    if (SUCCEEDED(SHGetMalloc(&pMalloc)) && pMalloc) {  
			    pMalloc->Free(pidl);  
			    pMalloc->Release(); 
		    }
	    }
        OleUninitialize();
        return folder;
    }

    // returns the name of the opened file name. If the user pressed "Cancel",
    // it returns an empty string
    std::string dlg_get_open_file_name(const char * filter, HWND owner) {
        char buffer[2048] = { 0 };
        OPENFILENAME fn = { 0 };
        fn.lStructSize = sizeof(OPENFILENAME);
        fn.hwndOwner = owner;
        fn.lpstrFilter = filter;
        fn.lpstrFile = buffer;
        fn.nMaxFile = 2048;
        fn.Flags = OFN_EXPLORER | OFN_ENABLESIZING;
        bool opened = ::GetOpenFileName(&fn) != false;
        if ( !opened)
            buffer[0] = 0; // the user pressed cancel
        return buffer;
    }

    const char ALL_FILES[] = "All Files\0*.*\0";

}

using namespace win32::gui;

struct browse_button_handler : event_handler<browse_button_handler, browse_button> {
    browse_button_handler() {
        //FIXME
        int it = 0;
    }

    handle_event on_click(mark_event_not_handled) {
        if ( self->m_browse == browse_button::browse_::dir)
            browse_dir();
        else 
            browse_file();
        return command<ID_reflect, BN_CLICKED>().HANDLED_BY(&me::on_click);
    }

private:
    void browse_file() {
        HWND owner = parent()->raw_hwnd();
        std::string file = dlg_get_open_file_name(ALL_FILES, owner);
        if ( !file.empty() )
            self->on_after_browse(file);
        else
            self->on_cancel_browse();
    }

    void browse_dir() {
        HWND owner = parent()->raw_hwnd();
        std::string folder = browse_for_folder("Select Folder", owner);
        if ( !folder.empty() )
            self->on_after_browse(folder);
        else
            self->on_cancel_browse();
    }
};

std::string browse_button::reflection_name() { return "browse_button"; }


browse_button::browse_button(void) : m_browse(browse_::dir) {
}

browse_button::~browse_button(void)
{
}
