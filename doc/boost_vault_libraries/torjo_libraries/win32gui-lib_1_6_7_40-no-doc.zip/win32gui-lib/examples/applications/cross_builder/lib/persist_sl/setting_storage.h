// Persist Settings Library
//
// Copyright 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

// setting_storage.h: interface for the setting_storage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_setting_storage_H__510AB81D_1747_47EA_A19D_278D56A57933__INCLUDED_)
#define AFX_setting_storage_H__510AB81D_1747_47EA_A19D_278D56A57933__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning (disable :4786) // msvc

#include <map>
#include <string>

#include "persist_exception.h"

namespace persist {

/*
    Represents a storage when settings are persisted.
    You should note that a configuration can consist of more than one storage.

    Abstract class.
*/
class setting_storage  
{
protected:
    setting_storage() {}
public:
    virtual ~setting_storage() {}
    // saves all (modified) settings;
    // useful in case your storage class has a caching mechanism)
    virtual void save( const err::handler & h = err::ignore() ) = 0;
    // returns a setting as a string. In case an error appears, sets the 'error' string
    virtual void get_setting( const std::string & name, std::string & value, std::string & error) const = 0;
    // sets a setting. In case an error appears, sets the 'error' string
    virtual void set_setting( const std::string & name, const std::string & value, std::string & error) = 0;
    // enumerates all settings. If an error occurs, just sets the error string.
    //
    // note that some of the settings might still be valid, even if the error string is set
    // (for example, some of the registry settings cannot be read, while most of them were successfully read)
    virtual void enum_settings( std::map<std::string,std::string> & values, std::string & error) const {
        // by default, we cannot enumerate the settings
        values.clear();
        error = "cannot enumerate settings";
    }
};

} // namespace persist

#endif // !defined(AFX_setting_storage_H__510AB81D_1747_47EA_A19D_278D56A57933__INCLUDED_)
