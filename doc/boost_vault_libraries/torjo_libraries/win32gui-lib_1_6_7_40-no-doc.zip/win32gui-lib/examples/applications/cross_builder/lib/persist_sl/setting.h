// Persist Settings Library
//
// Copyright 2004 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.

// setting_t.h: interface for the setting_t class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_setting_t_H__1D803BAB_86B5_4795_B4A6_F4AF0C30FD7D__INCLUDED_)
#define AFX_setting_t_H__1D803BAB_86B5_4795_B4A6_F4AF0C30FD7D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning (disable :4786) // msvc

#include "configuration.h"

namespace persist {

    namespace detail {
        template< class T> void from_stream( std::istringstream & in, T & val) {
            in >> val;
        }
        // special case for string
        inline void from_stream( std::istringstream & in, std::string & val) {
            val = in.str();
        }
    }

/* 
    Represents a persistent setting_t from a configuration.
    (a configuration consists of zero-or-more setting_ts)


    get and set operations are very easy:

    using namespace persist;
    // get
    long left = setting<long>("app.wnd.left");

    // set
    setting<long>("app.wnd.left") = 15;

 Remarks:
    In case you have a custom error handler, and want to access its context,
    call the .err() member function

*/
template<class type, class err_handler = err::ignore >
class setting_t  
{
private:
    typedef setting_t<type,err_handler> self_type;
public:
    setting_t( const std::string & name, const err_handler & handler, configuration & conf = configuration::def() ) 
        : m_conf( conf), m_handler( handler) {
        m_conf.resolve_name( name, m_place, m_sett_name);
        
    }
    setting_t( const std::string & name, configuration & conf = configuration::def() ) 
        : m_conf( conf), m_handler( /* default constructed */) {
        m_conf.resolve_name( name, m_place, m_sett_name);
        
    }
    ~setting_t() {}

    operator type() const { return get(); }
    self_type & operator=( const type & val) {
        set( val);
        return *this;
    }
    // allow things like:
    // setting_t<long>("app.first") = setting_t<int>("app.second");
    // (note: first type is long, second type is int)
    template< class other_type, class other_err> self_type & operator=( const setting_t<other_type,other_err> & other) {
        set( other.get() );
        return *this;
    }
    // allow things like:
    // setting_t<int>("app.first") = setting_t<int>("app.second");
    self_type & operator=( const self_type & other) {
        set( other.get() );
        return *this;
    }
    
    const err_handler & err() const { return m_handler; }

    // explicit access
    type get() const {
        std::string val_str;
        m_conf.get_setting( m_place, m_sett_name, val_str, m_handler);
        std::istringstream in( val_str);
        type val = type();
        detail::from_stream( in, val);
        if ( in.fail() ) {
            m_handler.on_error( &val_str, "value cannot be converted to underlying type");
            if ( !val_str.empty() ) {
                // it was an error, and the handler reset the value
                std::istringstream in_err( val_str);
                detail::from_stream( in_err, val);
            }
        }
        return val;
    }

private:
    void set( const type & val) {
        std::ostringstream out;
        out << val;
        m_conf.set_setting( m_place, m_sett_name, out.str(), m_handler);
    }
private:
    // where this setting_t is persisted
    std::string m_place;
    // the real name of the setting_t
    std::string m_sett_name;
    // the configuration this setting_t belongs to
    configuration & m_conf;
    // handling error(s)
    err_handler m_handler;
};


// provide error-handler
template< class t, class e>
setting_t<t,e> setting( const std::string & name, const e & handler, configuration & conf = configuration::def()) {
    return setting_t<t,e>( name, handler, conf);
}

// use default error-handler
template< class t>
setting_t<t> setting( const std::string & name, configuration & conf = configuration::def()) {
    return setting_t<t>( name, conf);
}

// helper, allow things like:
// std::cout << setting_str("app.welcome_msg");
// std::string msg = setting_str("app.welcome_msg");
inline std::string setting_str( const std::string & name, configuration & conf = configuration::def()) {
    return setting_t<std::string>( name, conf);
}



} // namespace persist

#endif // !defined(AFX_setting_t_H__1D803BAB_86B5_4795_B4A6_F4AF0C30FD7D__INCLUDED_)

