

/*
    Copyright (c) 2004, John Torjo (john@torjo.com), 
    All rights reserved.

    http://www.torjo.com/cb/ 

    You are NOT ALLOWED to copy, use, sell and distribute the source code
    provided in this software, without specific prior written permission
    from the copyright owner(s).

    You are NOT ALLOWED to modify and distribute the modified source code
    provided in this software, without specific prior written permission 
    from the copyright owner(s).

    Neither the name of the author nor the names of other contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission from the copyright owner(s).

    THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL
    THE AUTHOR OR OTHER CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION).
*/

/* 
    Or, put in simple terms, this code is provided for demonstration purposes,
    especially, as a full-fledged application using the win32gui libraries.

    It makes heavy use of the following libraries:
    - win32gui              (http://www.torjo.com/win32gui/)
    - rangelib              (http://www.torjo.com/rangelib/)
    - Boost.Log lib         (http://torjo.com/code/logging-v131.zip)
    - Persistence Lib       (currently, no link available)
    - Other Boost libraries (http://www.boost.org/)
*/

#include "StdAfx.h"
#include ".\compiler_metadata.h"
#include "util/string_util.h"
#include "main/app.h"
#include "util/rw_string_io.h"
#include "tree/path.h"
#include "tree/io.h"
#include "tree/algorithm.h"

using namespace boost::rangelib;

compiler_metadata::dir_settings::dir_settings() : is_compiler_specific(false) {
}

compiler_metadata::compiler_metadata(fs::path dir_name, const std::string & name, metadata_ptr parent) 
        : m_dir_settings("root"), m_dir(dir_name), m_full_name(name), m_parent(parent) {
    load_settings();
    load_rules();
}

compiler_metadata::~compiler_metadata(void)
{
}


namespace {
    // FIXME right now, I'm not using compiler-specific dirs. Maybe I should remove them altogether
    bool is_not_compiler_specific(const tree::item<compiler_metadata::dir_settings> & dir) {
        return dir.info.is_compiler_specific == false;
    }

    void set_setting_attribute(setting & set, const std::string & attribute, const std::string & value) {
        if ( attribute == "isinheritable") {
            bool is = value != "0";
            set.is_inheritable = is;
        }
        else if ( attribute == "ishidden") {
            bool is = value != "0";
            set.is_hidden = is;
        }
        else if ( attribute == "isglobal") {
            bool is = value != "0";
            set.is_global = is;
        }

        else 
            BOOST_LOG(err) << "invalid attribute " << attribute;
    }
}

/** 
    Returns the tree of directories that contain metadata,
    for this compiler

    Each of these directories, can also contain settings.
*/
tree::item<> compiler_metadata::get_dir_tree( dir::type type ) const {
    scoped_lock lk(m_cs);

    // FIXME (future): for all compiler-specific dirs, make a special directory to hold them, like
    // "VC 7.1 specific", "gcc specific" ,etc.

    // take from parent as well, and merge.
    tree::item<> result = m_dir_settings;
    if ( type == dir::exclude_compiler_specific)
        result = tree::filter(m_dir_settings, is_not_compiler_specific);

    if ( m_parent)
        return tree::sorted_merge( result, m_parent->get_dir_tree(type) );
    return result;
}

namespace {
    bool has_normalized_name(const std::string & name, const setting & s) {
        return s.name.normalized == name;
    }
}

/** 
    Returns the settings from a metadata directory
    (one that shows up in the Settings pane, on the left-side).

    Metadata directories are virtual directories, that are read
    from metadata files.

    see notes/10
*/
compiler_metadata::dir_settings compiler_metadata::get_settings_at_dir(const std::string & metadata_dir_name) const {
    scoped_lock lk(m_cs);

    dir_settings dir;
    // see if we have this directory
    if ( tree::exists_item_at_path(m_dir_settings, metadata_dir_name))
        dir= tree::sub_item_at_path(m_dir_settings, metadata_dir_name).info;
    if ( dir.is_compiler_specific)
        // if directory is compiler-specific, the parent has no play in this
        // compiler-specific directories are not inherited
        return dir;

    // take from parent as well, and merge.
    // we override parent settings
    dir_settings parent_dir;
    if ( m_parent) 
        parent_dir = m_parent->get_settings_at_dir(metadata_dir_name);

    // see notes/10
    //
    // also, always the child overrides the parent. For one thing, it could be that 
    // the child is more refined, or of a totally different type than the parent.
    //
    // For example, the "Debug Information Format" from VC7.1 adds the enumeration "Database for Edit and Continue",
    //              compared to VC6.
    for( crange<dir_settings::array> r(parent_dir.settings); r;) {
        std::string name = r->name.normalized;
        if ( rng::find_if(dir.settings, boost::bind(has_normalized_name,name,_1) ))
            r = rng::erase_current(parent_dir.settings, r); // both in parent dir, and in this dir
        else
            ++r;
    }
    dir.settings.insert(dir.settings.end(), parent_dir.settings.begin(), parent_dir.settings.end() );
    return dir;
}

/** 
    Loads the compiler metadata settings
*/
void compiler_metadata::load_settings() {
    scoped_lock lk(m_cs);

    // clear it first
    m_dir_settings = tree::item<dir_settings>("root"); // the root is never shown visually

    std::string file_name = (m_dir / "settings.txt").string();
    BOOST_LOG(dbg) << "Reading file " << file_name;
    std::ifstream in( file_name.c_str() );
    std::string line;
    typedef tree::item<dir_settings> tree_item;
    tree_item * cur_dir = &m_dir_settings;
    while ( std::getline(in, line) ) {
        str_trim(line);
        if ( line.empty() ) continue;
        if ( line[0] == '#') 
            continue; // lines starting with '#' - comments

        BOOST_LOG(dbg) << line;
        std::istringstream line_in(line);
        std::string signature;
        line_in >> signature;
        if ( signature == "directory" || signature == "compiler-directory" ) {
            std::string parent_name, child_name, desc;
            char delim;
            std::string dir;
            while ( line_in >> io::read_str(dir) ) {
                // add this dir to the directory path...
                if ( !child_name.empty() ) {
                    if ( !parent_name.empty() ) parent_name += "/";
                    parent_name +=  child_name;
                }
                child_name = dir; 

                delim = line_in.get();
                if ( delim != '/') {
                    // when no more delims, documentation follows
                    line_in >> io::read_str(desc);
                }
            }

            try {
                // find this directory
                tree_item * parent_dir = &tree::sub_item_at_path(m_dir_settings, parent_name);
                typedef tree_item::array array;
                tree_item * child = parent_dir->child_by_name(child_name);
                if ( child) 
                    cur_dir = child; // already exists
                else {
                    // new directory
                    parent_dir->children.push_back( tree::item<dir_settings>(child_name) );
                    cur_dir = &parent_dir->children.back();
                    cur_dir->info.description = desc;
                    cur_dir->info.is_compiler_specific = signature == "compiler-directory";
                }
            } catch(std::exception & exc) {
                BOOST_LOG(err) << file_name << ":" << exc.what() << " at line " << line;
            }

        }
        else if ( signature == "setting") {
            // reading setting
            std::string type;
            std::string name;
            setting cur_set;
            line_in >> io::read_str(name) >> io::read_str(cur_set.description) >> type;

            // the setting can have this syntax: "name/user-friendly name"
            cur_set.name = split_into_name_and_userfriendly_name(name);

            if ( type == "array") {
                cur_set.is_array = true;
                line_in >> type;
            }
            if ( type == "bool") {
                // bool is just a fixed enumerator
                //cur_set.type = sett::bool_;
                cur_set.type = sett::enum_;
                cur_set.enums.push_back( name_pair("0","No") );
                cur_set.enums.push_back( name_pair("1","Yes") );
            }
            else if ( type == "string")
                cur_set.type = sett::string;
            else if ( type == "int")
                cur_set.type = sett::int_;
            else if ( type == "real")
                cur_set.type = sett::double_;
            else if ( type == "file")
                cur_set.type = sett::file;
            else if ( type == "dir")
                cur_set.type = sett::dir;
            else if ( type == "enum") {
                cur_set.type = sett::enum_;
                std::string val;
                while ( line_in && line_in >> io::read_str(val) )
                    if ( val != "end-enum")
                        cur_set.enums.push_back( split_into_name_and_userfriendly_name(val));
                    else
                        break;
            }
            else {
                BOOST_LOG(err) << file_name << ": invalid line " << line;
                continue;
            }

            // read default value
            std::string raw_default_val, default_val, default_friendly_val;
            line_in >> io::read_str(raw_default_val);
            default_val = normalized_name(raw_default_val); // normalize it
            if ( cur_set.type == sett::enum_) {
                if ( type == "bool")
                    default_val = default_val != "0" ? "1" : "0"; // normalize boolean value
                default_friendly_val = default_val;
                for ( crange<const setting::enum_array> r(cur_set.enums); r; ++r)
                    if ( r->normalized == default_val) 
                        default_friendly_val = r->user_friendly;
            }
            else {
                default_friendly_val = raw_default_val;
            }
            cur_set.default_val = name_pair(default_val, default_friendly_val);

            m_settings[ cur_set.name.normalized ] = cur_set;
        }
        // FIXME (bug) in case item exists in any ascendants, I should get it from there !!!
        // (this applies, for instance, for Configure Compiler/gcc)
        else if ( signature == "item") {
            std::string item_name;
            line_in >> io::read_str(item_name);
            item_name = normalized_name(item_name);
            if ( crange<setting_coll> r = rng::coll_find(m_settings,item_name))
                cur_dir->info.settings.push_back( r->second);
            else
                BOOST_LOG(err) << file_name << ": invalid item name " << item_name;
        }
        else if ( signature == "attribute") {
            std::string sett_name, attribute, value;
            line_in >> io::read_str(sett_name) >> io::read_str(attribute) >> io::read_str(value);
            sett_name = normalized_name(sett_name);
            if ( crange<setting_coll> r = rng::coll_find(m_settings,sett_name)) {
                attribute = normalized_name(attribute);
                set_setting_attribute(r->second, attribute, value);
            }
            else
                BOOST_LOG(err) << file_name << ": invalid setting name " << sett_name;
        }
        else 
            BOOST_LOG(err) << file_name << ": invalid line " << line;
    }
    tree::sort(m_dir_settings);
    BOOST_LOG(dbg) << "End of Reading file " << file_name;
}



/** 
    Loads this compiler's setting rules
*/
void compiler_metadata::load_rules() {
    scoped_lock lk(m_cs);

    std::ifstream in( (m_dir / "rules.txt").string().c_str() );
    std::string line;

    // options that are in effect when reading the current line
    setting_rule::option_set option_groups;

    setting_rule::applies_to::type applies = setting_rule::applies_to::compile; // ... by default
    while ( std::getline(in, line) ) {
        str_trim(line);
        if ( line.empty() || line[0] == '#') 
            continue; // empty line, or comment
        std::istringstream line_in(line);
        std::string signature;
        line_in >> signature;
        if ( signature == "applies-to") {
            // FIXME in the future, I will have multiple types of "applies-to".
            // For example, the least -> applies-to CPP, RC. But I should adjust for
            // multiple languages.
            std::string to;
            line_in >> to;
            if ( to == "compile")   applies = setting_rule::applies_to::compile;
            else if ( to == "link") applies = setting_rule::applies_to::link;
            else
                BOOST_LOG(err) << "invalid applies-to rule: " << line;
        }
        else if ( signature == "options") {
            std::string name;
            line_in >> io::read_str(name);
            name = normalized_name(name);
            option_groups.insert(name);
        }
        else if ( signature == "end-options") {
            std::string name;
            line_in >> io::read_str(name);
            name = normalized_name(name);
            option_groups.erase(name);
        }
        else {
            // read a rule
            try {
                setting_rule rule = rule_from_line(line);
                rule.option_groups = option_groups;
                rule.applies = applies;
                m_rules.push_back(rule);
            } catch(std::exception & ) {
                BOOST_LOG(err) << "invalid setting rule: " << line;
            } 
        }
    }
}

/** 
    Returns a user-friendly name of this compiler metadata

    Convension: "invisible" means this should not be shown to the user.
*/
std::string compiler_metadata::friendly_name() const {
    std::string name = m_dir.leaf();
    std::ifstream in( (m_dir / "name.txt").string().c_str() );
    std::getline(in, name);
    return name;
}


/** 
    returns the full name of this compiler metadata - the name that uniquely identifies it
*/
std::string compiler_metadata::full_name() const {
    return m_full_name;
}

setting compiler_metadata::get_setting(std::string name) const {
    name = normalized_name(name);
    {
    scoped_lock lk(m_cs);
    if ( crange<const setting_coll> r = rng::coll_find(m_settings,name))
        return r->second;
    }
    
    if ( m_parent)
        return m_parent->get_setting(name);
    else
        PWC_THROW std::runtime_error("setting " + name + " not found");
}


/** 
    Returns the rules for this metadata
*/
compiler_metadata::rule_array compiler_metadata::rules() const {
    // FIXME this could be optimized, if needed.
    rule_array result;
    if ( m_parent) {
        rule_array parent_rules = m_parent->rules();
        result.insert( result.end(), parent_rules.begin(), parent_rules.end() );
    }
    result.insert( result.end(), m_rules.begin(), m_rules.end() );
    return result;
}


