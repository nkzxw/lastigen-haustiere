Get the latest Dev-C++ (including migw for Windows) from
http://www.bloodshed.net

Note: for building a sample using gcc, you can:
copy dev_cpp_template in the sample directory.
Open dev_cpp_prj.dev.

Then, add the project files (all .cpp and .rc files).
Then, compile and run.

(the samples in the smart_dlg directory already have the dev_cpp directory. You can take a look)
