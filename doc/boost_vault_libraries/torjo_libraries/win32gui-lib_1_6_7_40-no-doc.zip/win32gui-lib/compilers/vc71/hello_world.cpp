// hello_world.cpp

// Sample program

// You can find the latest version of this library at 
// http://www.torjo.com/win32gui/

#include <win32gui/frame.hpp>
#include <win32gui/controls.hpp>


using namespace win32::gui;
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR lpCmdLine, int nCmdShow) {

    DWORD style = WS_VISIBLE | WS_CHILD | SS_CENTER;
    wnd<frame> main = create_wnd<frame>( 
        "My Simple GUI", null_wnd, create_info().rect(200,200,420,270) )
            .add_child<label>( "Hello", create_info().rect(10,10,90,30).style(style))
            .add_child<label>( "World", create_info().rect(110,10,200,30).style(style));
    main->wait( wait_for::destroy );
}

