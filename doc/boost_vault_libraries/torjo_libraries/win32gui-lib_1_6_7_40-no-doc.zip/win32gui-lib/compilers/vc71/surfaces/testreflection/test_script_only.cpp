// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/reflection/reflection.hpp>
using namespace win32::gui::reflection;


namespace {
    struct test_rectangle : reflectable_properties_object<test_rectangle> {
        trivial_property<int> left;
        trivial_property<long> top;
    };
}


/* 
    Tests script-only properties
*/
void test_script_only() {
    // register properties
    register_reflect r("left", &test_rectangle::left);
    register_reflect r2("top", &test_rectangle::top);
    // script-only properties !!!
    register_reflect r3("right", script_only<test_rectangle,short int>() );
    register_reflect r4("bottom", script_only<test_rectangle,unsigned>() );

    // register types
    register_reflect_type<int> r5("int");
    register_reflect_type<long> r6("long");
    register_reflect_type<short int> r7("short int");
    register_reflect_type<unsigned> r8("unsigned");

    // make sure that for all registered variables, we can get/set them
    // (write/read to string)
    using namespace detail;
    reflect_info().validate_member_types();

    test_rectangle rect;
        
    std::string str;
    // test setters ang getters for scripting
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(rect)) ][ "right" ].set->do_set( &rect, "5");
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(rect)) ][ "right" ].get->do_get( &rect, str);
    assert( str == "5" );
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(rect)) ][ "bottom" ].set->do_set( &rect, "10");
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(rect)) ][ "bottom" ].get->do_get( &rect, str);
    assert( str == "10");

    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(rect)) ][ "right" ].set->do_set( &rect, "105");
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(rect)) ][ "right" ].get->do_get( &rect, str);
    assert( str == "105" );
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(rect)) ][ "bottom" ].set->do_set( &rect, "110");
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(rect)) ][ "bottom" ].get->do_get( &rect, str);
    assert( str == "110");

}



