// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/reflection/reflection.hpp>
using namespace win32::gui::reflection;

namespace {
    struct test_point : reflectable_properties_object<test_point> {
        void left(int val) { m_left = val; }
        int left() const { return m_left; }

        void top(int val) { m_top = val; }
        int top() const { return m_top; }
    private:
        int m_left;
        int m_top;
    };

    struct name_desc : reflectable_properties_object<name_desc> {
        // note: name() is returned by reference; desc() is returned by value !!!!!!!!!!!
        void name(std::string val)  { m_name = val; }
        const std::string & name() const    { return m_name; }

        void desc(const std::string & val)  { m_desc = val; }
        std::string desc() const            { return m_desc; }
    private:
        std::string m_name;
        std::string m_desc;
    };

    // register one & two as get-only
    struct test_read : reflectable_properties_object<test_read> {
        test_read() : m_two(2) {}
        int one() const { return 1; }
        const unsigned & two() const { return m_two; }
    private:
        unsigned m_two;
    };

    // register one and two as set-only
    struct test_write : reflectable_properties_object<test_write> {
        test_write() : m_one(0), m_two(0) {}
        void one(short int val) {
            m_one = val;
        }
        void two(const long & val) {
            m_two = val;
        }

        short int m_one;
        long m_two;
    };

}



/*
    Tests that registering of types and property_type types works correctly.

    Registers a few property_type types, then some test classes, and see that they work ok.
*/
void test_register_type_and_member_type() {
    // register properties
    register_reflect r("left", &test_point::left, &test_point::left);
    register_reflect r2("top", &test_point::top, &test_point::top);

    register_reflect r3("name", &name_desc::name, &name_desc::name);
    register_reflect r4("desc", &name_desc::desc, &name_desc::desc);

    register_reflect r5("one", &test_read::one);
    register_reflect r6("two", &test_read::two);

    register_reflect r7("one", &test_write::one);
    register_reflect r8("two", &test_write::two);

    // register types
    register_reflect_type<int> r9("int");
    register_reflect_type<long> r10("long");
    register_reflect_type<std::string> r11("string");
    register_reflect_type<short int> r12( "short_int", register_set_only ) ;
    register_reflect_type<unsigned> r13( "unsigned", register_get_only ) ;

    // make sure that for all registered variables, we can get/set them
    // (write/read to string)
    using namespace detail;
    reflect_info().validate_member_types();

    // manually call setters and getters
    test_point pnt;
    name_desc nd;
    test_read read;
    test_write write;

    // test setters for test_point
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(pnt)) ][ "left" ].set->do_set( &pnt, "5");
    assert( pnt.left() == 5);
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(pnt)) ][ "top" ].set->do_set( &pnt, "10");
    assert( pnt.top() == 10);
    // test getters for test_point
    pnt.left(7);
    pnt.top(8);
    std::string str;
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(pnt)) ][ "left" ].get->do_get( &pnt, str);
    assert( str == "7");
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(pnt)) ][ "top" ].get->do_get( &pnt, str);
    assert( str == "8");

    // test setters for name_desc
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(nd)) ][ "name" ].set->do_set( &nd, "John");
    assert( nd.name() == "John");
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(nd)) ][ "desc" ].set->do_set( &nd, "John Doe");
    assert( nd.desc() == "John Doe");
    // test getters for name_desc
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(nd)) ][ "name" ].get->do_get( &nd, str);
    assert( str == "John");
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(nd)) ][ "desc" ].get->do_get( &nd, str);
    assert( str == "John Doe");

    // test_read
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(read)) ][ "one" ].get->do_get( &read, str);
    assert( str == "1");
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(read)) ][ "two" ].get->do_get( &read, str);
    assert( str == "2");

    // test_write
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(write)) ][ "one" ].set->do_set( &write, "11");
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(write)) ][ "two" ].set->do_set( &write, "22");
    assert( write.m_one == 11);
    assert( write.m_two == 22);
}

