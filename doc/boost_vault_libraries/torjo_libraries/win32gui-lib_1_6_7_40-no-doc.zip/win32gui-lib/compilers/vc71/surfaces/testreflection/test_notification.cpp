// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/reflection/reflection.hpp>
using namespace win32::gui::reflection;

namespace {
    struct deepest_inner : reflectable_properties_object<deepest_inner> {
        deepest_inner() : m_left(0) {}

        void left(int val) { 
            m_left = val; 
            notify(&me::left);
        }
        int left() const { return m_left; }

        trivial_property<long> top;
    private:
        int m_left;
    };

    struct inner : reflectable_properties_object<inner> {
        const deepest_inner & a() const { return m_a; }
        void a(const deepest_inner & val) { 
            m_a = val; 
            notify(&me::a);
        }

        trivial_property<deepest_inner> b;
    private:
        deepest_inner m_a;
    };

    struct outer : reflectable_properties_object<outer> {
        trivial_property<inner> inner1;
        trivial_property<inner> inner2;
        trivial_property<deepest_inner> deep1;

        const inner & inner3() const { 
            return m_inner3; 
        }
        void inner3(const inner & val) { 
            m_inner3 = val;
            notify(&me::inner3);
        }
    private:
        inner m_inner3;
    };








    void print_notification(const reflectable_properties_object_base*, const std::string & prop) {
        std::cout << "change in " << prop << std::endl;
    }

    struct notify_prop {
        std::string prop_name;
    };

    notify_prop expected_names_all[] = {
        { "inner1.a.left" },
        { "inner1.a.top" }
    };
    int count_all = sizeof(expected_names_all) / sizeof(expected_names_all[0]);

    notify_prop expected_names_a[] = {
        { "inner1.a.left" },
        { "inner1.a.top" }
    };
    int count_a = sizeof(expected_names_a) / sizeof(expected_names_a[0]);

    notify_prop expected_names_left[] = {
        { "inner1.a.left" },
        { "inner1.a.top" }
    };
    int count_left = sizeof(expected_names_left) / sizeof(expected_names_left[0]);

    notify_prop expected_names_fix[] = {
        { "inner1.a.left" },
        { "inner1.a.top" }
    };
    int count_fix = sizeof(expected_names_fix) / sizeof(expected_names_fix[0]);

    notify_prop expected_names_inner1[] = {
        { "inner1.a.left" },
        { "inner1.a.top" }
    };
    int count_inner1 = sizeof(expected_names_inner1) / sizeof(expected_names_inner1[0]);

    struct check_notification {
        check_notification(const notify_prop * expected_names, int count) : expected_names(expected_names), count(count), idx(0) {}

        void operator()(const reflectable_properties_object_base*, const std::string & prop) const {
            return;
            // too many notifications!
            assert( idx < count);
            // unexpected notification!
            assert( expected_names[idx].prop_name == prop);
            ++idx;
        }

        mutable int idx;
        int count;
        const notify_prop * expected_names;
    };
    
}

void test_notification() {

    // register properties
    register_reflect r("left", &deepest_inner::left, &deepest_inner::left);
    register_reflect r2("top", &deepest_inner::top);
    register_reflect r3("a", &inner::a, &inner::a);
    register_reflect r4("b", &inner::b);
    register_reflect r41("c", script_only<inner, deepest_inner>() );
    register_reflect r5("inner1", &outer::inner1);
    register_reflect r6("inner2", &outer::inner2);
    register_reflect r7("deep1", &outer::deep1);
    register_reflect r72("inner3", &outer::inner3, &outer::inner3);

    // register types
//    register_reflect r8("int", reflect_type<int>() );
    register_reflect_type<int> r9("int");
    register_reflect_type<long> r10("long");

    // make sure that for all registered variables, we can get/set them
    // (write/read to string)
    using namespace detail;
    reflect_info().validate_member_types();

    notify::subscribe(print_notification, "*");
    notify::subscribe(check_notification(expected_names_all, count_all), "*");
    notify::subscribe(check_notification(expected_names_a, count_a), "*.a.*");
    notify::subscribe(check_notification(expected_names_left, count_left), "*.left");
    notify::subscribe(check_notification(expected_names_fix, count_fix), "inner1.b.left");
    notify::subscribe(check_notification(expected_names_inner1, count_inner1), "inner1.*");

    outer out;
    out.set("inner1.a.left", "05");
    out.set("inner1.a.top", "10");
    out.set("inner1.b.left", "15");
    out.set("inner1.b.top", "20");
    out.set("inner1.c.left", "25");
    out.set("inner1.c.top", "30");

    out.set("inner2.a.left", "105");
    out.set("inner2.a.top", "110");
    out.set("inner2.b.left", "115");
    out.set("inner2.b.top", "120");
    out.set("inner2.c.left", "125");
    out.set("inner2.c.top", "130");

    out.set("inner3.a.left", "2105");
    out.set("inner3.a.top", "2110");
    out.set("inner3.b.left", "2115");
    out.set("inner3.b.top", "2120");
    out.set("inner3.c.left", "2125");
    out.set("inner3.c.top", "2130");

    out.set("deep1.left", "3105");
    out.set("deep1.top", "3110");

}