// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/draw/surfaces/detail/parse_relations.hpp>
#include <win32gui/reflection/reflection.hpp>
#include <fstream>

using namespace win32::gui::draw;
using namespace win32::gui::reflection;

namespace {
    
    std::string from_file(const std::string & file_name) {
        std::ifstream in(file_name.c_str());
        std::ostringstream out;
        in >> out.rdbuf();
        return out.str();
    }

    std::string printed(const statement &s) {
        std::ostringstream out;
        s.print(out);
        return out.str();
    }
}


/* 
    tests parsing relations
*/
void test_parse_relations() {
    win32::gui::draw::detail::relations_holder rls;
    win32::gui::draw::detail::parse_relations( from_file("relations.txt"), rls);

    assert( rls.layouts.size() == 3);
    assert( rls.layouts["horiz"].size() == 10);
    assert( printed(*rls.layouts["horiz"]["pane1.rect.width"]) == " { [parent.rect.width] / [2] } ");
    assert( printed(*rls.layouts["horiz"]["pane1.rect.height"]) == " {parent.rect.height} ");
    assert( printed(*rls.layouts["horiz"]["pane2.rect.left"]) == " {pane1.rect.width} ");
    assert( printed(*rls.layouts["horiz"]["pane2.rect.width"]) == " {pane1.rect.width} ");
    assert( printed(*rls.layouts["horiz"]["pane2.rect.height"]) == " {parent.rect.height} ");

    assert( printed(*rls.layouts["horiz"]["pane3.rect.width"]) == " { [parent.rect.width] / [2] } ");
    assert( printed(*rls.layouts["horiz"]["pane3.rect.height"]) == " {parent.rect.height} ");
    assert( printed(*rls.layouts["horiz"]["pane4.rect.left"]) == " {pane3.rect.width} ");
    assert( printed(*rls.layouts["horiz"]["pane4.rect.width"]) == " {pane3.rect.width} ");
    assert( printed(*rls.layouts["horiz"]["pane4.rect.height"]) == " {parent.rect.height} ");

    assert( rls.layouts["vert"].size() == 16);
    assert( printed(*rls.layouts["vert"]["pane1.rect.left"]) == " {0cm} ");
    assert( printed(*rls.layouts["vert"]["pane1.rect.top"]) == " {0cm} ");
    assert( printed(*rls.layouts["vert"]["pane1.rect.width"]) == " {parent.rect.width} ");
    assert( printed(*rls.layouts["vert"]["pane1.rect.height"]) == " { [parent.rect.height] / [2] } ");
    assert( printed(*rls.layouts["vert"]["pane2.rect.left"]) == " {0cm} ");
    assert( printed(*rls.layouts["vert"]["pane2.rect.top"]) == " {pane1.rect.height} ");
    assert( printed(*rls.layouts["vert"]["pane2.rect.width"]) == " {pane1.rect.width} ");
    assert( printed(*rls.layouts["vert"]["pane2.rect.height"]) == " { [parent.rect.height] / [2] } ");

    assert( printed(*rls.layouts["vert"]["pane3.rect.left"]) == " {0cm} ");
    assert( printed(*rls.layouts["vert"]["pane3.rect.top"]) == " {0cm} ");
    assert( printed(*rls.layouts["vert"]["pane3.rect.width"]) == " {parent.rect.width} ");
    assert( printed(*rls.layouts["vert"]["pane3.rect.height"]) == " { [parent.rect.height] / [2] } ");
    assert( printed(*rls.layouts["vert"]["pane4.rect.left"]) == " {0cm} ");
    assert( printed(*rls.layouts["vert"]["pane4.rect.top"]) == " {pane3.rect.height} ");
    assert( printed(*rls.layouts["vert"]["pane4.rect.width"]) == " {pane3.rect.width} ");
    assert( printed(*rls.layouts["vert"]["pane4.rect.height"]) == " { [parent.rect.height] / [2] } ");

    assert( rls.layouts["last"].size() == 3);
    assert( printed(*rls.layouts["last"]["pane2.rect.left"]) == " { [pane1.rect.left] + [ (pane1.rect.width) + (0cm) ] } ");
    assert( printed(*rls.layouts["last"]["cucu.rect.width"]) == " { [ (10) / (100) ] * [parent.rect.width] } " );
    assert( printed(*rls.layouts["last"]["cucu.rect.height"]) == " { [parent.rect.height] + -[10] } ");

    ///////////////////////////////////////////////////////////////////////////////
    // surfaces
    assert( rls.surfaces.children.size() == 2);
    assert( rls.surfaces.children["parent_pane"].name == "parent_pane");
    assert( rls.surfaces.children["cucu"].name == "cucu");
    assert( rls.surfaces.children["cucu"].children.size() == 0);
    assert( rls.surfaces.children["parent_pane"].children.size() == 4);

    assert( rls.surfaces.children["parent_pane"].children["pane1"].name == "pane1");
    assert( rls.surfaces.children["parent_pane"].children["pane2"].name == "pane2");
    assert( rls.surfaces.children["parent_pane"].children["pane3"].name == "pane3");
    assert( rls.surfaces.children["parent_pane"].children["pane4"].name == "pane4");

    assert( rls.surfaces.children["parent_pane"].children["pane1"].children.size() == 2);
    assert( rls.surfaces.children["parent_pane"].children["pane2"].children.size() == 1);
    assert( rls.surfaces.children["parent_pane"].children["pane3"].children.size() == 0);
    assert( rls.surfaces.children["parent_pane"].children["pane4"].children.size() == 3);


    assert( rls.surfaces.children["parent_pane"].children["pane1"].children["child11"].name == "child11");
    assert( rls.surfaces.children["parent_pane"].children["pane1"].children["child12"].name == "child12");

    assert( rls.surfaces.children["parent_pane"].children["pane2"].children["child21"].name == "child21");

    assert( rls.surfaces.children["parent_pane"].children["pane4"].children["child41"].name == "child41");
    assert( rls.surfaces.children["parent_pane"].children["pane4"].children["child42"].name == "child42");
    assert( rls.surfaces.children["parent_pane"].children["pane4"].children["child43"].name == "child43");
}


