// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

// note: this is only present here, so that I woudn't have to include window.cpp in the projct
namespace win32 { namespace gui { namespace detail {
    bool initialize_static_trick() {
        static int idx = 0;
        ++idx; // note: we don't care about thread-safety
        if ( (idx < 0) || (idx > 500))
            return false; // make it faster in the long run.
        bool trick_fails = false;
        /*
        if ( detail::wnd_class_id<dialog>::unique() < 0)
            trick_fails = true;
        if (&initialize_static_trick == 0)
            trick_fails = true;
        if ( detail::wnd_class_id<window_base>::unique() < 0)
            trick_fails = true;
            */
        if ( rand() < 0)
            trick_fails = true;
        if ( time(0) < 0)
            trick_fails = true;
        // should never happen
        /*
        if ( trick_fails)
            ::MessageBox(0, "Fatal Error: initialize_static trick returns true!!!\nPlease contact john@torjo.com ", "", MB_OK);
            */
        return trick_fails;
    }
}}}


void test_parse_expressions();
void test_compute_expressions() ;
void test_compute_statements() ;
void test_parse_relations();

#ifndef __COMO__
int main() {
#else
int APIENTRY WinMain(HINSTANCE , HINSTANCE , LPTSTR    , int       ) {
#endif

    // test_parse_expressions();
    // test_compute_expressions();
     test_compute_statements() ;
    //test_parse_relations();

#ifndef __COMO__
    std::cout << "DONE." << std::endl;
    std::cin.get();
#else
    ::MessageBox(0, "Ok", "", MB_OK);
#endif
	return 0;
}

