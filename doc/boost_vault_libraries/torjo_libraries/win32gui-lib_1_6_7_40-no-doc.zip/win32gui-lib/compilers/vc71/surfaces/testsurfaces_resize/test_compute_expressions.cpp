// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/draw/surfaces/detail/expression.hpp>
#include <win32gui/draw/surfaces/detail/surface.hpp>
#include <win32gui/reflection/reflection.hpp>
#include <sstream>
#include <math.h>

using namespace win32::gui::draw;
using namespace win32::gui::reflection;

namespace {

    struct t_point : surface_<t_point> {
        /*
        t_point() {
            int i = 0;
        }
        ~t_point() {
            int i  = 0;
        }
        */
        trivial_property<int> left;
        trivial_property<int> top;

        static std::string class_name() { return "t_point"; }
    };

    struct t_rectangle : surface_<t_rectangle> {
        trivial_property<int> left;
        trivial_property<int> top;
        trivial_property<int> width;
        trivial_property<int> height;
        trivial_property<std::string> name;

        static std::string class_name() { return "t_rectangle"; }
    };

    bool approximately_equal(double a, double b) {
        double diff = abs(a - b);
        return ( diff < .001);
    }

    ////////////////////////////////////
    // Script functions

    int min_(int i, int j) {
        return i < j ? i : j;
    }

    int max_(int i, int j) {
        return i > j ? i : j;
    }

    int do_mul(int i, int j) {
        return i * j;
    }

    int do_div(int i, int j) {
        return i / j;
    }

    length do_length_op(const length & a, const length & b, const std::string & op) {
        length result = a;
        if ( op == "+") result += b;
        else if ( op == "-") result -= b;
        else if ( op == "*") result *= b;
        else if ( op == "/") result /= b;
        return result;
    }
}


/* 
    tests computing expressions
    (to see that computing an expression generates the expected result)
*/
void test_compute_expressions() {
    register_reflect r1("left", &t_point::left);
    register_reflect r2("top", &t_point::top);

    register_reflect r3("left", &t_rectangle::left);
    register_reflect r4("top", &t_rectangle::top);
    register_reflect r5("width", &t_rectangle::width);
    register_reflect r6("height", &t_rectangle::height);
    register_reflect r7("name", &t_rectangle::name);

    register_reflect r8("min", &min_);
    register_reflect r81("max", &max_);
    register_reflect r82("mul", &do_mul);
    register_reflect r83("div", &do_div);
    register_reflect r84("length_op", &do_length_op);

    register_reflect_type<int> r21("int");
    register_reflect_type<std::string> r22("string");
    register_reflect_type<length> r23("length");

    using namespace win32::gui::reflection::detail;
    reflect_info().validate_member_types();


    ptr<> pnt1 = create_surface("t_point"), pnt2 = create_surface("t_point"), pnt3 = create_surface("t_point");
    ptr<> rect1 = create_surface("t_rectangle"), rect2 = create_surface("t_rectangle");

    pnt1->set("left", "5");
    pnt1->set("top", "10");

    pnt2->set("left", "50");
    pnt2->set("top", "100");

    pnt3->set("left", "500");
    pnt3->set("top", "1000");

    rect1->set("left", "1");
    rect1->set("top", "2");
    rect1->set("width", "10");
    rect1->set("height", "20");
    rect1->set("name", "Rectangle 1");

    rect2->set("left", "10");
    rect2->set("top", "20");
    rect2->set("width", "100");
    rect2->set("height", "200");
    rect2->set("name", "Rectangle two");

    statement_compute_info compute1;
    compute1.m_self = pnt1;
    compute1.m_other_objects["p"] = pnt2;
    compute1.m_other_objects["r"] = rect1;

    expression e1("self.left * 3 + p.top * r.width + r.height / p.left");
    expression_result res1 = e1.compute(compute1);
    assert( approximately_equal(res1.as_double(), 1015.4) );

    expression e12("(self.left * 3 + p.top * r.width + r.height / p.left) < 1016");
    res1 = e12.compute(compute1);
    assert( res1.as_bool() );
    expression e13("(self.left * 3 + p.top * r.width + r.height / p.left) <= 116");
    res1 = e13.compute(compute1);
    assert( !res1.as_bool() );


    expression e2("13cm * 2mm + 50mm / 20mm");
    expression_result res2 = e2.compute( statement_compute_info() );
    assert( approximately_equal(res2.as_len().val, 2.85) );
    assert( res2.as_len().type() == length::cm);

    statement_compute_info compute3;
    compute3.m_self = rect1;
    expression e3("a + b + \"c d\" + self.name");
    expression_result res3 = e3.compute( compute3);
    assert( res3.as_str() == "abc dRectangle 1");

    expression e4("(1 < 6) && (7 <= 6) || (A < B) && (\"titi\" >= \"gigi\") ");
    assert( e4.compute( statement_compute_info()).as_bool() );
    expression e5("(1 < 6) && (7.5in >= 1px)  && \"titi\" >= \"gigi\" ");
    assert( e5.compute( statement_compute_info()).as_bool() );

    // call functions
    statement_compute_info compute6;
    compute6.m_other_objects["p1"] = pnt1;
    compute6.m_other_objects["p2"] = pnt2;
    expression e6("12 * max(p1.left,p2.left) - mul(p1.top,p2.top)");
    expression_result res6 = e6.compute(compute6);
    assert( approximately_equal(res6.as_double(), -400));

    expression e62("12 * mul(max(p1.left,p2.left),p1.top) + mul(mul(p1.top,max(p1.top,p2.top)),div(p2.top,p1.top))");
    expression_result res62 = e62.compute(compute6);
    assert( approximately_equal(res62.as_double(), 16000));

    expression e7("12cm + length_op( length_op(10mm,1.5cm,\"+\"), length_op(10cm,2cm,\"-\"), \"+\" ) ");
    expression_result res7 = e7.compute( statement_compute_info() );
    assert( approximately_equal(res7.as_len().val, 22.5) );
    assert( res7.statement_type() == length::cm);

//    std::cout << res2.as_len() << std::endl;
}



