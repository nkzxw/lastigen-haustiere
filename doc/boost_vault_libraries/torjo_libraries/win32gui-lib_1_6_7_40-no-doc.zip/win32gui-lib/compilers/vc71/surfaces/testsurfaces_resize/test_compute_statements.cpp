// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/draw/surfaces/detail/statement.hpp>
#include <win32gui/draw/surfaces/detail/surface.hpp>
#include <win32gui/reflection/reflection.hpp>
#include <sstream>
#include <math.h>

using namespace win32::gui::draw;
using namespace win32::gui::reflection;

namespace {

    struct t_point : surface_<t_point> {
        trivial_property<int> left;
        trivial_property<int> top;

        static std::string class_name() { return "s_point"; }
    };

    struct t_rectangle : surface_<t_rectangle> {
        trivial_property<int> left;
        trivial_property<int> top;
        trivial_property<int> width;
        trivial_property<int> height;
        trivial_property<std::string> name;

        static std::string class_name() { return "s_rectangle"; }
    };

    bool approximately_equal(double a, double b) {
        double diff = abs(a - b);
        return ( diff < .001);
    }


    void print(const std::string & name, int val) {
        std::cout << name << val << "; ";
    }


}


/* 
    tests computing statements
*/
void test_compute_statements() {

    register_reflect r1("left", &t_point::left);
    register_reflect r2("top", &t_point::top);

    register_reflect r3("left", &t_rectangle::left);
    register_reflect r4("top", &t_rectangle::top);
    register_reflect r5("width", &t_rectangle::width);
    register_reflect r6("height", &t_rectangle::height);
    register_reflect r7("name", &t_rectangle::name);

    register_reflect r8("print", &print);

    register_reflect_type<int> r21("int");
    register_reflect_type<std::string> r22("string");
    register_reflect_type<length> r23("length");

    using namespace win32::gui::reflection::detail;
    reflect_info().validate_member_types();

    ptr<> pnt1 = create_surface("s_point"), pnt2 = create_surface("s_point");
    pnt1->set("left", "5");
    pnt1->set("top", "10");
    pnt2->set("left", "40");
    pnt2->set("top", "100");

    
    statement s1( 
        "{"
        "if ( p1.top > p2.left) then {"
        "   print(\"p1.left=\",p1.left); p1.left * 10;"
        "} else {"
        "   print(\"p2.top=\",p2.top); p2.top * 5;"
        "}"
        "}"
        );
    statement_compute_info compute1;
    compute1.m_other_objects["p1"] = pnt1;
    compute1.m_other_objects["p2"] = pnt2;
    assert( approximately_equal(s1.compute(compute1).first.as_double(), 500));

    // reverse...
    statement_compute_info compute2;
    compute2.m_other_objects["p1"] = pnt2;
    compute2.m_other_objects["p2"] = pnt1;
    assert( approximately_equal(s1.compute(compute2).first.as_double(), 400));


    statement s2(
        "if ( p1.top > 10) then"
        "   if ( p1.top < 5) then"
        "       print(\"impossible!\",0);"
        "if ( p1.top < 200) then "
        "   200;"
        "if ( p1.top > 20) then "
        "   p1.top;"
        );
    assert( approximately_equal(s2.compute(compute1).first.as_double(), 200));
    assert( approximately_equal(s2.compute(compute2).first.as_double(), 100));

//    std::cout << s1.compute(compute1).first.as_double() << std::endl;
}


