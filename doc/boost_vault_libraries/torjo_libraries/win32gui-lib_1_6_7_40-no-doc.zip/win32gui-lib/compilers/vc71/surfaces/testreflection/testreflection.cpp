// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

// note: this is only present here, so that I woudn't have to include window.cpp in the projct
namespace win32 { namespace gui { namespace detail {
    bool initialize_static_trick() {
        static int idx = 0;
        ++idx; // note: we don't care about thread-safety
        if ( (idx < 0) || (idx > 500))
            return false; // make it faster in the long run.
        bool trick_fails = false;
        /*
        if ( detail::wnd_class_id<dialog>::unique() < 0)
            trick_fails = true;
        if (&initialize_static_trick == 0)
            trick_fails = true;
        if ( detail::wnd_class_id<window_base>::unique() < 0)
            trick_fails = true;
            */
        if ( rand() < 0)
            trick_fails = true;
        if ( time(0) < 0)
            trick_fails = true;
        // should never happen
        /*
        if ( trick_fails)
            ::MessageBox(0, "Fatal Error: initialize_static trick returns true!!!\nPlease contact john@torjo.com ", "", MB_OK);
            */
        return trick_fails;
    }
}}}


void test_register_type_and_member_type();
void test_trivial();
void test_script_only();
void test_inheritance() ;
void test_aggregation();
void test_enum();
void test_notification();
void test_function();
void test_array();

#ifndef __COMO__
int main() {
#else
int APIENTRY WinMain(HINSTANCE , HINSTANCE , LPTSTR    , int       ) {
#endif

    test_register_type_and_member_type();
    test_trivial();
    test_script_only();
    test_inheritance();
    test_aggregation();
    test_enum();
    test_notification();
    test_function();
    test_array();

#ifndef __COMO__
    std::cout << "DONE." << std::endl;
    std::cin.get();
#else
    ::MessageBox(0, "Ok", "", MB_OK);
#endif
	return 0;
}

