// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/reflection/reflection.hpp>
using namespace win32::gui::reflection;

namespace {
    struct test_point : named_class<test_point>, reflectable_properties_object<test_point> {
        static std::string class_name() { return "test_point"; }

        test_point() : m_top(0) {}

        trivial_property<int> left;

        void top(int val) { m_top = val; }
        int top() const { return m_top; }
    private:
        int m_top;
    };

    struct test_rectangle : test_point, named_class<test_rectangle>, reflectable_properties_object<test_rectangle> {
        static std::string class_name() { return "test_rectangle"; }
        // bottom - is script-only
        trivial_property<long> right;

        // test - it is overwritten in smart_rectangle
        //        note: even the type is overwritten!
        trivial_property<std::string> test;
    };

    struct smart_rectangle : test_rectangle, named_class<smart_rectangle>, reflectable_properties_object<smart_rectangle> {
        static std::string class_name() { return "smart_rectangle"; }
        bool is_x_valid() const {
            return left() < right();
        }
        
        // test - overwrites the one from test_rectangle
        trivial_property<int> test;
    };
}

void print_props( const reflectable_properties_object_base & obj) {
    std::cout << "\nProperties for " << obj.object_name() << std::endl;
    typedef std::vector<property_info> array;
    array props = obj.enum_props();
    for ( array::const_iterator begin = props.begin(), end = props.end(); begin != end; ++begin)
        std::cout << begin->name << " = " << begin->type << std::endl;
}


void test_inheritance() {
    // register properties
    register_reflect r("left", &test_point::left);
    register_reflect r2("top", &test_point::top, &test_point::top);
    register_reflect r3("is_selected", script_only<test_point,bool>() );

    register_reflect r4("right", &test_rectangle::right);
    register_reflect r41("test", &test_rectangle::test);
    register_reflect r5("bottom", script_only<test_rectangle,unsigned>() );

    register_reflect r6("is_x_valid", &smart_rectangle::is_x_valid);
    register_reflect r61("test", &smart_rectangle::test);

    // register types
    register_reflect_type<int> r7("int");
    register_reflect_type<bool> r8("bool");
    register_reflect_type<long> r9("long");
    register_reflect_type<std::string> r92("string");
    register_reflect_type<unsigned> r921("unsigned");

    detail::reflect_info().validate_member_types();

    test_point pnt;
    test_rectangle rect;
    smart_rectangle smart;

    pnt.object_name("p");
    rect.object_name("r");
    smart.object_name("smart_r");

    print_props(pnt);
    print_props(rect);
    print_props(smart);

    pnt.set("left", "5");
    assert( pnt.get("left") == "5");
    pnt.set("top", "15");
    assert( pnt.get("top") == "15");
    pnt.set("is_selected", "1");
    assert(pnt.get("is_selected") == "1");
    assert( !pnt.has_prop("right") );
    assert( !pnt.has_prop("is_x_valid") );
    assert( !pnt.has_prop("a") );

    rect.set("left", "5");
    assert( rect.get("left") == "5");
    rect.set("top", "15");
    assert( rect.get("top") == "15");
    rect.set("right", "25");
    assert( rect.get("right") == "25");
    rect.set("bottom", "200");
    assert( rect.get("bottom") == "200");
    rect.set("is_selected", "1");
    assert(rect.get("is_selected") == "1");
    rect.set("test", "titi-gigi");
    assert( rect.get("test") == "titi-gigi");
    assert( !rect.has_prop("is_x_valid") );
    assert( !rect.has_prop("a") );

    smart.set("left", "5");
    assert( smart.get("left") == "5");
    smart.set("top", "15");
    assert( smart.get("top") == "15");
    smart.set("right", "25");
    assert( smart.get("right") == "25");
    smart.set("bottom", "200");
    assert( smart.get("bottom") == "200");
    smart.set("is_selected", "1");
    assert(smart.get("is_selected") == "1");
    smart.set("test_rectangle::test", "titi-gigi");
    assert( smart.get("test_rectangle::test") == "titi-gigi");
    smart.set("test", "244");
    assert( smart.get("test") == "244");
    assert( !smart.has_prop("a") );
}

