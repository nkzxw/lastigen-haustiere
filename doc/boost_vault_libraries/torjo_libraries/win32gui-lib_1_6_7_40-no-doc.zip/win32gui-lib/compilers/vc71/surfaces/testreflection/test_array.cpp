// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


#include <win32gui/window.hpp>
#include <win32gui/reflection/reflection.hpp>
using namespace win32::gui::reflection;

namespace {

    ///////////////////////////////////////////////////////////////////////////////////
    // testing Array get/set

    struct point : reflectable_properties_object<point> {
        trivial_property<int> left;
        trivial_property<int> top;
    };


    struct test : reflectable_properties_object<test> {
        reflectable_array<int> m_ints;
        reflectable_array<std::string> m_strings;
        
        reflectable_array<point> m_points;
    };

    void test_array_get_set() {
        register_reflect r1("ints", &test::m_ints);
        register_reflect r2("strings", &test::m_strings);
        register_reflect r3("points", &test::m_points);

        register_reflect_type<int> r21("int");
        register_reflect_type<std::string> r22("string");

        using namespace detail;
        reflect_info().validate_member_types();

        test t;
        t.set("ints", "[1, 3, 5]");
        assert( t.m_ints.size() == 3);
        assert( t.m_ints.at(0) == 1);
        assert( t.m_ints.at(1) == 3);
        assert( t.m_ints.at(2) == 5);

        t.set("strings", "  [a,b,c,\"d e\",f,\"g\"\"h\",i] ");
        assert( t.m_strings.size() == 7);
        assert( t.m_strings.at(0) == "a");
        assert( t.m_strings.at(1) == "b");
        assert( t.m_strings.at(2) == "c");
        assert( t.m_strings.at(3) == "d e");
        assert( t.m_strings.at(4) == "f");
        assert( t.m_strings.at(5) == "g\"h");
        assert( t.m_strings.at(6) == "i");

        t.m_ints.clear();
        t.m_ints.add(2);
        t.m_ints.add(3);
        t.m_ints.add(4);
        assert( t.get("ints") == "[ 2, 3, 4 ]");

        t.m_strings.clear();
        t.m_strings.add("abc");
        t.m_strings.add("");
        t.m_strings.add("de");
        t.m_strings.add("f\" g");
        t.m_strings.add("h,k");
        t.m_strings.add("l");
        t.m_strings.add("");
        assert( t.get("strings") == "[ abc, \"\", de, \"f\"\" g\", \"h,k\", l, \"\" ]");

        t.m_strings.clear();
        t.set("strings", "[ abc, \"\", de, \"f\"\" g\", \"h,k\", l, \"\" ]");
        assert( t.m_strings.size() == 7);
        assert( t.m_strings.at(0) == "abc");
        assert( t.m_strings.at(1) == "");
        assert( t.m_strings.at(2) == "de");
        assert( t.m_strings.at(3) == "f\" g");
        assert( t.m_strings.at(4) == "h,k");
        assert( t.m_strings.at(5) == "l");
        assert( t.m_strings.at(6) == "");
    }

    ///////////////////////////////////////////////////////////////////////////////////
    // testing passing Arrays to functions;
    // even an array of reflectable objects

    void print_array(const reflectable_array<int> & ints) {
        std::cout << "INT Array size: " << ints.size() << std::endl;
        for ( int idx = 0; idx < (int)ints.size(); ++idx)
            std::cout << "element " << idx << " = " << ints.at(idx) << std::endl;
    }

    void test_array(const reflectable_array<int> & ints) {
        assert( ints.size() == 3);
        assert( ints.at(0) == 1);
        assert( ints.at(1) == 3);
        assert( ints.at(2) == 5);
    }

    void print_points(const reflectable_array<point> & points) {
        std::cout << "POINT Array size: " << points.size() << std::endl;
        for ( int idx = 0; idx < (int)points.size(); ++idx)
            std::cout << "element " << idx << " = [" << points.at(idx).left() << "," << points.at(idx).top() << "]" << std::endl;
    }

    void test_points1(const reflectable_array<point> & points) {
        assert( points.size() == 2);
        assert( points.at(0).left() == 10);
        assert( points.at(0).top() == 20);
        assert( points.at(1).left() == 100);
        assert( points.at(1).top() == 200);
    }

    void modify_points(reflectable_array<point> & points) {
        points.clear();

        point p1, p2, p3, p4;
        p1.left(100);
        p1.top(200);
        p2.left(1000);
        p2.top(2000);

        p3.left(1);
        p3.top(2);
        p4.left(2);
        p4.top(4);

        points.add( p1);
        points.add( p2);
        points.add( p3);
        points.add( p4);
    }

    void test_points2(const reflectable_array<point> & points) {
        assert( points.size() == 4);
        assert( points.at(0).left() == 100);
        assert( points.at(0).top() == 200);
        assert( points.at(1).left() == 1000);
        assert( points.at(1).top() == 2000);
        assert( points.at(2).left() == 1);
        assert( points.at(2).top() == 2);
        assert( points.at(3).left() == 2);
        assert( points.at(3).top() == 4);
    }

    // tests passing a trivial array to the function
    void test_pass_array_to_func() {
        register_reflect r1( "print_array", &print_array);
        register_reflect r2( "test_array", &test_array);
        register_reflect r3( "print_points", &print_points);
        register_reflect r4( "test_points1", &test_points1);
        register_reflect r41( "modify_points", &modify_points);
        register_reflect r42( "test_points2", &test_points2);

        register_reflect r5( "left", &point::left);
        register_reflect r6( "top", &point::top);

        test t;
        t.set("ints", "[1, 3, 5]");

        using function::argument;
        using function::result;
        typedef std::vector<argument> array;

        using namespace detail;
        array args;
        args.push_back( argument(&t, "ints") );
        reflect_info().call_func("print_array", args);
        reflect_info().call_func("test_array", args);

        point p1, p2;
        p1.left(10);
        p1.top(20);
        p2.left(100);
        p2.top(200);
        t.m_points.add( p1);
        t.m_points.add( p2);
        args.clear();
        args.push_back( argument(&t, "points") );
        reflect_info().call_func("print_points", args);
        reflect_info().call_func("test_points1", args);
        reflect_info().call_func("modify_points", args);
        reflect_info().call_func("test_points2", args);
        reflect_info().call_func("print_points", args);
    }






    void test_ptrs_before(const reflectable_array<point*> & points) {
        assert( points.size() == 4);
        assert( points.at(0)->left() == 100);
        assert( points.at(0)->top() == 200);
        assert( points.at(1)->left() == 1000);
        assert( points.at(1)->top() == 2000);
        assert( points.at(2)->left() == 1);
        assert( points.at(2)->top() == 2);
        assert( points.at(3)->left() == 2);
        assert( points.at(3)->top() == 4);
    }

    void modify_ptrs(reflectable_array<point*> & points) {
        // switch them
        point * p1 = points.at(0);
        point * p2 = points.at(1);
        point * p3 = points.at(2);
        point * p4 = points.at(3);

        points.at(0, p4);
        points.at(1, p3);
        points.at(2, p2);
        points.at(3, p1);
    }

    void test_ptrs_after(const reflectable_array<point*> & points) {
        assert( points.size() == 4);
        assert( points.at(3)->left() == 100);
        assert( points.at(3)->top() == 200);
        assert( points.at(2)->left() == 1000);
        assert( points.at(2)->top() == 2000);
        assert( points.at(1)->left() == 1);
        assert( points.at(1)->top() == 2);
        assert( points.at(0)->left() == 2);
        assert( points.at(0)->top() == 4);
    }

    struct test_ptr : reflectable_properties_object<test_ptr> {
        reflectable_array<point*> m_ptrs;
    };

    void test_pass_array_of_ptrs_to_func() {
        register_reflect r1( "points", &test_ptr::m_ptrs);
        register_reflect r2( "test_ptrs_before", &test_ptrs_before);
        register_reflect r3( "modify_ptrs", &modify_ptrs);
        register_reflect r4( "test_ptrs_after", &test_ptrs_after);

        point p1, p2, p3, p4;
        p1.left(100);
        p1.top(200);
        p2.left(1000);
        p2.top(2000);
        p3.left(1);
        p3.top(2);
        p4.left(2);
        p4.top(4);

        test_ptr t;
        t.m_ptrs.add( &p1);
        t.m_ptrs.add( &p2);
        t.m_ptrs.add( &p3);
        t.m_ptrs.add( &p4);

        using function::argument;
        using function::result;
        typedef std::vector<argument> array;

        using namespace detail;
        array args;
        args.push_back( argument(&t, "points") );
        reflect_info().call_func("test_ptrs_before", args);
        reflect_info().call_func("modify_ptrs", args);
        reflect_info().call_func("test_ptrs_after", args);
    }




    ///////////////////////////////////////////////////////////////////////////////////
    // testing passing an Array of properties to functions;


    struct inner : reflectable_properties_object<inner> {
        trivial_property<point> m_point;
        trivial_property<std::string> m_str;
        trivial_property<int> m_int;
    };

    struct holder : reflectable_properties_object<holder> {
        reflectable_array<inner> m_objects;
    };

    void dump_ints(const reflectable_array<int> & ints) {
        std::cout << "INT Array size: " << ints.size() << std::endl;
        for ( int idx = 0; idx < (int)ints.size(); ++idx)
            std::cout << "element " << idx << " = " << ints.at(idx) << std::endl;
    }
    void test_ints(const reflectable_array<int> & ints) {
        assert( ints.size() == 4);
        assert( ints.at(0) == 1);
        assert( ints.at(1) == 10);
        assert( ints.at(2) == 100);
        assert( ints.at(3) == 1000);
    }

    void dump_points(const reflectable_array<point> & points) {
        std::cout << "POINT Array size: " << points.size() << std::endl;
        for ( int idx = 0; idx < (int)points.size(); ++idx)
            std::cout << "element " << idx << " = [" << points.at(idx).left() << "," << points.at(idx).top() << "]" << std::endl;
    }
    void test_points(const reflectable_array<point> & points) {
        assert( points.size() == 4);
        assert( points.at(0).left() == 100);
        assert( points.at(0).top() == 200);
        assert( points.at(1).left() == 1000);
        assert( points.at(1).top() == 2000);
        assert( points.at(2).left() == 1);
        assert( points.at(2).top() == 2);
        assert( points.at(3).left() == 2);
        assert( points.at(3).top() == 4);
    }


    void dump_strings(const reflectable_array<std::string> & strings) {
        std::cout << "string Array size: " << strings.size() << std::endl;
        for ( int idx = 0; idx < (int)strings.size(); ++idx)
            std::cout << "element " << idx << " = " << strings.at(idx) << std::endl;
    }
    void test_strings(const reflectable_array<std::string> & strings) {
        assert( strings.size() == 4);
        assert( strings.at(0) == "a");
        assert( strings.at(1) == "b c");
        assert( strings.at(2) == "de");
        assert( strings.at(3) == "f g,h");
    }

    void test_pass_array_of_properties() {
        register_reflect r1("point", &inner::m_point);
        register_reflect r2("string", &inner::m_str);
        register_reflect r22("int", &inner::m_int);
        register_reflect r3("inner", &holder::m_objects);

        register_reflect r4("dump_ints", &dump_ints);
        register_reflect r5("dump_points", &dump_points);
        register_reflect r6("dump_strings", &dump_strings);
        register_reflect r7("test_ints", &test_ints);
        register_reflect r8("test_points", &test_points);
        register_reflect r9("test_strings", &test_strings);

        using function::argument;
        using function::result;
        typedef std::vector<argument> array;

        holder h;


        point p1, p2, p3, p4;
        p1.left(100);
        p1.top(200);
        p2.left(1000);
        p2.top(2000);
        p3.left(1);
        p3.top(2);
        p4.left(2);
        p4.top(4);

        inner i;
        i.m_point(p1);
        h.m_objects.add( i);
        i.m_point(p2);
        h.m_objects.add( i);
        i.m_point(p3);
        h.m_objects.add( i);
        i.m_point(p4);
        h.m_objects.add( i);

        using namespace detail;
        array args;
        args.push_back( argument(&h, "inner.point") );
        reflect_info().call_func("dump_points", args);
        reflect_info().call_func("test_points", args);

        int i1 = 1, i2 = 10, i3 = 100, i4 = 1000;
        i.m_int(i1);
        h.m_objects.at(0, i);
        i.m_int(i2);
        h.m_objects.at(1, i);
        i.m_int(i3);
        h.m_objects.at(2, i);
        i.m_int(i4);
        h.m_objects.at(3, i);
        args.clear();
        args.push_back( argument(&h, "inner.int") );
        reflect_info().call_func("dump_ints", args);
        reflect_info().call_func("test_ints", args);

        std::string s1 = "a", s2 = "b c", s3 = "de", s4 = "f g,h";
        i.m_str(s1);
        h.m_objects.at(0, i);
        i.m_str(s2);
        h.m_objects.at(1, i);
        i.m_str(s3);
        h.m_objects.at(2, i);
        i.m_str(s4);
        h.m_objects.at(3, i);
        args.clear();
        args.push_back( argument(&h, "inner.string") );
        reflect_info().call_func("dump_strings", args);
        reflect_info().call_func("test_strings", args);
    }

}

/* 
    tests using arrays

    Also, tests passing an array to a function
*/
void test_array() {
    test_array_get_set();
    test_pass_array_to_func() ;
    test_pass_array_of_ptrs_to_func();
    test_pass_array_of_properties();
}





