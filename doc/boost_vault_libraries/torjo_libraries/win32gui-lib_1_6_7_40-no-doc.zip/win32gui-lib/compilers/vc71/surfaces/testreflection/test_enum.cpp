// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/reflection/reflection.hpp>
using namespace win32::gui::reflection;

namespace {
    struct day_of_week : reflect_enum {
        enum type {
            mon, tue, wed, thu, fri, sat, sun
        };
        day_of_week() : base( init()
            (mon, "monday")
            (tue, "tuesday")
            (wed, "wednesday")
            (thu, "thursday")
            (fri, "friday")
            (sat, "saturday")
            (sun, "sunday")) {}
    };

    struct holding_enum : reflectable_properties_object<holding_enum> {
        holding_enum() : m_day2(day_of_week::mon) {}

        trivial_property<day_of_week::type> day1;

        day_of_week::type day2() const { return m_day2; }
        void day2(const day_of_week::type & val) { m_day2 = val; }
    private:
        day_of_week::type m_day2;
    };
}

void test_enum() {
    register_reflect r("day_of_week", day_of_week() );
    register_reflect r2("day1", &holding_enum::day1 );
    register_reflect r3("day2", &holding_enum::day2, &holding_enum::day2 );

    // make sure that for all registered variables, we can get/set them
    // (write/read to string)
    using namespace detail;
    reflect_info().validate_member_types();

    holding_enum e;
    e.set("day1", "tuesday");
    assert( e.day1() == day_of_week::tue);
    assert( e.get("day1") == "tuesday");

    e.set("day2", "friday");
    assert( e.day2() == day_of_week::fri);
    assert( e.get("day2") == "friday");

    e.set("day1", "sunday");
    assert( e.day1() == day_of_week::sun);
    assert( e.get("day1") == "sunday");

    e.set("day2", "saturday");
    assert( e.day2() == day_of_week::sat);
    assert( e.get("day2") == "saturday");

}




