// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/reflection/reflection.hpp>
using namespace win32::gui::reflection;

namespace {
    struct test_point : reflectable_properties_object<test_point> {
        trivial_property<int> left;
        trivial_property<long> top;
    };
}


/**
    tests trivial properties
*/
void test_trivial() {
    // register properties
    register_reflect r("left", &test_point::left);
    register_reflect r2("top", &test_point::top);

    // register types
    register_reflect_type<int> r3("int");
    register_reflect_type<long> r4("long");

    // make sure that for all registered variables, we can get/set them
    // (write/read to string)
    using namespace detail;
    reflect_info().validate_member_types();

    test_point pnt;

    // test setters for test_point
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(pnt)) ][ "left" ].set->do_set( &pnt, "5");
    assert( pnt.left() == 5);
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(pnt)) ][ "top" ].set->do_set( &pnt, "10");
    assert( pnt.top() == 10);
    // test getters for test_point
    pnt.left(7);
    pnt.top(8);
    std::string str;
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(pnt)) ][ "left" ].get->do_get( &pnt, str);
    assert( str == "7");
    reflect_info().m_reflectable_types[ typeinfo_holder(typeid(pnt)) ][ "top" ].get->do_get( &pnt, str);
    assert( str == "8");

}


