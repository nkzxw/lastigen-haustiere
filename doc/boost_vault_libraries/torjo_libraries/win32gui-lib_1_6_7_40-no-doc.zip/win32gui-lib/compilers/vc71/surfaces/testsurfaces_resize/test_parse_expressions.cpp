// testreflection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/draw/surfaces/detail/expression.hpp>
#include <sstream>

using namespace win32::gui::draw;

namespace {
    std::string printed(const expression & e) {
        std::ostringstream out;
        e.print(out);
        return out.str();
    }
}

/** 
    tests how expressions are parsed
*/
void test_parse_expressions() {
    expression e1("a + b - c * d + e");
    expression e2("a + (b - c) * d + e");
    expression e22("a * b / c * d / e");
    
    expression e23("a + (b - c) * d / e + f");
    expression e24("a / b / c * d / e * f / g / h * i");

    expression e3("a + (b - c) * d + func(e,3,\"4\"\"5\",a + b - c,a * b - c)");
    expression e4("(a >= b || a < c) && a == func(c) && b >= c + a");

    assert( printed(e1) == " { [a] + [ ( (b) + -( (c) * (d) ) ) + (e) ] } ");
    assert( printed(e2) == " { [a] + [ ( ( (b) + -(c) ) * (d) ) + (e) ] } ");
    assert( printed(e22) == " { [a] * [ ( (b) / (c) ) * ( (d) / (e) ) ] } ");
    assert( printed(e23) == " { [a] + [ ( ( (b) + -(c) ) * ( (d) / (e) ) ) + (f) ] } ");
    assert( printed(e24) == " { [ (a) / ( (b) / (c) ) ] * [ ( (d) / (e) ) * ( ( (f) / ( (g) / (h) ) ) * (i) ) ] } ");
    assert( printed(e3) == " { [a] + [ ( ( (b) + -(c) ) * (d) ) + (func( (e) , (3) , (\"4\"\"5\") , ( (a) + ( (b) + -(c) ) ) , ( ( (a) * (b) ) + -(c) ) )) ] } ");

    assert( printed(e4) == " { [ ( (a) >= (b) ) || ( (a) < (c) ) ] && [ ( (a) == (func( (c) )) ) && ( (b) >= ( (c) + (a) ) ) ] } ");
//    assert( printed(e1) == "");
  //  assert( printed(e1) == "");

    std::cout << printed(e4) << std::endl;
}


