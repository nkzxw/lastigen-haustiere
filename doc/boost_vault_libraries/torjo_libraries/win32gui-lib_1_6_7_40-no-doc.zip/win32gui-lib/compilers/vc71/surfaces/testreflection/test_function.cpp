// testreflection.cpp : Defines the entry test_point for the console application.
//

#include "stdafx.h"

#include <win32gui/window.hpp>
#include <win32gui/reflection/reflection.hpp>
using namespace win32::gui::reflection;

namespace {
    struct test_point : reflectable_properties_object<test_point> {
        test_point() : m_left(0), m_top(0) {}

        void left(int val) { m_left = val; }
        int left() const { return m_left; }

        void top(int val) { m_top = val; }
        int top() const { return m_top; }
    private:
        int m_left;
        int m_top;
    };

    struct test_rectangle : reflectable_properties_object<test_rectangle> {
        trivial_property<int> left;
        trivial_property<int> top;
        trivial_property<int> width;
        trivial_property<int> height;
    };

    struct keeper : reflectable_properties_object<keeper> {
        trivial_property<test_point> pnt;
        trivial_property<test_rectangle> rect;
        trivial_property<std::string> name;
    };


    void print() {
        std::cout << "print called" << std::endl;
    }

    int area(const test_rectangle & r) {
        return r.width() * r.height();
    }

    void increment_rect(test_rectangle & r) {
        r.left( r.left() + 1);
        r.top( r.top() + 1);
    }

    void increment_test_point(test_point & p) {
        p.left( p.left() + 1);
        p.top( p.top() + 1);
    }

    int topleft(const test_point & p) {
        return p.left() + p.top();
    }

    // adds this test_point to the test_rectangle
    void add_test_point(test_rectangle & rect, const test_point & pnt) {
        rect.left( rect.left() + pnt.left() );
        rect.top( rect.top() + pnt.top() );
    }

    // ... note: test_point passed by value
    void set_test_point(test_rectangle & rect, test_point pnt) {
        rect.left( pnt.left() );
        rect.top( pnt.top() );
    }

    void increment(int & i, int val) {
        i += val;
    }

    void set_name(std::string & name, const std::string & val) {
        name = val;
    }

    int compare(const std::string & a, const std::string & b) {
        if ( a < b) return -1;
        if ( a == b) return 0;
        return 1;
    }

    // just testing function result!
    test_rectangle get_rect(const test_rectangle & r) {
        return r;
    }

    test_point get_test_point_from_keeper(const keeper & k) {
        return k.pnt();
    }

    void set_keeper_name(keeper & k, const std::string & name) {
        k.name( name);
    }
}


/** 
    Tests calling functions from scripting
*/
void test_function() {
    // register properties
    register_reflect r1("left", &test_point::left, &test_point::left);
    register_reflect r2("top", &test_point::top, &test_point::top);

    register_reflect r3("left", &test_rectangle::left);
    register_reflect r4("top", &test_rectangle::top);
    register_reflect r5("width", &test_rectangle::width);
    register_reflect r6("height", &test_rectangle::height);

    register_reflect r7("test_point", &keeper::pnt);
    register_reflect r8("rect", &keeper::rect);
    register_reflect r9("name", &keeper::name);

    // register functions
    register_reflect r10("print", &print);
    register_reflect r11("area", &area);
    register_reflect r12("increment_rect", &increment_rect);
    register_reflect r13("increment_test_point", &increment_test_point);
    register_reflect r14("topleft", &topleft);
    register_reflect r15("add_test_point", &add_test_point);
    register_reflect r16("set_test_point", &set_test_point);
    register_reflect r17("increment", &increment);
    register_reflect r18("set_name", &set_name);
    register_reflect r19("compare", &compare);
    register_reflect r20("get_rect", &get_rect);
    register_reflect r202("get_test_point", &get_test_point_from_keeper);
    register_reflect r203("set_keeper_name", &set_keeper_name);

    // register types
    register_reflect_type<int> r21("int");
    register_reflect_type<std::string> r22("string");

    using namespace detail;
    reflect_info().validate_member_types();

    using function::argument;
    using function::result;
    typedef std::vector<argument> array;

    array args;
    reflect_info().call_func("print", args);

    keeper k1, k2;

    k1.set("rect.width", "10");
    k1.set("rect.height", "15");
    result r;
    args.clear();
    args.push_back( argument(&k1,"rect") );
    r = reflect_info().call_func("area", args);
    assert( r.val() == "150" );

    k1.rect( ::test_rectangle() );
    args.clear();
    args.push_back( argument(&k1,"rect") );
    r = reflect_info().call_func("increment_rect", args);
    assert( k1.get("rect.left") == "1");
    assert( k1.get("rect.top") == "1");

    args.clear();
    args.push_back( argument(&k1,"test_point") );
    r = reflect_info().call_func("increment_test_point", args);
    assert( k1.get("test_point.left") == "1");
    assert( k1.get("test_point.top") == "1");

    k1.set("test_point.left", "5");
    k1.set("test_point.top", "10");
    args.clear();
    args.push_back( argument(&k1,"test_point") );
    r = reflect_info().call_func("topleft", args);
    assert( r.val() == "15");

    k2.set("test_point.left", "100");
    k2.set("test_point.top", "200");
    k1.set("rect.left", "50");
    k1.set("rect.top", "100");
    args.clear();
    args.push_back( argument(&k1,"rect") );
    args.push_back( argument(&k2,"test_point") );
    r = reflect_info().call_func("add_test_point", args);
    assert( k1.get("rect.left") == "150");
    assert( k1.get("rect.top") == "300");

    k1.set("test_point.left", "100");
    k1.set("test_point.top", "200");
    ::test_rectangle rect;
    args.clear();
    args.push_back( argument(&rect,"") );
    args.push_back( argument(&k1,"test_point") );
    r = reflect_info().call_func("set_test_point", args);
    assert( rect.get("left") == "100");
    assert( rect.get("top") == "200");



    k1.set("rect.left", "100");
    k1.set("rect.width", "100");
    k1.set("rect.height", "100");
    k1.set("test_point.left", "100");

    args.clear();
    args.push_back( argument(&k1,"rect.left") );
    args.push_back( argument("10") );
    r = reflect_info().call_func("increment", args);

    args.clear();
    args.push_back( argument(&k1,"test_point.left") );
    args.push_back( argument("1") );
    r = reflect_info().call_func("increment", args);

    args.clear();
    args.push_back( argument(&k1,"rect.width") );
    args.push_back( argument("50") );
    r = reflect_info().call_func("increment", args);

    args.clear();
    args.push_back( argument(&k1,"rect.height") );
    args.push_back( argument("2") );
    r = reflect_info().call_func("increment", args);

    assert( k1.get("rect.left") == "110");
    assert( k1.get("rect.width") == "150");
    assert( k1.get("rect.height") == "102");
    assert( k1.get("test_point.left") == "101");


    args.clear();
    args.push_back( argument(&k1,"name") );
    args.push_back( argument("John Doe") );
    r = reflect_info().call_func("set_name", args);
    assert( k1.get("name") == "John Doe");

    k2.set("name", "Abraham");
    args.clear();
    args.push_back( argument(&k2,"name") );
    args.push_back( argument(&k1,"name") );
    r = reflect_info().call_func("compare", args);
    assert( r.val() == "-1");


    k1.set("rect.left", "100");
    k1.set("rect.top", "200");
    k1.set("rect.width", "300");
    k1.set("rect.height", "400");
    args.clear();
    args.push_back( argument(&k1,"rect") );
    r = reflect_info().call_func("get_rect", args);
    test_rectangle * result_rect = dynamic_cast<test_rectangle*>( r.obj().get() );
    assert( result_rect->get("left") == "100");
    assert( result_rect->get("top") == "200");
    assert( result_rect->get("width") == "300");
    assert( result_rect->get("height") == "400");

    k1.set("test_point.left", "100");
    k1.set("test_point.top", "200");
    args.clear();
    args.push_back( argument(&k1,"") );
    r = reflect_info().call_func("get_test_point", args);
    test_point* result_pnt = dynamic_cast<test_point*>( r.obj().get() );
    assert( result_pnt->get("left") == "100");
    assert( result_pnt->get("top") == "200");

    args.clear();
    args.push_back( argument(&k1,"") );
    args.push_back( argument("My Cool Keeper") );
    r = reflect_info().call_func("set_keeper_name", args);
    assert( k1.get("name") == "My Cool Keeper");
}

