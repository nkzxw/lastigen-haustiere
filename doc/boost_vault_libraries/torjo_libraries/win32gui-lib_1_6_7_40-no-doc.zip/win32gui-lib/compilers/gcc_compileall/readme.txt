Get the latest Dev-C++ (including migw for Windows) from
http://www.bloodshed.net
