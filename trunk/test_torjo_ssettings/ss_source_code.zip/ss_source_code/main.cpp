// Straightforward Settings Library
//
// Copyright 2007 John Torjo (john@macadamian.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
//
// Find latest version of this at http://www.macadamian.ro/drdobbs/




#include "ss/setting.h"
#include "ss/configuration.h"
#include "ss/file_storage.h"
#include "ss/registry_storage.h"
#include <vector>

using namespace ss;

typedef enum answer {
  yes = 10, no, maybe
};

void ss::init_settings( ) {
    def_cfg().add_storage(TTEXT("user"), new file_storage("user.ini"));
    def_cfg().add_storage(TTEXT(""), new registry_storage(TTEXT("CU/Software/sstest")));
    def_cfg().set_error_handler(err::do_log_do_dbg_wnd);

    // defaults
    setting(TTEXT("user.a")) = 5;
    setting(TTEXT("a.b")) = TTEXT("amazingly def");

    bulk_setting(
        TTEXT("chart.window.width=100"),
        TTEXT("chart.window.height=50"),
        TTEXT("user.ab=yes_or_no"),
        TTEXT("tmp.del_period=20"));

  register_enum<answer>()
    (yes,TTEXT("Yes"))(no,TTEXT("No"))(maybe,TTEXT("yes_or_no"));
}

int main()
{
    std::vector<int> v, v2;
    v.push_back(5);
    v.push_back(7);
    v.push_back(9);
    v.push_back(4);
    std::vector<bool> vb,vb2;
    vb.push_back(true);
    vb.push_back(false);
    vb.push_back(true);
    vb.push_back(false);
    array(setting(TTEXT("user.arr1"))) = v;
    v2 = array(setting(TTEXT("user.arr1"))) ;
    assert(v == v2);
    array(setting(TTEXT("user.arr2"))) = vb;
    vb2 = array(setting(TTEXT("user.arr2")));
    assert(vb == vb2);

    long l[5] = { 0 , 1, 2, 3, 4};
    array(setting(TTEXT("user.arr3")),5) = l;
//    long l2[5];
//    l2 = array(setting(TTEXT("user.arr3")),5);

    std::map<long, int> m, m2;
    m[10] = 1;
    m[50]= 5;
    m[-2] = 20;
    m[-10] = -100;
    coll(setting(TTEXT("user.col1"))) = m;
    m2 = coll(setting(TTEXT("user.col1")));
    assert( m == m2);

    answer aa = setting(TTEXT("user.aa"));
    setting(TTEXT("user.aa")) = yes;
    answer ans = setting(TTEXT("user.ab"));

    int i = setting(TTEXT("user.a"));
    string b = setting(TTEXT("a.b"));

    enum_(setting(TTEXT("user.default_answer"))) = maybe;
    answer a = enum_(setting(TTEXT("user.default_answer")));
    

    int width = setting(TTEXT("CHART.window.width"));
    int height = setting(TTEXT("CHART.window.Height"));
    int del_p = setting(TTEXT("Tmp.del_perioD"));
    // get
    string name = setting(TTEXT("user.name"));
    string pass = setting(TTEXT("user.passw"));
    long retries = setting(TTEXT("app.retries"));
    retries = setting(TTEXT("app.retries"));

    // set
    setting(TTEXT("app.retries")) = 5;
    setting(TTEXT("user.retries")) = 5;
    setting(TTEXT("user.name")) = TTEXT("amazingly cool ...");
    setting(TTEXT("user.passw")) = TTEXT("secret");

    setting<bool>(TTEXT("user.test")) = false;

    // forced get
    long w = setting<long>(TTEXT("width"));

    // forced set
    setting<unsigned long>(TTEXT("width")) = 12400;


    setting(TTEXT("app.retries")) = 5;
    setting(TTEXT("app.retries2")) = 1500;
    setting(TTEXT("app.retries3")) = 15000ul;
    string s = setting(TTEXT("app.retries"));
    s = setting(TTEXT("app.retries2")).c_str();
    s = setting(TTEXT("app.retries3")).c_str();

	return 0;
}

