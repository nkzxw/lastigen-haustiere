#include "placement_src.hpp"

namespace user_project
{
    BOOST_SINGLETON_PLACEMENT(S1)
    BOOST_SINGLETON_PLACEMENT(S2)
    BOOST_SINGLETON_PLACEMENT(S3)
}

