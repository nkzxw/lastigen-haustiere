#include "placement_src.hpp"

using namespace user_project;

int main()
{
    S1::instance->foo();
    S2::instance->foo();
    S3::instance->foo();

    return 0;
}

