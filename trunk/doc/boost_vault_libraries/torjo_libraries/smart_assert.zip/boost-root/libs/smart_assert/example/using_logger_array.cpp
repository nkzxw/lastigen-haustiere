// using_logger_array.cpp 
//
/*
    Using the logger_array:
    logging to file, console, and Debug Window (win32)
*/

// uncomment this, for the SMART_ASSERTs to behave just like
// in Release mode (that is, turning off SMART_ASSERTions)
//
// #define BOOST_SMART_ASSERT_MODE 0

#include <boost/smart_assert_ext.hpp>

#include <iostream>
#include <string>
#include <list>

using namespace boost::smart_assert;


void test_loggerarray() {

    int *one = 0;
    int *two = 0;
    int *three = 0;

    SMART_ASSERT(one);
    SMART_ASSERT(two);
    SMART_ASSERT(three);
}




void dump_summary_to_cout( const assert_context & context) {
    dump_assert_context_summary( context, std::cout );
}


int main()
{
    configs_array().run_config( "ignore");

    logger_array a;

    // existing logger
    assert_context_func to_file = assert_settings().get_logger();
    a.add_logger( to_file);
    // log to cout
    a.add_logger( &dump_summary_to_cout);
#if defined( BOOST_SMART_ASSERT_WIN32)
    // log to Dbg Window
    a.add_logger( &output_to_debug_wnd_win32);
#endif
    assert_settings().set_logger( a);

    for ( int idx = 0; idx < 5; ++idx) 
        test_loggerarray();
    std::cout << "\nExample over. Press a non-space key." << std::endl;

    while ( isspace( std::cin.get() ));
    return 0;
}

