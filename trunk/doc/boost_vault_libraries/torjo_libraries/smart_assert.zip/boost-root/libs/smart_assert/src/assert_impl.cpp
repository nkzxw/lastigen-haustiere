
// implementation

#include <boost/smart_assert/assert_impl.hpp>
