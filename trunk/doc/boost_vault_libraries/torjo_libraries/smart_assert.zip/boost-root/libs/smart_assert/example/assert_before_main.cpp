// assert_before_main.cpp

//
/*
    see what happens when an ASSERT fails before main()!
*/

// uncomment this, for the SMART_ASSERTs to behave just like
// in Release mode (that is, turning off SMART_ASSERTions)
//
// #define BOOST_SMART_ASSERT_MODE 0


#include <boost/smart_assert_ext.hpp>

using namespace boost::smart_assert;


// note:
//
// It's most likely that s_Test's constructor will be called
// BEFORE constructing the before_main initializer
//
// this means that we initialize the SMART_ASSERT library 
// in Assert's constructor
struct Test {
    Test() {
        SMART_ASSERT( false).msg( "this failed before main()");    
    }
} s_Test;




int main() {
    std::cout << "\nExample over. Press a non-space key." << std::endl;

    while ( isspace( std::cin.get() ));

    return 0;
}
