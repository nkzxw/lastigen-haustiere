/* 
    test_print_to_stream - tests the print_to_stream footprint
    (how many bytes are used for a print_to_stream call)
*/


#include <boost/smart_assert/priv/impl/smart_assert_tostream.hpp>
#include <iostream>
#include <assert.h>


struct action_print_to_stream_int {
    template< int idx>
    struct action {
        action() {
            int i = idx;
            print_to_stream( std::cout, i);
        }
    };
};


struct action_print_to_stream_using_raw_int {
    template< int idx>
    struct action {
        action() {
            const int i = idx;
            print_to_stream_raw( std::cout, i);
        }
    };
};


struct action_assert {
    template< int idx>
    struct action {
        action() {
            assert( i && std::cout.good());
        }
    };
};






template< int idx, class do_action>
struct contain_class : contain_class< idx - 1, do_action> {
    contain_class() {
        typedef typename do_action::action< idx> action_type;
        action_type value;
    }
};

// VC6 - no partial specialization
template<> struct contain_class< 0, action_print_to_stream_int> {};
template<> struct contain_class< 0, action_print_to_stream_using_raw_int> {};
template<> struct contain_class< 0, action_assert> {};


/*
    note:
    modify the values of COUNT, generate the Release version of 
    this program, and see the footprint of 'print_to_stream'
*/
const int COUNT = 1192;




int main()
{
    contain_class< COUNT, action_print_to_stream_int> test;
//    contain_class< COUNT, action_assert> test2;
//    contain_class< COUNT, action_print_to_stream_using_raw_int> test3;

    std::cin.get();
    return 0;
}



