// assert_simple.cpp 
//
/*
    Using SMART_ASSERT with win32 handles 
    (asking the user is by showing a dialog)
*/


// uncomment this, for the SMART_ASSERTs to behave just like
// in Release mode (that is, turning off SMART_ASSERTions)
//
// #define BOOST_SMART_ASSERT_MODE 0

#include <boost/smart_assert/assert_impl.hpp>

#include <iostream>
#include <string>
#include <list>

using namespace boost::smart_assert;



void test_assert()
{
    int i, j, k;
    k = 1;
    i = 3;
    j = 2;
    SMART_ASSERT( (i < j) || (i == 3) || (j == 1) ) (i)(j);
    SMART_ASSERT( (i < j) || (i < 0) || (k == -1) ) (i)(j)(k);

    // shortcut, instead of SMART_ASSERT(p)(p);
    int *p = 0;
    SMART_ASSERT(p);
}


void test_assert_range() {

    std::list< int> l;
    l.push_back( 1);
    l.push_back( 2);
    l.push_back( 3);
    l.push_back( 4);
    l.push_back( 5);
    l.push_back( 6);
    l.push_back( 7);
    l.push_back( 0);

    std::list< int>::const_iterator first = l.begin(), last = l.end();
    // compare the first and last element from the list
    SMART_ASSERT( *first < *l.rbegin()) (range_(first,last));

}





int main()
{
    configs_array().run_config( "dbg_win");

    test_assert();
    test_assert_range();

    std::cout << "\nExample over. Press a non-space key." << std::endl;

    while ( isspace( std::cin.get() ));
    return 0;
}

