// Example - SMART_ENFORCE.cpp



#include <boost/smart_assert_ext.hpp>
#include <iostream>

#if defined( BOOST_SMART_ASSERT_WIN32)
    #include <io.h> // only on Windows platforms,

#else

    #ifdef BOOST_HAS_UNISTD_H
    // for Unix, instead of #include <io.h>
    #include <unistd.h>
    #define _read read
    #endif

#endif




struct Test
{
    Test( int i) : m_i( i)
    {}
    void print_i()
    { std::cout << "test=" << m_i << std::endl; }
private:
    int m_i;
};


void test_enforce()
{
    // writing to enforced std::cout - works
    SMART_ENFORCE( std::cout) << "writing to enforced cout" << std::endl;

    // writing to enforced pointer - works
    int i = 0;
    int *p = &i;
    int *p2 = SMART_ENFORCE( p);
    *p2 = 1;

    // trying to modify NULL value
    try {
        p = 0;
        *( SMART_ENFORCE( p)) = 1;
        std::cout << "SHOULD NEVER ARIVE HERE!!!" << std::endl;
    } catch( std::exception & exc) {
        std::cout << exc.what() << std::endl;
    }

    // trying to get NULL value
    try {
        int * p3 = SMART_ENFORCE( p);
        std::cout << "SHOULD NEVER ARIVE HERE!!!" << std::endl;
    } catch( std::exception & exc) {
        std::cout << exc.what() << std::endl;
    }

    // writing to enforced pointer - works
    Test t( 10);
    Test * pTest = &t;
    (SMART_ENFORCE(pTest)) ->print_i();

    // writing to enforced pointer - fails
    try {
        pTest = 0;
        (SMART_ENFORCE(pTest)) ->print_i();
        std::cout << "SHOULD NEVER ARIVE HERE!!!" << std::endl;
    } catch( std::exception & exc) {
        std::cout << exc.what() << std::endl;
    }
}


struct HandlePredicate {
    static bool is_wrong(long handle) {
        return handle == -1;
    }
};

#define HANDLE_ENFORCE(expr) SMART_ENFORCE_EXT(expr, HandlePredicate())

void test_custom_enforce() {
    // will of course fail
    int file = -1;
    void *buffer = NULL;
    int buflen = 40;
    try {
        const int available = 
            HANDLE_ENFORCE(_read(file, buffer, buflen))(file)(buffer)(buflen).msg( "could not read from file");
        std::cout << "SHOULD NEVER ARIVE HERE!!!" << std::endl;
    } catch( std::exception & exc) {
        std::cout << exc.what() << std::endl;
    }

}

int main() {

    test_enforce();
    test_custom_enforce();
 
    std::cout << "\nExample over. Press a non-space key." << std::endl;

    while ( isspace( std::cin.get() ));
    return 0;
}
