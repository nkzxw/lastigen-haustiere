// verify.cpp 
//
/*
    Using SMART_VERIFY, 
    Using SMART_VERIFY_RET
*/


// uncomment this, for the SMART_ASSERTs to behave just like
// in Release mode (that is, turning off SMART_ASSERTions)
//
// #define BOOST_SMART_ASSERT_MODE 0

#include <boost/smart_assert_ext.hpp>

#include <iostream>
#include <string>
#include <list>

using namespace boost::smart_assert;

void test_verify() {

    int i, j, k;
    k = 1;
    i = 3;
    j = 2;

    // usage - just like SMART_ASSERT !!!
    try {
        SMART_VERIFY( (i < j) || (i < 0) || (k == -1) ) (i)(j)(k);
        std::cout << "SHOULD NEVER ARRIVE HERE!!!" << std::endl;
    }
    catch ( std::exception & exc) {
        std::cout << exc.what() << std::endl;
    }

    // using the .msg function
    try {
        SMART_VERIFY( (i < j) && (i == 3) && (j == 1) ) (i)(j)
            .msg( "as expected, this failed");
        std::cout << "SHOULD NEVER ARRIVE HERE!!!" << std::endl;
    }
    catch ( std::exception & exc) {
        std::cout << exc.what() << std::endl;
    }

    // setting level to 'debug'
    int *p = 0;
    SMART_VERIFY(p).debug( "we'll ask the user what to do");

}


// calculates n!
int factorial( int n) {
    SMART_VERIFY_RET( n >= 0)(n) .ret_on_fail(-1);

    if ( n == 0) return 1;
    else if ( n == 1) return 1;
    else return n * factorial( n - 1);
}

void test_verify_ret() {

    std::cout << "factorial(3) = " << factorial( 3) << std::endl;
    std::cout << "factorial(2) = " << factorial( 2) << std::endl;
    std::cout << "factorial(1) = " << factorial( 1) << std::endl;
    std::cout << "factorial(0) = " << factorial( 0) << std::endl;
    std::cout << "factorial(-1) = " << factorial( -1) << std::endl;
    std::cout << "factorial(-2) = " << factorial( -2) << std::endl;
    std::cout << "factorial(-3) = " << factorial( -3) << std::endl;
    std::cout << "factorial(-4) = " << factorial( -4) << std::endl;
    std::cout << "factorial(-5) = " << factorial( -5) << std::endl;
}




int main()
{
    test_verify();
    test_verify_ret();

    std::cout << "\nExample over. Press a non-space key." << std::endl;

    while ( isspace( std::cin.get() ));
    return 0;
}

