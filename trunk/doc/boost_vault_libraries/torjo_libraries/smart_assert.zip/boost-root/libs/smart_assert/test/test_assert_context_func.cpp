// test_assert_context_func.cpp

/*
    Tests the implementation of the assert_context_func class.
*/

#include <boost/smart_assert.hpp>
#include <iostream>
#include <functional>

using namespace boost::smart_assert;

static int g_test = 0;

void f( const assert_context & ) {
    std::cout << "f()" << std::endl;
    g_test++;
}

struct Test {
    void operator() ( const assert_context & ) {
        std::cout << "Test()" << std::endl;
        g_test += 2;
    }
};


int test_failed() {
    std::cout << "Test FAILED!" << std::endl;
    return -1;
}

int main() {

    assert_context_func a;
    assert_context_func b( &f);
    Test t;
    assert_context_func c( t);
    assert_context_func d( c);
    assert_context_func e = b;

    assert_context ctx;
    a( ctx);
    b( ctx);
    if ( g_test != 1) return test_failed();

    c( ctx);
    if ( g_test != 3) return test_failed();

    d( ctx);
    if ( g_test != 5) return test_failed();

    e( ctx);
    if ( g_test != 6) return test_failed();

    std::cout << "Test succeeded" << std::endl;
    return 0;
}
