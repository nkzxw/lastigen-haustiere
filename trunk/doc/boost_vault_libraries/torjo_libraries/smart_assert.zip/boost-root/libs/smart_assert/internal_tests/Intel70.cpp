
// crashes on Intel 7.0 ???
#define BOOST_SMART_ASSERT_NO_CUSTOM_ALLOC
#include <boost/smart_assert.hpp>
#include <boost/smart_assert_ext.hpp>

namespace boost { namespace smart_assert {
    smart_assert_initializer initializer( "./assert.txt", "./persist.txt",
&default_initialize);
}}


int main()
{
    char* aline = 0;
    SMART_ASSERT(aline);

    return 0;
}
