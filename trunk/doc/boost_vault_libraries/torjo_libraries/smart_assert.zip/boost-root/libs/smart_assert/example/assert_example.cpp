// assert_example.cpp 
#include <boost/smart_assert_ext.hpp>

void login_admin( const std::string & username, const std::string & passw) {
    SMART_ASSERT( username == "admin" && passw == "secret") (username)(passw)
        .msg( "Unauthorized administrator login!");
}

int main() {
    login_admin( "admin", "anonymous");
    return 0;
}


// FIXME in the docs:

/*

    symbol_key key = std::make_pair( m_current_symbol, period);
    symbol_infos::const_iterator info = m_symbols.find( key);
    if ( info != m_symbols.end() ) {
        return info->second.get_first_in_between( secs, earliest);
    }
    else {
        // unknown symbol!!!
        ASSERT( false);
        return earliest;
    }

This could be:
SMART_ASSERT( false) (current_symbol)(period).msg( "unknown symbol!");

*/