// assert_simple.cpp 
//
/*
    Simple usage of SMART_ASSERT;
    usage of the v_ macro;
    printing ranges (within SMART_ASSERT);
*/


// uncomment this, for the SMART_ASSERTs to behave just like
// in Release mode (that is, turning off SMART_ASSERTions)
//
// #define BOOST_SMART_ASSERT_MODE 0

#include <boost/smart_assert/assert_impl.hpp>

#include <iostream>
#include <string>
#include <list>



using namespace boost::smart_assert;


void test_first_second( int first, int second) {
    if ( first < second)
        SMART_ASSERT( first > second)(first)(second);
    else
        SMART_ASSERT( first < second)(first)(second);
}

void test_null_str() {
    char* aline = 0;
    SMART_ASSERT( aline);
    SMART_ASSERT( aline)( aline);

    const char * aline_const = 0;
    SMART_ASSERT( aline_const);
    SMART_ASSERT( aline_const)( aline_const);
}

void test_assert()
{
    int i, j, k;
    k = 1;
    i = 3;
    j = 2;
    SMART_ASSERT( (i < j) || (i == 3) || (j == 1) ) (i)(j);
    SMART_ASSERT( (i < j) || (i < 0) || (k == -1) ) (i)(j)(k);

    // shortcut, instead of SMART_ASSERT(p)(p);
    int *p = 0;
    SMART_ASSERT(p);

    test_first_second( 1, 2);
    test_first_second( 2, 1);
}


// should NEVER be called twice!
int function_once() {
    static int idx = 0;
    if ( ++idx > 1)
        std::cout << "ERROR: this function should NEVER be called twice" << std::endl;
    return 0;
}

void test_assert_use_v_() {
    int i, j;
    i = 3;
    j = 2;
    // the v_ macro should be used ONLY when the tested
    // function might take a while (the tested function is slow);
    // 
    // then, we would not want the slow function to be called twice, 
    // in case the assertion fails (see below).



    // use the v_ macro!
    //
    // this way, the function_once() will be called only once!
    //
    // if we were to use
    // 'SMART_ASSERT( function_once() || (i == j) )(function_once())(i)(j)';
    // function_once() would be called twice, since the assertion fails
    SMART_ASSERT_V_( v_(function_once()) || (i == j) )(i)(j);
}

void test_assert_range() {

    std::list< int> l;
    l.push_back( 1);
    l.push_back( 2);
    l.push_back( 3);
    l.push_back( 4);
    l.push_back( 5);
    l.push_back( 6);
    l.push_back( 7);
    l.push_back( 0);

    std::list< int>::const_iterator first = l.begin(), last = l.end();
    // compare the first and last element from the list
    SMART_ASSERT( *first < *l.rbegin()) (range_(first,last));

}




int main()
{
    test_null_str();
    test_assert();
    test_assert_use_v_();
    test_assert_range();

    std::cout << "\nExample over. Press a non-space key." << std::endl;

    while ( isspace( std::cin.get() ));
    return 0;
}

/*
ENTERING ASSERT RECURSIVELY

For instance, an assert is triggered, and we're logging it.
While logging it, we enter it again!


We have to have a way to know which asserts are entered at this moment.
If entering it again, we will JUST IGNORE IT (eventually, call a critical logger,
                                              when this is possible!)


                                              - see how threads interact with this!*/