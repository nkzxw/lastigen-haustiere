// test_smart_assert_footprint.cpp

/* 
    (together with test_smart_assert_footprint2.cpp)
    tests the footprint of SMART_ASSERT
    (how many bytes are used for a SMART_ASSERT)
*/

/*
    Notes:
    (July 26, 2003 - redesigned the tests)

    Date            Type of compilation             Measuring for   Avg Footprint  Notes
    July 26, 2003   VC6, release mode,              test_1          160            -
                         compiled for speed: 

    July 26, 2003   VC6, release mode,              test_1          118            -
                         compiled for minsize:      

    July 26, 2003   VC6, release mode,              test_2          240            -
                         compiled for speed:      

    July 26, 2003   VC6, release mode,              test_2          180            -
                         compiled for minsize:      
    July 26, 2003   gcc3.2, "-Os" setting           test_1          220

    ---------------------------------------------------------------------
    July 19, 2003   VC6, release mode,              test_1          245            -
                         compiled for speed: 

    July 19, 2003   VC6, release mode,              test_1          194            -
                         compiled for minsize:      

    July 19, 2003   VC6, release mode,              test_2          276            -
                         compiled for speed:      

    July 19, 2003   VC6, release mode,              test_2          215            -
                         compiled for minsize:      

    July 19, 2003   gcc3.2, "-Os" setting           test_1          267            the size is this big,
                    (anyway, gave up on gcc,                                       since for gcc, the SMART_ASSERT_CONTEXT
                     seems to be ignoring the                                      contains the function name as well (which
                     __attribute__((noinline))                                     in our case is very LARGE)
                     setting. generates poor code)


*/


// we're in release mode, turn on SMART_ASSERTs
#define BOOST_SMART_ASSERT_MODE 1

#include <boost/smart_assert.hpp>
#include <iostream>
#include <assert.h>
#include <fstream>
#include <stdlib.h>

void compute_avg_footprint( const char * exe_name, int count);

////////////////////////////////////////////////////////////
// possible footprints we can test for

#define test_1 SMART_ASSERT( ( i < 0) || ( i >= 1000)) (i);
#define test_2 SMART_ASSERT( i && std::cout.good() )( i);

/*
  (for footprint)
  ORIGINAL:
if ( boost::smart_assert::Private::keeper boost_private_assert_keeper = 0) ; 
else if ( boost_private_assert_keeper.test_expr(i, "i" ) ) ; 
else 
    boost::smart_assert::make_assert().SMART_ASSERT_CONTEXT.print_prewrittern_values( boost_private_assert_keeper).SMART_ASSERT_A.print_current_val((i), "i").SMART_ASSERT_B;


Re-designed into:

using namespace boost::smart_assert;
if ( Private::keeper k = 0) ; 
else if ( k.test_expr(i, "i" ) ) ; 
else 
    make_assert().
        SMART_ASSERT_CONTEXT.
        print_prewrittern_values( k).
        SMART_ASSERT_A.
        print_current_val(i, "i").
        SMART_ASSERT_B;



and then into:

using namespace boost::smart_assert;
if ( Private::keeper k = 0) ; 
else if ( k.test_expr(i, "i" ) ) ; 
else 
    make_assert().
        context(BOOST_SMART_ASSERT_FILE_KEY,BOOST_SMART_ASSERT_FILE).
        context(BOOST_SMART_ASSERT_LINE_KEY,__LINE__).
        print_prewrittern_values( k).
        SMART_ASSERT_A.
        print_current_val(i, "i").
        SMART_ASSERT_B;

*/
#define test_footprint \
    if ( i && std::cout.good() ) ;                              \
    else                                                        \
        make_assert().                                          \
            test_expr( i, "i").                                 \
            context(BOOST_SMART_ASSERT_FILE_KEY, BOOST_SMART_ASSERT_FILE).           \
            context(BOOST_SMART_ASSERT_LINE_KEY, __LINE__).     \
            SMART_ASSERT_A.                                     \
            print_current_val(i, "i").                          \
            SMART_ASSERT_B;                                     

#define test_simple_footprint make_assert();


// END OF possible footprints we can test for
////////////////////////////////////////////////////////////




/*
    note:
    see the footprint of SMART_ASSERT or assert

    ** Check out the "footprint" macro, to see the footprint
    you're testing for **


    HERE IS HOW TO TEST:

    First, #define COUNT 1 (define COUNT to be one) 
    Then, generate the release version,
    and run it. This will output this file size to "size.txt" file.

    Then, #define COUNT to be any of 101, 201, 301, ... 1001,
    generate the release version and run it.

    (note: the more COUNT, the more compilation time)

    This will read the "size.txt" file, know current file size, 
    and output the average footprint of SMART_ASSERT.

    Note that this is just an estimate.
*/


// *********** what footprint are we testing ************
#define footprint test_1
//#define footprint test_2
//#define footprint test_footprint
//#define footprint test_simple_footprint

// count can be one of: 1, 101, 201, ... 1001
#define COUNT 801
//#define COUNT 1



void test_smart_assert_footprint() {
    using namespace boost::smart_assert;
    // note: initialized like this on purpose !!!
    // (this won't allow the compiler to make any assumtions
    //  based on the value of i!!!
    int i = rand();
    footprint; ++i;

    // 1000 more calls

    // 100
#if COUNT > 100
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
#endif

    // 200
#if COUNT > 200
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
#endif

    // 300
#if COUNT > 300
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
#endif

    // 400
#if COUNT > 400
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
#endif

    // 500
#if COUNT > 500
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
#endif

    // 600
#if COUNT > 600
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
#endif

    // 700
#if COUNT > 700
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
#endif

    // 800
#if COUNT > 800
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
#endif

    // 900
#if COUNT > 900
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
#endif

    // 1000
#if COUNT > 1000
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;    footprint; ++i;
#endif
}

    
int main( int argc, char * argv[])
{
    // note - right now working only for win32
    compute_avg_footprint( argv[ 0], COUNT);
    std::cout << "\nnote: from this average, you "
        << "should substract the small size taken by '++i'\n"
        << "(probably 4 bytes)";
    if ( std::cout.good() ) {
        std::cin.get();
        return 0;
    }
    // make sure we call this function (so that it won't be
    // optimized away)
    test_smart_assert_footprint();
    return 0;
}
