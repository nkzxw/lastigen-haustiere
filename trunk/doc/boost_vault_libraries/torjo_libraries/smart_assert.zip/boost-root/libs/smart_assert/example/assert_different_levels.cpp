// assert_different_levels.cpp 
//
/*
    setting the level of SMART_ASSERT
*/

// uncomment this, for the SMART_ASSERTs to behave just like
// in Release mode (that is, turning off SMART_ASSERTions)
//
// #define BOOST_SMART_ASSERT_MODE 0


#include <boost/smart_assert_ext.hpp>

#include <iostream>
#include <string>
#include <list>

using namespace boost::smart_assert;


void test_assert_different_levels()
{
    // LEVEL warning
    int nUsersCount = 900;
    SMART_ASSERT( (nUsersCount * 10/9) < 1000) (nUsersCount)
        .warn( "Users Count almost reaching max. capacity (1000)!");


    // LEVEL debug
    int i = 3000;
    SMART_ASSERT( i < 100) (i).debug( "index too big!");

    // custom level;
    // this will also dump to console a "[SMART_ASSERT logical error]"
    // which is totally correct, since we have not set the handler
    // for level 500
    //
    //
    //
    // shortcut, instead of SMART_ASSERT(p)(p);
    int *p = 0;
    SMART_ASSERT(p).level( 500, "some custom level (500, that is)");


    // LEVEL error
    try {
        int i = 0, j = 0;
        SMART_ASSERT(i != j)(i)(j).error( "values should be different!");
#ifdef BOOST_SMART_ASSERT_DEBUG
        std::cout << "SHOULD NEVER ARRIVE HERE" << std::endl;
#endif
    }
    catch ( std::exception & exc) {
        std::cout << exc.what() << std::endl;
    }

    
    // LEVEL critical
    //
    // note: this, by default, would abort.
    // However, we change this, to just dump to console
    assert_settings().set_level_handler(
        lvl_fatal, &print_details_to_console);
    std::string strUserName = "titi";
    SMART_ASSERT( strUserName == "admin")(strUserName)
        .fatal( "User is not an administrator!");
    // set the default handler back
    assert_settings().set_level_handler(
        lvl_fatal, &default_handle_fatal);

}





int main()
{
    test_assert_different_levels();

    std::cout << "\nExample over. Press a non-space key." << std::endl;

    while ( isspace( std::cin.get() ));
    return 0;
}

