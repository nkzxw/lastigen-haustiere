/*
    together with test_smart_assert_footprint.cpp

    We include smart_assert_ext in a separate file, to maximize
    the chances for the compiler NOT to inline member functions involved 
    in SMART_ASSERT
*/

// we're in release mode, turn on SMART_ASSERTs
#define BOOST_SMART_ASSERT_MODE 1
#include <boost/smart_assert_ext.hpp>


#if defined(BOOST_SMART_ASSERT_WIN32)

#include <sys/types.h>
#include <sys/stat.h>

int get_file_size( const char * str) {
#if defined( BOOST_MSVC) || defined( __COMO__)
    struct _stat dest;
#else 
    struct stat dest;
#endif
    _stat( str, &dest);
    return dest.st_size;
}

#endif


void compute_avg_footprint( const char * exe_name, int count) {

    // note - right now working only for win32
#if defined(BOOST_SMART_ASSERT_WIN32)
    // note: asking about std::cout as well,
    // because I want the compiler to generate
    // both branches of code, no matter the value of COUNT
    // (otherwise, one could be optimized away)
    if ( std::cout && (count == 1) ) {
        std::ofstream out( "size.txt");
        int size = get_file_size( exe_name);
        out << size << std::endl;
        std::cout << "size written to size.txt, for when count = 1 : " << size << std::endl;
    }
    else {
        std::ifstream in( "size.txt");
        int old_size = 0;
        in >> old_size;

        int new_size = get_file_size( exe_name);
        int average = ( new_size - old_size) / count;
        std::cout << "Avg footprint = " << average << std::endl;        
        std::cout << "(old size = " << old_size 
            << ", new size = " << new_size 
            << ", diff = " << new_size - old_size 
            << ")" << std::endl;
    }

#endif
}
