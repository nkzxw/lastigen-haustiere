// persistent_asserts.cpp

// Boost.SmartAssert library
//
// Copyright (C) 2003 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
 
// See http://www.boost.org for updates, documentation, and revision history.

/*
    Shows how you can use Persitent ASSERTions

    Execute it, and select amongst the IGNORE options.

    To understand how it works, execute the program multiple times.
    (if you choose to ignore an assert forever, you'll see that it
     will be ignored by default on the next runs of the program!)
*/


#include <boost/smart_assert_ext.hpp>
using namespace boost::smart_assert;


// idx - the index of the call to this function
void test_persistent_asserts( int idx) {

    int *one = 0;
    int *two = 0;
    int *three = 0;

    // note: all the following ASSERTs have the default level
    // ('debug', that is)
    SMART_ASSERT(one)(idx);
    SMART_ASSERT(two)(idx);
    SMART_ASSERT(three)(idx);
}


int main() {

    configs_array().run_config( "dbg_persist");

    // show all possible options, when asking user
    assert_settings().set_level_handler( 
        lvl_debug, &ask_user_on_assert_internal_testing);

    for ( int idx = 0; idx < 5; ++idx)
        test_persistent_asserts( idx);

    std::cout << "\nExample over. Press a non-space key." << std::endl;

    while ( isspace( std::cin.get() ));
    return 0;
}
