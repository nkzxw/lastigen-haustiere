// assert_impl.h


TODO: make it interoperate with Boost.Log

// Boost.SmartAssert library
//
// Copyright (C) 2003 John Torjo (john@torjo.com)
//
//  Use, modification, and distribution is subject to the Boost Software
//  License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
 
// See http://www.boost.org for updates, documentation, and revision history.

// to know the version of the SMART_ASSERT you're using right now, 
// check out <boost/smart_assert/version.txt>

#ifndef BOOST_SMART_ASSERT_ASSERT_IMPL_HPP_INCLUDED
#define BOOST_SMART_ASSERT_ASSERT_IMPL_HPP_INCLUDED

#if _MSC_VER >= 1020
#pragma once
#endif



#include <boost/smart_assert/assert_ext.hpp>

// Implementation
#include <boost/smart_assert/priv/impl/smart_assert.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_cfgarray.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_context.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_ctxfunc.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_h_basic.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_h_ext.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_h_win32.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_init.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_l_basic.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_l_ext.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_persist.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_settings.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_util.hpp>
#include <boost/smart_assert/priv/impl/smart_assert_keeper.hpp>

#ifndef BOOST_SMART_ASSERT_OVERRIDE_DEFAULTS
#include <boost/smart_assert/priv/impl/smart_assert_default.hpp>
#endif



#endif
