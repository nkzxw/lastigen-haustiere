// smart_assert_ext.h

// Boost.SmartAssert library
//
// Copyright (C) 2003 John Torjo (john@torjo.com)
//
//  Use, modification, and distribution is subject to the Boost Software
//  License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
 
// See http://www.boost.org for updates, documentation, and revision history.

// to know the version of the SMART_ASSERT you're using right now, 
// check out <boost/smart_assert/version.txt>

#ifndef BOOST_SMART_ASSERT_EXT_HPP_INCLUDED
#define BOOST_SMART_ASSERT_EXT_HPP_INCLUDED

// you're encouraged not to include smart_assert_ext.hpp.
// Include '<boost/smart_assert/assert_impl.hpp>' instead.
// This is kept only for backward compatibility
#include <boost/smart_assert/assert_impl.hpp>

#endif
