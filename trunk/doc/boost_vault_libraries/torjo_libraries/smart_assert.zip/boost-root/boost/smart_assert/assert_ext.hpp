// smart_assert_ext.h

// Boost.SmartAssert library
//
// Copyright (C) 2003 John Torjo (john@torjo.com)
//
//  Use, modification, and distribution is subject to the Boost Software
//  License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
 
// See http://www.boost.org for updates, documentation, and revision history.

// to know the version of the SMART_ASSERT you're using right now, 
// check out <boost/smart_assert/version.txt>

#ifndef BOOST_SMART_ASSERT_EXT_HPP_INCLUDED
#define BOOST_SMART_ASSERT_EXT_HPP_INCLUDED

#include <boost/smart_assert/assert.hpp>

#ifdef BOOST_SMART_ASSERT_WIN32
// Win32 specific
#define WIN32_LEAN_AND_MEAN
#define BOOST_WIN32_LEAN_AND_MEAN_DEFINED
#endif // BOOST_SMART_ASSERT_WIN32

#include <boost/smart_assert/priv/fwd/before_includes.hpp>

// persistence
#include <boost/smart_assert/priv/fwd/smart_assert_persist.hpp>

// extra (cool) handlers !!!
#include <boost/smart_assert/priv/fwd/smart_assert_h_ext.hpp>

// extra (cool) loggers !!!
#include <boost/smart_assert/priv/fwd/smart_assert_l_ext.hpp>


// Configurations
#include <boost/smart_assert/priv/fwd/smart_assert_cfgarray.hpp>
#include <boost/smart_assert/priv/fwd/smart_assert_init.hpp>


#ifdef BOOST_WIN32_LEAN_AND_MEAN_DEFINED
    #undef BOOST_WIN32_LEAN_AND_MEAN_DEFINED
    #undef WIN32_LEAN_AND_MEAN
#endif

#include <boost/smart_assert/priv/fwd/after_includes.hpp>

#endif
