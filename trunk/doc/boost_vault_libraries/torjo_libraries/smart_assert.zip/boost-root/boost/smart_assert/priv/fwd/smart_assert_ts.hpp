// fwd/smart_assert_ts.hpp

// Boost.SmartAssert library
//
// Copyright (C) 2003 John Torjo (john@torjo.com)
//
// Permission to copy, use, sell and distribute this software is granted
// provided this copyright notice appears in all copies.
// Permission to modify the code and to distribute modified code is granted
// provided this copyright notice appears in all copies, and a notice
// that the code was modified is included with the copyright notice.
//
// This software is provided "as is" without express or implied warranty,
// and with no claim as to its suitability for any purpose.
 
// See http://www.boost.org for updates, documentation, and revision history.

// to know the version of the SMART_ASSERT you're using right now, 
// check out <boost/smart_assert/version.txt>

#ifndef BOOST_INNER_SMART_ASSERT_THREAD_SAFE_HPP_INCLUDED
#define BOOST_INNER_SMART_ASSERT_THREAD_SAFE_HPP_INCLUDED

#if _MSC_VER >= 1020
#pragma once
#endif


// thread-safe issues

/*
    By default, if BOOST_HAS_THREADS defined    -> thread-safe
                if                   not def.   -> NOT thread safe

    Override this with :
    BOOST_SMART_ASSERT_TS_TYPE       0          -> NOT thread-safe
    BOOST_SMART_ASSERT_TS_TYPE       1          -> thread-safe
*/


// thanks Pavel Vozenilek!
#include <boost/config.hpp>

#undef BOOST_SMART_ASSERT_THREAD_SAFE

#if defined(BOOST_SMART_ASSERT_TS_TYPE)
    #if BOOST_SMART_ASSERT_TS_TYPE != 0
    #define BOOST_SMART_ASSERT_THREAD_SAFE
    #endif
#else
    // defaults
    #ifdef BOOST_HAS_THREADS
    #define BOOST_SMART_ASSERT_THREAD_SAFE
    #endif
#endif // defined(BOOST_SMART_ASSERT_TS_TYPE)


#ifdef BOOST_SMART_ASSERT_THREAD_SAFE
#include <boost/thread/recursive_mutex.hpp>
#endif

namespace boost {

namespace smart_assert {

namespace Private {

#ifdef BOOST_SMART_ASSERT_THREAD_SAFE
// thread-safe

// we might enter ASSERT recursively (twice in the same thread);
// therefore, we should use recursive_mutex !!!!! 
typedef boost::recursive_mutex mutex_type;
typedef boost::recursive_mutex::scoped_lock lock_type;

#else
// not thread-safe
struct mutex_type {};
struct lock_type { 
    lock_type( mutex_type &) {}
    ~lock_type() {}
};
#endif




#undef BOOST_SMART_ASSERT_THREAD_SAFE


} // namespace Private

} // namespace smart_assert

} // namespace boost

#endif 
